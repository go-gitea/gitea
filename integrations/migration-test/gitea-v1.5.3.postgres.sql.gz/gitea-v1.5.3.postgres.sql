--
-- PostgreSQL database dump
--

-- Dumped from database version 10.6 (Ubuntu 10.6-0ubuntu0.18.04.1)
-- Dumped by pg_dump version 10.6 (Ubuntu 10.6-0ubuntu0.18.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP INDEX IF EXISTS gtestschema."UQE_watch_watch";
DROP INDEX IF EXISTS gtestschema."UQE_user_open_id_uri";
DROP INDEX IF EXISTS gtestschema."UQE_user_name";
DROP INDEX IF EXISTS gtestschema."UQE_user_lower_name";
DROP INDEX IF EXISTS gtestschema."UQE_upload_uuid";
DROP INDEX IF EXISTS gtestschema."UQE_two_factor_uid";
DROP INDEX IF EXISTS gtestschema."UQE_topic_name";
DROP INDEX IF EXISTS gtestschema."UQE_team_user_s";
DROP INDEX IF EXISTS gtestschema."UQE_team_unit_s";
DROP INDEX IF EXISTS gtestschema."UQE_team_repo_s";
DROP INDEX IF EXISTS gtestschema."UQE_star_s";
DROP INDEX IF EXISTS gtestschema."UQE_repository_s";
DROP INDEX IF EXISTS gtestschema."UQE_repo_topic_s";
DROP INDEX IF EXISTS gtestschema."UQE_repo_redirect_s";
DROP INDEX IF EXISTS gtestschema."UQE_release_n";
DROP INDEX IF EXISTS gtestschema."UQE_reaction_s";
DROP INDEX IF EXISTS gtestschema."UQE_protected_branch_s";
DROP INDEX IF EXISTS gtestschema."UQE_org_user_s";
DROP INDEX IF EXISTS gtestschema."UQE_login_source_name";
DROP INDEX IF EXISTS gtestschema."UQE_lfs_meta_object_s";
DROP INDEX IF EXISTS gtestschema."UQE_issue_watch_watch";
DROP INDEX IF EXISTS gtestschema."UQE_issue_repo_index";
DROP INDEX IF EXISTS gtestschema."UQE_issue_label_s";
DROP INDEX IF EXISTS gtestschema."UQE_follow_follow";
DROP INDEX IF EXISTS gtestschema."UQE_email_address_email";
DROP INDEX IF EXISTS gtestschema."UQE_deploy_key_s";
DROP INDEX IF EXISTS gtestschema."UQE_deleted_branch_s";
DROP INDEX IF EXISTS gtestschema."UQE_commit_status_repo_sha_index";
DROP INDEX IF EXISTS gtestschema."UQE_collaboration_s";
DROP INDEX IF EXISTS gtestschema."UQE_attachment_uuid";
DROP INDEX IF EXISTS gtestschema."UQE_access_token_sha1";
DROP INDEX IF EXISTS gtestschema."UQE_access_s";
DROP INDEX IF EXISTS gtestschema."IDX_webhook_updated_unix";
DROP INDEX IF EXISTS gtestschema."IDX_webhook_repo_id";
DROP INDEX IF EXISTS gtestschema."IDX_webhook_org_id";
DROP INDEX IF EXISTS gtestschema."IDX_webhook_is_active";
DROP INDEX IF EXISTS gtestschema."IDX_webhook_created_unix";
DROP INDEX IF EXISTS gtestschema."IDX_user_updated_unix";
DROP INDEX IF EXISTS gtestschema."IDX_user_open_id_uid";
DROP INDEX IF EXISTS gtestschema."IDX_user_last_login_unix";
DROP INDEX IF EXISTS gtestschema."IDX_user_is_active";
DROP INDEX IF EXISTS gtestschema."IDX_user_created_unix";
DROP INDEX IF EXISTS gtestschema."IDX_u2f_registration_user_id";
DROP INDEX IF EXISTS gtestschema."IDX_u2f_registration_updated_unix";
DROP INDEX IF EXISTS gtestschema."IDX_u2f_registration_created_unix";
DROP INDEX IF EXISTS gtestschema."IDX_two_factor_updated_unix";
DROP INDEX IF EXISTS gtestschema."IDX_two_factor_created_unix";
DROP INDEX IF EXISTS gtestschema."IDX_tracked_time_user_id";
DROP INDEX IF EXISTS gtestschema."IDX_tracked_time_issue_id";
DROP INDEX IF EXISTS gtestschema."IDX_topic_updated_unix";
DROP INDEX IF EXISTS gtestschema."IDX_topic_created_unix";
DROP INDEX IF EXISTS gtestschema."IDX_team_user_org_id";
DROP INDEX IF EXISTS gtestschema."IDX_team_unit_org_id";
DROP INDEX IF EXISTS gtestschema."IDX_team_repo_org_id";
DROP INDEX IF EXISTS gtestschema."IDX_team_org_id";
DROP INDEX IF EXISTS gtestschema."IDX_stopwatch_user_id";
DROP INDEX IF EXISTS gtestschema."IDX_stopwatch_issue_id";
DROP INDEX IF EXISTS gtestschema."IDX_repository_updated_unix";
DROP INDEX IF EXISTS gtestschema."IDX_repository_name";
DROP INDEX IF EXISTS gtestschema."IDX_repository_lower_name";
DROP INDEX IF EXISTS gtestschema."IDX_repository_is_private";
DROP INDEX IF EXISTS gtestschema."IDX_repository_is_mirror";
DROP INDEX IF EXISTS gtestschema."IDX_repository_is_fork";
DROP INDEX IF EXISTS gtestschema."IDX_repository_is_bare";
DROP INDEX IF EXISTS gtestschema."IDX_repository_fork_id";
DROP INDEX IF EXISTS gtestschema."IDX_repository_created_unix";
DROP INDEX IF EXISTS gtestschema."IDX_repo_unit_s";
DROP INDEX IF EXISTS gtestschema."IDX_repo_unit_created_unix";
DROP INDEX IF EXISTS gtestschema."IDX_repo_redirect_lower_name";
DROP INDEX IF EXISTS gtestschema."IDX_repo_indexer_status_repo_id";
DROP INDEX IF EXISTS gtestschema."IDX_release_tag_name";
DROP INDEX IF EXISTS gtestschema."IDX_release_repo_id";
DROP INDEX IF EXISTS gtestschema."IDX_release_publisher_id";
DROP INDEX IF EXISTS gtestschema."IDX_release_created_unix";
DROP INDEX IF EXISTS gtestschema."IDX_reaction_user_id";
DROP INDEX IF EXISTS gtestschema."IDX_reaction_type";
DROP INDEX IF EXISTS gtestschema."IDX_reaction_issue_id";
DROP INDEX IF EXISTS gtestschema."IDX_reaction_created_unix";
DROP INDEX IF EXISTS gtestschema."IDX_reaction_comment_id";
DROP INDEX IF EXISTS gtestschema."IDX_pull_request_merger_id";
DROP INDEX IF EXISTS gtestschema."IDX_pull_request_merged_unix";
DROP INDEX IF EXISTS gtestschema."IDX_pull_request_issue_id";
DROP INDEX IF EXISTS gtestschema."IDX_pull_request_head_repo_id";
DROP INDEX IF EXISTS gtestschema."IDX_pull_request_has_merged";
DROP INDEX IF EXISTS gtestschema."IDX_pull_request_base_repo_id";
DROP INDEX IF EXISTS gtestschema."IDX_public_key_owner_id";
DROP INDEX IF EXISTS gtestschema."IDX_org_user_uid";
DROP INDEX IF EXISTS gtestschema."IDX_org_user_org_id";
DROP INDEX IF EXISTS gtestschema."IDX_org_user_is_public";
DROP INDEX IF EXISTS gtestschema."IDX_oauth2_session_expires_unix";
DROP INDEX IF EXISTS gtestschema."IDX_notification_user_id";
DROP INDEX IF EXISTS gtestschema."IDX_notification_updated_unix";
DROP INDEX IF EXISTS gtestschema."IDX_notification_updated_by";
DROP INDEX IF EXISTS gtestschema."IDX_notification_status";
DROP INDEX IF EXISTS gtestschema."IDX_notification_source";
DROP INDEX IF EXISTS gtestschema."IDX_notification_repo_id";
DROP INDEX IF EXISTS gtestschema."IDX_notification_issue_id";
DROP INDEX IF EXISTS gtestschema."IDX_notification_created_unix";
DROP INDEX IF EXISTS gtestschema."IDX_notification_commit_id";
DROP INDEX IF EXISTS gtestschema."IDX_notice_created_unix";
DROP INDEX IF EXISTS gtestschema."IDX_mirror_updated_unix";
DROP INDEX IF EXISTS gtestschema."IDX_mirror_repo_id";
DROP INDEX IF EXISTS gtestschema."IDX_mirror_next_update_unix";
DROP INDEX IF EXISTS gtestschema."IDX_milestone_repo_id";
DROP INDEX IF EXISTS gtestschema."IDX_login_source_updated_unix";
DROP INDEX IF EXISTS gtestschema."IDX_login_source_is_sync_enabled";
DROP INDEX IF EXISTS gtestschema."IDX_login_source_is_actived";
DROP INDEX IF EXISTS gtestschema."IDX_login_source_created_unix";
DROP INDEX IF EXISTS gtestschema."IDX_lfs_meta_object_repository_id";
DROP INDEX IF EXISTS gtestschema."IDX_lfs_meta_object_oid";
DROP INDEX IF EXISTS gtestschema."IDX_lfs_lock_repo_id";
DROP INDEX IF EXISTS gtestschema."IDX_lfs_lock_owner_id";
DROP INDEX IF EXISTS gtestschema."IDX_label_repo_id";
DROP INDEX IF EXISTS gtestschema."IDX_issue_user_uid";
DROP INDEX IF EXISTS gtestschema."IDX_issue_updated_unix";
DROP INDEX IF EXISTS gtestschema."IDX_issue_repo_id";
DROP INDEX IF EXISTS gtestschema."IDX_issue_poster_id";
DROP INDEX IF EXISTS gtestschema."IDX_issue_milestone_id";
DROP INDEX IF EXISTS gtestschema."IDX_issue_is_pull";
DROP INDEX IF EXISTS gtestschema."IDX_issue_is_closed";
DROP INDEX IF EXISTS gtestschema."IDX_issue_deadline_unix";
DROP INDEX IF EXISTS gtestschema."IDX_issue_created_unix";
DROP INDEX IF EXISTS gtestschema."IDX_issue_closed_unix";
DROP INDEX IF EXISTS gtestschema."IDX_issue_assignees_issue_id";
DROP INDEX IF EXISTS gtestschema."IDX_issue_assignees_assignee_id";
DROP INDEX IF EXISTS gtestschema."IDX_hook_task_repo_id";
DROP INDEX IF EXISTS gtestschema."IDX_gpg_key_owner_id";
DROP INDEX IF EXISTS gtestschema."IDX_gpg_key_key_id";
DROP INDEX IF EXISTS gtestschema."IDX_external_login_user_user_id";
DROP INDEX IF EXISTS gtestschema."IDX_email_address_uid";
DROP INDEX IF EXISTS gtestschema."IDX_deploy_key_repo_id";
DROP INDEX IF EXISTS gtestschema."IDX_deploy_key_key_id";
DROP INDEX IF EXISTS gtestschema."IDX_deleted_branch_repo_id";
DROP INDEX IF EXISTS gtestschema."IDX_deleted_branch_deleted_unix";
DROP INDEX IF EXISTS gtestschema."IDX_deleted_branch_deleted_by_id";
DROP INDEX IF EXISTS gtestschema."IDX_commit_status_updated_unix";
DROP INDEX IF EXISTS gtestschema."IDX_commit_status_sha";
DROP INDEX IF EXISTS gtestschema."IDX_commit_status_repo_id";
DROP INDEX IF EXISTS gtestschema."IDX_commit_status_index";
DROP INDEX IF EXISTS gtestschema."IDX_commit_status_created_unix";
DROP INDEX IF EXISTS gtestschema."IDX_comment_updated_unix";
DROP INDEX IF EXISTS gtestschema."IDX_comment_poster_id";
DROP INDEX IF EXISTS gtestschema."IDX_comment_issue_id";
DROP INDEX IF EXISTS gtestschema."IDX_comment_created_unix";
DROP INDEX IF EXISTS gtestschema."IDX_collaboration_user_id";
DROP INDEX IF EXISTS gtestschema."IDX_collaboration_repo_id";
DROP INDEX IF EXISTS gtestschema."IDX_attachment_release_id";
DROP INDEX IF EXISTS gtestschema."IDX_attachment_issue_id";
DROP INDEX IF EXISTS gtestschema."IDX_action_user_id";
DROP INDEX IF EXISTS gtestschema."IDX_action_repo_id";
DROP INDEX IF EXISTS gtestschema."IDX_action_is_private";
DROP INDEX IF EXISTS gtestschema."IDX_action_is_deleted";
DROP INDEX IF EXISTS gtestschema."IDX_action_created_unix";
DROP INDEX IF EXISTS gtestschema."IDX_action_comment_id";
DROP INDEX IF EXISTS gtestschema."IDX_action_act_user_id";
DROP INDEX IF EXISTS gtestschema."IDX_access_token_updated_unix";
DROP INDEX IF EXISTS gtestschema."IDX_access_token_uid";
DROP INDEX IF EXISTS gtestschema."IDX_access_token_created_unix";
ALTER TABLE IF EXISTS ONLY gtestschema.webhook DROP CONSTRAINT webhook_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.watch DROP CONSTRAINT watch_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.version DROP CONSTRAINT version_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema."user" DROP CONSTRAINT user_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.user_open_id DROP CONSTRAINT user_open_id_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.upload DROP CONSTRAINT upload_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.u2f_registration DROP CONSTRAINT u2f_registration_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.two_factor DROP CONSTRAINT two_factor_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.tracked_time DROP CONSTRAINT tracked_time_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.topic DROP CONSTRAINT topic_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.team_user DROP CONSTRAINT team_user_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.team_unit DROP CONSTRAINT team_unit_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.team_repo DROP CONSTRAINT team_repo_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.team DROP CONSTRAINT team_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.stopwatch DROP CONSTRAINT stopwatch_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.star DROP CONSTRAINT star_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.repository DROP CONSTRAINT repository_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.repo_unit DROP CONSTRAINT repo_unit_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.repo_redirect DROP CONSTRAINT repo_redirect_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.repo_indexer_status DROP CONSTRAINT repo_indexer_status_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.release DROP CONSTRAINT release_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.reaction DROP CONSTRAINT reaction_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.pull_request DROP CONSTRAINT pull_request_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.public_key DROP CONSTRAINT public_key_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.protected_branch DROP CONSTRAINT protected_branch_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.org_user DROP CONSTRAINT org_user_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.oauth2_session DROP CONSTRAINT oauth2_session_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.notification DROP CONSTRAINT notification_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.notice DROP CONSTRAINT notice_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.mirror DROP CONSTRAINT mirror_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.milestone DROP CONSTRAINT milestone_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.login_source DROP CONSTRAINT login_source_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.lfs_meta_object DROP CONSTRAINT lfs_meta_object_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.lfs_lock DROP CONSTRAINT lfs_lock_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.label DROP CONSTRAINT label_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.issue_watch DROP CONSTRAINT issue_watch_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.issue_user DROP CONSTRAINT issue_user_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.issue DROP CONSTRAINT issue_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.issue_label DROP CONSTRAINT issue_label_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.issue_assignees DROP CONSTRAINT issue_assignees_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.hook_task DROP CONSTRAINT hook_task_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.gpg_key DROP CONSTRAINT gpg_key_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.follow DROP CONSTRAINT follow_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.external_login_user DROP CONSTRAINT external_login_user_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.email_address DROP CONSTRAINT email_address_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.deploy_key DROP CONSTRAINT deploy_key_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.deleted_branch DROP CONSTRAINT deleted_branch_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.commit_status DROP CONSTRAINT commit_status_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.comment DROP CONSTRAINT comment_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.collaboration DROP CONSTRAINT collaboration_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.attachment DROP CONSTRAINT attachment_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.action DROP CONSTRAINT action_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.access_token DROP CONSTRAINT access_token_pkey;
ALTER TABLE IF EXISTS ONLY gtestschema.access DROP CONSTRAINT access_pkey;
ALTER TABLE IF EXISTS gtestschema.webhook ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.watch ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.version ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.user_open_id ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema."user" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.upload ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.u2f_registration ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.two_factor ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.tracked_time ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.topic ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.team_user ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.team_unit ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.team_repo ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.team ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.stopwatch ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.star ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.repository ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.repo_unit ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.repo_redirect ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.repo_indexer_status ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.release ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.reaction ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.pull_request ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.public_key ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.protected_branch ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.org_user ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.notification ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.notice ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.mirror ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.milestone ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.login_source ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.lfs_meta_object ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.lfs_lock ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.label ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.issue_watch ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.issue_user ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.issue_label ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.issue_assignees ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.issue ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.hook_task ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.gpg_key ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.follow ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.email_address ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.deploy_key ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.deleted_branch ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.commit_status ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.comment ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.collaboration ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.attachment ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.action ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.access_token ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS gtestschema.access ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS gtestschema.webhook_id_seq;
DROP TABLE IF EXISTS gtestschema.webhook;
DROP SEQUENCE IF EXISTS gtestschema.watch_id_seq;
DROP TABLE IF EXISTS gtestschema.watch;
DROP SEQUENCE IF EXISTS gtestschema.version_id_seq;
DROP TABLE IF EXISTS gtestschema.version;
DROP SEQUENCE IF EXISTS gtestschema.user_open_id_id_seq;
DROP TABLE IF EXISTS gtestschema.user_open_id;
DROP SEQUENCE IF EXISTS gtestschema.user_id_seq;
DROP TABLE IF EXISTS gtestschema."user";
DROP SEQUENCE IF EXISTS gtestschema.upload_id_seq;
DROP TABLE IF EXISTS gtestschema.upload;
DROP SEQUENCE IF EXISTS gtestschema.u2f_registration_id_seq;
DROP TABLE IF EXISTS gtestschema.u2f_registration;
DROP SEQUENCE IF EXISTS gtestschema.two_factor_id_seq;
DROP TABLE IF EXISTS gtestschema.two_factor;
DROP SEQUENCE IF EXISTS gtestschema.tracked_time_id_seq;
DROP TABLE IF EXISTS gtestschema.tracked_time;
DROP SEQUENCE IF EXISTS gtestschema.topic_id_seq;
DROP TABLE IF EXISTS gtestschema.topic;
DROP SEQUENCE IF EXISTS gtestschema.team_user_id_seq;
DROP TABLE IF EXISTS gtestschema.team_user;
DROP SEQUENCE IF EXISTS gtestschema.team_unit_id_seq;
DROP TABLE IF EXISTS gtestschema.team_unit;
DROP SEQUENCE IF EXISTS gtestschema.team_repo_id_seq;
DROP TABLE IF EXISTS gtestschema.team_repo;
DROP SEQUENCE IF EXISTS gtestschema.team_id_seq;
DROP TABLE IF EXISTS gtestschema.team;
DROP SEQUENCE IF EXISTS gtestschema.stopwatch_id_seq;
DROP TABLE IF EXISTS gtestschema.stopwatch;
DROP SEQUENCE IF EXISTS gtestschema.star_id_seq;
DROP TABLE IF EXISTS gtestschema.star;
DROP SEQUENCE IF EXISTS gtestschema.repository_id_seq;
DROP TABLE IF EXISTS gtestschema.repository;
DROP SEQUENCE IF EXISTS gtestschema.repo_unit_id_seq;
DROP TABLE IF EXISTS gtestschema.repo_unit;
DROP TABLE IF EXISTS gtestschema.repo_topic;
DROP SEQUENCE IF EXISTS gtestschema.repo_redirect_id_seq;
DROP TABLE IF EXISTS gtestschema.repo_redirect;
DROP SEQUENCE IF EXISTS gtestschema.repo_indexer_status_id_seq;
DROP TABLE IF EXISTS gtestschema.repo_indexer_status;
DROP SEQUENCE IF EXISTS gtestschema.release_id_seq;
DROP TABLE IF EXISTS gtestschema.release;
DROP SEQUENCE IF EXISTS gtestschema.reaction_id_seq;
DROP TABLE IF EXISTS gtestschema.reaction;
DROP SEQUENCE IF EXISTS gtestschema.pull_request_id_seq;
DROP TABLE IF EXISTS gtestschema.pull_request;
DROP SEQUENCE IF EXISTS gtestschema.public_key_id_seq;
DROP TABLE IF EXISTS gtestschema.public_key;
DROP SEQUENCE IF EXISTS gtestschema.protected_branch_id_seq;
DROP TABLE IF EXISTS gtestschema.protected_branch;
DROP SEQUENCE IF EXISTS gtestschema.org_user_id_seq;
DROP TABLE IF EXISTS gtestschema.org_user;
DROP TABLE IF EXISTS gtestschema.oauth2_session;
DROP SEQUENCE IF EXISTS gtestschema.notification_id_seq;
DROP TABLE IF EXISTS gtestschema.notification;
DROP SEQUENCE IF EXISTS gtestschema.notice_id_seq;
DROP TABLE IF EXISTS gtestschema.notice;
DROP SEQUENCE IF EXISTS gtestschema.mirror_id_seq;
DROP TABLE IF EXISTS gtestschema.mirror;
DROP SEQUENCE IF EXISTS gtestschema.milestone_id_seq;
DROP TABLE IF EXISTS gtestschema.milestone;
DROP SEQUENCE IF EXISTS gtestschema.login_source_id_seq;
DROP TABLE IF EXISTS gtestschema.login_source;
DROP SEQUENCE IF EXISTS gtestschema.lfs_meta_object_id_seq;
DROP TABLE IF EXISTS gtestschema.lfs_meta_object;
DROP SEQUENCE IF EXISTS gtestschema.lfs_lock_id_seq;
DROP TABLE IF EXISTS gtestschema.lfs_lock;
DROP SEQUENCE IF EXISTS gtestschema.label_id_seq;
DROP TABLE IF EXISTS gtestschema.label;
DROP SEQUENCE IF EXISTS gtestschema.issue_watch_id_seq;
DROP TABLE IF EXISTS gtestschema.issue_watch;
DROP SEQUENCE IF EXISTS gtestschema.issue_user_id_seq;
DROP TABLE IF EXISTS gtestschema.issue_user;
DROP SEQUENCE IF EXISTS gtestschema.issue_label_id_seq;
DROP TABLE IF EXISTS gtestschema.issue_label;
DROP SEQUENCE IF EXISTS gtestschema.issue_id_seq;
DROP SEQUENCE IF EXISTS gtestschema.issue_assignees_id_seq;
DROP TABLE IF EXISTS gtestschema.issue_assignees;
DROP TABLE IF EXISTS gtestschema.issue;
DROP SEQUENCE IF EXISTS gtestschema.hook_task_id_seq;
DROP TABLE IF EXISTS gtestschema.hook_task;
DROP SEQUENCE IF EXISTS gtestschema.gpg_key_id_seq;
DROP TABLE IF EXISTS gtestschema.gpg_key;
DROP SEQUENCE IF EXISTS gtestschema.follow_id_seq;
DROP TABLE IF EXISTS gtestschema.follow;
DROP TABLE IF EXISTS gtestschema.external_login_user;
DROP SEQUENCE IF EXISTS gtestschema.email_address_id_seq;
DROP TABLE IF EXISTS gtestschema.email_address;
DROP SEQUENCE IF EXISTS gtestschema.deploy_key_id_seq;
DROP TABLE IF EXISTS gtestschema.deploy_key;
DROP SEQUENCE IF EXISTS gtestschema.deleted_branch_id_seq;
DROP TABLE IF EXISTS gtestschema.deleted_branch;
DROP SEQUENCE IF EXISTS gtestschema.commit_status_id_seq;
DROP TABLE IF EXISTS gtestschema.commit_status;
DROP SEQUENCE IF EXISTS gtestschema.comment_id_seq;
DROP TABLE IF EXISTS gtestschema.comment;
DROP SEQUENCE IF EXISTS gtestschema.collaboration_id_seq;
DROP TABLE IF EXISTS gtestschema.collaboration;
DROP SEQUENCE IF EXISTS gtestschema.attachment_id_seq;
DROP TABLE IF EXISTS gtestschema.attachment;
DROP SEQUENCE IF EXISTS gtestschema.action_id_seq;
DROP TABLE IF EXISTS gtestschema.action;
DROP SEQUENCE IF EXISTS gtestschema.access_token_id_seq;
DROP TABLE IF EXISTS gtestschema.access_token;
DROP SEQUENCE IF EXISTS gtestschema.access_id_seq;
DROP TABLE IF EXISTS gtestschema.access;
DROP EXTENSION IF EXISTS plpgsql;
DROP SCHEMA IF EXISTS gtestschema;
--
-- Name: gtestschema; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA gtestschema;


ALTER SCHEMA gtestschema OWNER TO postgres;

--
-- Name: SCHEMA gtestschema; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA gtestschema IS 'Gitea default schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner:
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner:
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: access; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.access (
    id bigint NOT NULL,
    user_id bigint,
    repo_id bigint,
    mode integer
);


ALTER TABLE gtestschema.access OWNER TO postgres;

--
-- Name: access_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.access_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.access_id_seq OWNER TO postgres;

--
-- Name: access_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.access_id_seq OWNED BY gtestschema.access.id;


--
-- Name: access_token; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.access_token (
    id bigint NOT NULL,
    uid bigint,
    name character varying(255),
    sha1 character varying(40),
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE gtestschema.access_token OWNER TO postgres;

--
-- Name: access_token_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.access_token_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.access_token_id_seq OWNER TO postgres;

--
-- Name: access_token_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.access_token_id_seq OWNED BY gtestschema.access_token.id;


--
-- Name: action; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.action (
    id bigint NOT NULL,
    user_id bigint,
    op_type integer,
    act_user_id bigint,
    repo_id bigint,
    comment_id bigint,
    is_deleted boolean DEFAULT false NOT NULL,
    ref_name character varying(255),
    is_private boolean DEFAULT false NOT NULL,
    content text,
    created_unix bigint
);


ALTER TABLE gtestschema.action OWNER TO postgres;

--
-- Name: action_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.action_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.action_id_seq OWNER TO postgres;

--
-- Name: action_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.action_id_seq OWNED BY gtestschema.action.id;


--
-- Name: attachment; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.attachment (
    id bigint NOT NULL,
    uuid uuid,
    issue_id bigint,
    release_id bigint,
    comment_id bigint,
    name character varying(255),
    download_count bigint DEFAULT 0,
    size bigint DEFAULT 0,
    created_unix bigint
);


ALTER TABLE gtestschema.attachment OWNER TO postgres;

--
-- Name: attachment_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.attachment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.attachment_id_seq OWNER TO postgres;

--
-- Name: attachment_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.attachment_id_seq OWNED BY gtestschema.attachment.id;


--
-- Name: collaboration; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.collaboration (
    id bigint NOT NULL,
    repo_id bigint NOT NULL,
    user_id bigint NOT NULL,
    mode integer DEFAULT 2 NOT NULL
);


ALTER TABLE gtestschema.collaboration OWNER TO postgres;

--
-- Name: collaboration_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.collaboration_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.collaboration_id_seq OWNER TO postgres;

--
-- Name: collaboration_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.collaboration_id_seq OWNED BY gtestschema.collaboration.id;


--
-- Name: comment; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.comment (
    id bigint NOT NULL,
    type integer,
    poster_id bigint,
    issue_id bigint,
    label_id bigint,
    old_milestone_id bigint,
    milestone_id bigint,
    assignee_id bigint,
    removed_assignee boolean,
    old_title character varying(255),
    new_title character varying(255),
    commit_id bigint,
    line bigint,
    content text,
    created_unix bigint,
    updated_unix bigint,
    commit_sha character varying(40)
);


ALTER TABLE gtestschema.comment OWNER TO postgres;

--
-- Name: comment_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.comment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.comment_id_seq OWNER TO postgres;

--
-- Name: comment_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.comment_id_seq OWNED BY gtestschema.comment.id;


--
-- Name: commit_status; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.commit_status (
    id bigint NOT NULL,
    index bigint,
    repo_id bigint,
    state character varying(7) NOT NULL,
    sha character varying(64) NOT NULL,
    target_url text,
    description text,
    context text,
    creator_id bigint,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE gtestschema.commit_status OWNER TO postgres;

--
-- Name: commit_status_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.commit_status_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.commit_status_id_seq OWNER TO postgres;

--
-- Name: commit_status_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.commit_status_id_seq OWNED BY gtestschema.commit_status.id;


--
-- Name: deleted_branch; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.deleted_branch (
    id bigint NOT NULL,
    repo_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    commit character varying(255) NOT NULL,
    deleted_by_id bigint,
    deleted_unix bigint
);


ALTER TABLE gtestschema.deleted_branch OWNER TO postgres;

--
-- Name: deleted_branch_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.deleted_branch_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.deleted_branch_id_seq OWNER TO postgres;

--
-- Name: deleted_branch_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.deleted_branch_id_seq OWNED BY gtestschema.deleted_branch.id;


--
-- Name: deploy_key; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.deploy_key (
    id bigint NOT NULL,
    key_id bigint,
    repo_id bigint,
    name character varying(255),
    fingerprint character varying(255),
    mode integer DEFAULT 1 NOT NULL,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE gtestschema.deploy_key OWNER TO postgres;

--
-- Name: deploy_key_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.deploy_key_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.deploy_key_id_seq OWNER TO postgres;

--
-- Name: deploy_key_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.deploy_key_id_seq OWNED BY gtestschema.deploy_key.id;


--
-- Name: email_address; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.email_address (
    id bigint NOT NULL,
    uid bigint NOT NULL,
    email character varying(255) NOT NULL,
    is_activated boolean
);


ALTER TABLE gtestschema.email_address OWNER TO postgres;

--
-- Name: email_address_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.email_address_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.email_address_id_seq OWNER TO postgres;

--
-- Name: email_address_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.email_address_id_seq OWNED BY gtestschema.email_address.id;


--
-- Name: external_login_user; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.external_login_user (
    external_id character varying(255) NOT NULL,
    user_id bigint NOT NULL,
    login_source_id bigint NOT NULL
);


ALTER TABLE gtestschema.external_login_user OWNER TO postgres;

--
-- Name: follow; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.follow (
    id bigint NOT NULL,
    user_id bigint,
    follow_id bigint
);


ALTER TABLE gtestschema.follow OWNER TO postgres;

--
-- Name: follow_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.follow_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.follow_id_seq OWNER TO postgres;

--
-- Name: follow_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.follow_id_seq OWNED BY gtestschema.follow.id;


--
-- Name: gpg_key; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.gpg_key (
    id bigint NOT NULL,
    owner_id bigint NOT NULL,
    key_id character(16) NOT NULL,
    primary_key_id character(16),
    content text NOT NULL,
    created_unix bigint,
    expired_unix bigint,
    added_unix bigint,
    emails text,
    can_sign boolean,
    can_encrypt_comms boolean,
    can_encrypt_storage boolean,
    can_certify boolean
);


ALTER TABLE gtestschema.gpg_key OWNER TO postgres;

--
-- Name: gpg_key_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.gpg_key_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.gpg_key_id_seq OWNER TO postgres;

--
-- Name: gpg_key_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.gpg_key_id_seq OWNED BY gtestschema.gpg_key.id;


--
-- Name: hook_task; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.hook_task (
    id bigint NOT NULL,
    repo_id bigint,
    hook_id bigint,
    uuid character varying(255),
    type integer,
    url text,
    payload_content text,
    content_type integer,
    event_type character varying(255),
    is_ssl boolean,
    is_delivered boolean,
    delivered bigint,
    is_succeed boolean,
    request_content text,
    response_content text
);


ALTER TABLE gtestschema.hook_task OWNER TO postgres;

--
-- Name: hook_task_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.hook_task_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.hook_task_id_seq OWNER TO postgres;

--
-- Name: hook_task_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.hook_task_id_seq OWNED BY gtestschema.hook_task.id;


--
-- Name: issue; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.issue (
    id bigint NOT NULL,
    repo_id bigint,
    index bigint,
    poster_id bigint,
    name character varying(255),
    content text,
    milestone_id bigint,
    priority integer,
    is_closed boolean,
    is_pull boolean,
    num_comments integer,
    ref character varying(255),
    deadline_unix bigint,
    created_unix bigint,
    updated_unix bigint,
    closed_unix bigint
);


ALTER TABLE gtestschema.issue OWNER TO postgres;

--
-- Name: issue_assignees; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.issue_assignees (
    id bigint NOT NULL,
    assignee_id bigint,
    issue_id bigint
);


ALTER TABLE gtestschema.issue_assignees OWNER TO postgres;

--
-- Name: issue_assignees_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.issue_assignees_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.issue_assignees_id_seq OWNER TO postgres;

--
-- Name: issue_assignees_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.issue_assignees_id_seq OWNED BY gtestschema.issue_assignees.id;


--
-- Name: issue_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.issue_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.issue_id_seq OWNER TO postgres;

--
-- Name: issue_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.issue_id_seq OWNED BY gtestschema.issue.id;


--
-- Name: issue_label; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.issue_label (
    id bigint NOT NULL,
    issue_id bigint,
    label_id bigint
);


ALTER TABLE gtestschema.issue_label OWNER TO postgres;

--
-- Name: issue_label_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.issue_label_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.issue_label_id_seq OWNER TO postgres;

--
-- Name: issue_label_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.issue_label_id_seq OWNED BY gtestschema.issue_label.id;


--
-- Name: issue_user; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.issue_user (
    id bigint NOT NULL,
    uid bigint,
    issue_id bigint,
    is_read boolean,
    is_mentioned boolean
);


ALTER TABLE gtestschema.issue_user OWNER TO postgres;

--
-- Name: issue_user_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.issue_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.issue_user_id_seq OWNER TO postgres;

--
-- Name: issue_user_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.issue_user_id_seq OWNED BY gtestschema.issue_user.id;


--
-- Name: issue_watch; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.issue_watch (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    issue_id bigint NOT NULL,
    is_watching boolean NOT NULL,
    created_unix bigint NOT NULL,
    updated_unix bigint NOT NULL
);


ALTER TABLE gtestschema.issue_watch OWNER TO postgres;

--
-- Name: issue_watch_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.issue_watch_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.issue_watch_id_seq OWNER TO postgres;

--
-- Name: issue_watch_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.issue_watch_id_seq OWNED BY gtestschema.issue_watch.id;


--
-- Name: label; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.label (
    id bigint NOT NULL,
    repo_id bigint,
    name character varying(255),
    description character varying(255),
    color character varying(7),
    num_issues integer,
    num_closed_issues integer
);


ALTER TABLE gtestschema.label OWNER TO postgres;

--
-- Name: label_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.label_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.label_id_seq OWNER TO postgres;

--
-- Name: label_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.label_id_seq OWNED BY gtestschema.label.id;


--
-- Name: lfs_lock; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.lfs_lock (
    id bigint NOT NULL,
    repo_id bigint NOT NULL,
    owner_id bigint NOT NULL,
    path text,
    created timestamp without time zone
);


ALTER TABLE gtestschema.lfs_lock OWNER TO postgres;

--
-- Name: lfs_lock_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.lfs_lock_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.lfs_lock_id_seq OWNER TO postgres;

--
-- Name: lfs_lock_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.lfs_lock_id_seq OWNED BY gtestschema.lfs_lock.id;


--
-- Name: lfs_meta_object; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.lfs_meta_object (
    id bigint NOT NULL,
    oid character varying(255) NOT NULL,
    size bigint NOT NULL,
    repository_id bigint NOT NULL,
    created_unix bigint
);


ALTER TABLE gtestschema.lfs_meta_object OWNER TO postgres;

--
-- Name: lfs_meta_object_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.lfs_meta_object_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.lfs_meta_object_id_seq OWNER TO postgres;

--
-- Name: lfs_meta_object_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.lfs_meta_object_id_seq OWNED BY gtestschema.lfs_meta_object.id;


--
-- Name: login_source; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.login_source (
    id bigint NOT NULL,
    type integer,
    name character varying(255),
    is_actived boolean DEFAULT false NOT NULL,
    is_sync_enabled boolean DEFAULT false NOT NULL,
    cfg text,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE gtestschema.login_source OWNER TO postgres;

--
-- Name: login_source_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.login_source_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.login_source_id_seq OWNER TO postgres;

--
-- Name: login_source_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.login_source_id_seq OWNED BY gtestschema.login_source.id;


--
-- Name: milestone; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.milestone (
    id bigint NOT NULL,
    repo_id bigint,
    name character varying(255),
    content text,
    is_closed boolean,
    num_issues integer,
    num_closed_issues integer,
    completeness integer,
    deadline_unix bigint,
    closed_date_unix bigint
);


ALTER TABLE gtestschema.milestone OWNER TO postgres;

--
-- Name: milestone_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.milestone_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.milestone_id_seq OWNER TO postgres;

--
-- Name: milestone_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.milestone_id_seq OWNED BY gtestschema.milestone.id;


--
-- Name: mirror; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.mirror (
    id bigint NOT NULL,
    repo_id bigint,
    "interval" bigint,
    enable_prune boolean DEFAULT true NOT NULL,
    updated_unix bigint,
    next_update_unix bigint
);


ALTER TABLE gtestschema.mirror OWNER TO postgres;

--
-- Name: mirror_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.mirror_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.mirror_id_seq OWNER TO postgres;

--
-- Name: mirror_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.mirror_id_seq OWNED BY gtestschema.mirror.id;


--
-- Name: notice; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.notice (
    id bigint NOT NULL,
    type integer,
    description text,
    created_unix bigint
);


ALTER TABLE gtestschema.notice OWNER TO postgres;

--
-- Name: notice_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.notice_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.notice_id_seq OWNER TO postgres;

--
-- Name: notice_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.notice_id_seq OWNED BY gtestschema.notice.id;


--
-- Name: notification; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.notification (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    repo_id bigint NOT NULL,
    status smallint NOT NULL,
    source smallint NOT NULL,
    issue_id bigint NOT NULL,
    commit_id character varying(255),
    updated_by bigint NOT NULL,
    created_unix bigint NOT NULL,
    updated_unix bigint NOT NULL
);


ALTER TABLE gtestschema.notification OWNER TO postgres;

--
-- Name: notification_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.notification_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.notification_id_seq OWNER TO postgres;

--
-- Name: notification_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.notification_id_seq OWNED BY gtestschema.notification.id;


--
-- Name: oauth2_session; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.oauth2_session (
    id character varying(100) NOT NULL,
    data text,
    created_unix bigint,
    updated_unix bigint,
    expires_unix bigint
);


ALTER TABLE gtestschema.oauth2_session OWNER TO postgres;

--
-- Name: org_user; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.org_user (
    id bigint NOT NULL,
    uid bigint,
    org_id bigint,
    is_public boolean
);


ALTER TABLE gtestschema.org_user OWNER TO postgres;

--
-- Name: org_user_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.org_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.org_user_id_seq OWNER TO postgres;

--
-- Name: org_user_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.org_user_id_seq OWNED BY gtestschema.org_user.id;


--
-- Name: protected_branch; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.protected_branch (
    id bigint NOT NULL,
    repo_id bigint,
    branch_name character varying(255),
    can_push boolean DEFAULT false NOT NULL,
    enable_whitelist boolean,
    whitelist_user_i_ds text,
    whitelist_team_i_ds text,
    enable_merge_whitelist boolean DEFAULT false NOT NULL,
    merge_whitelist_user_i_ds text,
    merge_whitelist_team_i_ds text,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE gtestschema.protected_branch OWNER TO postgres;

--
-- Name: protected_branch_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.protected_branch_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.protected_branch_id_seq OWNER TO postgres;

--
-- Name: protected_branch_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.protected_branch_id_seq OWNED BY gtestschema.protected_branch.id;


--
-- Name: public_key; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.public_key (
    id bigint NOT NULL,
    owner_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    fingerprint character varying(255) NOT NULL,
    content text NOT NULL,
    mode integer DEFAULT 2 NOT NULL,
    type integer DEFAULT 1 NOT NULL,
    login_source_id bigint DEFAULT 0 NOT NULL,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE gtestschema.public_key OWNER TO postgres;

--
-- Name: public_key_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.public_key_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.public_key_id_seq OWNER TO postgres;

--
-- Name: public_key_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.public_key_id_seq OWNED BY gtestschema.public_key.id;


--
-- Name: pull_request; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.pull_request (
    id bigint NOT NULL,
    type integer,
    status integer,
    issue_id bigint,
    index bigint,
    head_repo_id bigint,
    base_repo_id bigint,
    head_user_name character varying(255),
    head_branch character varying(255),
    base_branch character varying(255),
    merge_base character varying(40),
    has_merged boolean,
    merged_commit_id character varying(40),
    merger_id bigint,
    merged_unix bigint
);


ALTER TABLE gtestschema.pull_request OWNER TO postgres;

--
-- Name: pull_request_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.pull_request_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.pull_request_id_seq OWNER TO postgres;

--
-- Name: pull_request_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.pull_request_id_seq OWNED BY gtestschema.pull_request.id;


--
-- Name: reaction; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.reaction (
    id bigint NOT NULL,
    type character varying(255) NOT NULL,
    issue_id bigint NOT NULL,
    comment_id bigint,
    user_id bigint NOT NULL,
    created_unix bigint
);


ALTER TABLE gtestschema.reaction OWNER TO postgres;

--
-- Name: reaction_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.reaction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.reaction_id_seq OWNER TO postgres;

--
-- Name: reaction_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.reaction_id_seq OWNED BY gtestschema.reaction.id;


--
-- Name: release; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.release (
    id bigint NOT NULL,
    repo_id bigint,
    publisher_id bigint,
    tag_name character varying(255),
    lower_tag_name character varying(255),
    target character varying(255),
    title character varying(255),
    sha1 character varying(40),
    num_commits bigint,
    note text,
    is_draft boolean DEFAULT false NOT NULL,
    is_prerelease boolean DEFAULT false NOT NULL,
    is_tag boolean DEFAULT false NOT NULL,
    created_unix bigint
);


ALTER TABLE gtestschema.release OWNER TO postgres;

--
-- Name: release_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.release_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.release_id_seq OWNER TO postgres;

--
-- Name: release_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.release_id_seq OWNED BY gtestschema.release.id;


--
-- Name: repo_indexer_status; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.repo_indexer_status (
    id bigint NOT NULL,
    repo_id bigint,
    commit_sha character varying(40)
);


ALTER TABLE gtestschema.repo_indexer_status OWNER TO postgres;

--
-- Name: repo_indexer_status_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.repo_indexer_status_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.repo_indexer_status_id_seq OWNER TO postgres;

--
-- Name: repo_indexer_status_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.repo_indexer_status_id_seq OWNED BY gtestschema.repo_indexer_status.id;


--
-- Name: repo_redirect; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.repo_redirect (
    id bigint NOT NULL,
    owner_id bigint,
    lower_name character varying(255) NOT NULL,
    redirect_repo_id bigint
);


ALTER TABLE gtestschema.repo_redirect OWNER TO postgres;

--
-- Name: repo_redirect_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.repo_redirect_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.repo_redirect_id_seq OWNER TO postgres;

--
-- Name: repo_redirect_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.repo_redirect_id_seq OWNED BY gtestschema.repo_redirect.id;


--
-- Name: repo_topic; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.repo_topic (
    repo_id bigint,
    topic_id bigint
);


ALTER TABLE gtestschema.repo_topic OWNER TO postgres;

--
-- Name: repo_unit; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.repo_unit (
    id bigint NOT NULL,
    repo_id bigint,
    type integer,
    config text,
    created_unix bigint
);


ALTER TABLE gtestschema.repo_unit OWNER TO postgres;

--
-- Name: repo_unit_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.repo_unit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.repo_unit_id_seq OWNER TO postgres;

--
-- Name: repo_unit_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.repo_unit_id_seq OWNED BY gtestschema.repo_unit.id;


--
-- Name: repository; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.repository (
    id bigint NOT NULL,
    owner_id bigint,
    lower_name character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255),
    website character varying(255),
    default_branch character varying(255),
    num_watches integer,
    num_stars integer,
    num_forks integer,
    num_issues integer,
    num_closed_issues integer,
    num_pulls integer,
    num_closed_pulls integer,
    num_milestones integer DEFAULT 0 NOT NULL,
    num_closed_milestones integer DEFAULT 0 NOT NULL,
    is_private boolean,
    is_bare boolean,
    is_mirror boolean,
    is_fork boolean DEFAULT false NOT NULL,
    fork_id bigint,
    size bigint DEFAULT 0 NOT NULL,
    is_fsck_enabled boolean DEFAULT true NOT NULL,
    topics json,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE gtestschema.repository OWNER TO postgres;

--
-- Name: repository_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.repository_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.repository_id_seq OWNER TO postgres;

--
-- Name: repository_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.repository_id_seq OWNED BY gtestschema.repository.id;


--
-- Name: star; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.star (
    id bigint NOT NULL,
    uid bigint,
    repo_id bigint
);


ALTER TABLE gtestschema.star OWNER TO postgres;

--
-- Name: star_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.star_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.star_id_seq OWNER TO postgres;

--
-- Name: star_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.star_id_seq OWNED BY gtestschema.star.id;


--
-- Name: stopwatch; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.stopwatch (
    id bigint NOT NULL,
    issue_id bigint,
    user_id bigint,
    created_unix bigint
);


ALTER TABLE gtestschema.stopwatch OWNER TO postgres;

--
-- Name: stopwatch_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.stopwatch_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.stopwatch_id_seq OWNER TO postgres;

--
-- Name: stopwatch_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.stopwatch_id_seq OWNED BY gtestschema.stopwatch.id;


--
-- Name: team; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.team (
    id bigint NOT NULL,
    org_id bigint,
    lower_name character varying(255),
    name character varying(255),
    description character varying(255),
    authorize integer,
    num_repos integer,
    num_members integer
);


ALTER TABLE gtestschema.team OWNER TO postgres;

--
-- Name: team_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.team_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.team_id_seq OWNER TO postgres;

--
-- Name: team_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.team_id_seq OWNED BY gtestschema.team.id;


--
-- Name: team_repo; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.team_repo (
    id bigint NOT NULL,
    org_id bigint,
    team_id bigint,
    repo_id bigint
);


ALTER TABLE gtestschema.team_repo OWNER TO postgres;

--
-- Name: team_repo_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.team_repo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.team_repo_id_seq OWNER TO postgres;

--
-- Name: team_repo_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.team_repo_id_seq OWNED BY gtestschema.team_repo.id;


--
-- Name: team_unit; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.team_unit (
    id bigint NOT NULL,
    org_id bigint,
    team_id bigint,
    type integer
);


ALTER TABLE gtestschema.team_unit OWNER TO postgres;

--
-- Name: team_unit_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.team_unit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.team_unit_id_seq OWNER TO postgres;

--
-- Name: team_unit_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.team_unit_id_seq OWNED BY gtestschema.team_unit.id;


--
-- Name: team_user; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.team_user (
    id bigint NOT NULL,
    org_id bigint,
    team_id bigint,
    uid bigint
);


ALTER TABLE gtestschema.team_user OWNER TO postgres;

--
-- Name: team_user_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.team_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.team_user_id_seq OWNER TO postgres;

--
-- Name: team_user_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.team_user_id_seq OWNED BY gtestschema.team_user.id;


--
-- Name: topic; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.topic (
    id bigint NOT NULL,
    name character varying(255),
    repo_count integer,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE gtestschema.topic OWNER TO postgres;

--
-- Name: topic_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.topic_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.topic_id_seq OWNER TO postgres;

--
-- Name: topic_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.topic_id_seq OWNED BY gtestschema.topic.id;


--
-- Name: tracked_time; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.tracked_time (
    id bigint NOT NULL,
    issue_id bigint,
    user_id bigint,
    created_unix bigint,
    "time" bigint
);


ALTER TABLE gtestschema.tracked_time OWNER TO postgres;

--
-- Name: tracked_time_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.tracked_time_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.tracked_time_id_seq OWNER TO postgres;

--
-- Name: tracked_time_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.tracked_time_id_seq OWNED BY gtestschema.tracked_time.id;


--
-- Name: two_factor; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.two_factor (
    id bigint NOT NULL,
    uid bigint,
    secret character varying(255),
    scratch_token character varying(255),
    last_used_passcode character varying(10),
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE gtestschema.two_factor OWNER TO postgres;

--
-- Name: two_factor_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.two_factor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.two_factor_id_seq OWNER TO postgres;

--
-- Name: two_factor_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.two_factor_id_seq OWNED BY gtestschema.two_factor.id;


--
-- Name: u2f_registration; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.u2f_registration (
    id bigint NOT NULL,
    name character varying(255),
    user_id bigint,
    raw bytea,
    counter integer,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE gtestschema.u2f_registration OWNER TO postgres;

--
-- Name: u2f_registration_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.u2f_registration_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.u2f_registration_id_seq OWNER TO postgres;

--
-- Name: u2f_registration_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.u2f_registration_id_seq OWNED BY gtestschema.u2f_registration.id;


--
-- Name: upload; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.upload (
    id bigint NOT NULL,
    uuid uuid,
    name character varying(255)
);


ALTER TABLE gtestschema.upload OWNER TO postgres;

--
-- Name: upload_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.upload_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.upload_id_seq OWNER TO postgres;

--
-- Name: upload_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.upload_id_seq OWNED BY gtestschema.upload.id;


--
-- Name: user; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema."user" (
    id bigint NOT NULL,
    lower_name character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    full_name character varying(255),
    email character varying(255) NOT NULL,
    keep_email_private boolean,
    passwd character varying(255) NOT NULL,
    login_type integer,
    login_source bigint DEFAULT 0 NOT NULL,
    login_name character varying(255),
    type integer,
    location character varying(255),
    website character varying(255),
    rands character varying(10),
    salt character varying(10),
    language character varying(5),
    created_unix bigint,
    updated_unix bigint,
    last_login_unix bigint,
    last_repo_visibility boolean,
    max_repo_creation integer DEFAULT '-1'::integer NOT NULL,
    is_active boolean,
    is_admin boolean,
    allow_git_hook boolean,
    allow_import_local boolean,
    allow_create_organization boolean DEFAULT true,
    prohibit_login boolean DEFAULT false NOT NULL,
    avatar character varying(2048) NOT NULL,
    avatar_email character varying(255) NOT NULL,
    use_custom_avatar boolean,
    num_followers integer,
    num_following integer DEFAULT 0 NOT NULL,
    num_stars integer,
    num_repos integer,
    description character varying(255),
    num_teams integer,
    num_members integer,
    diff_view_style character varying(255) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE gtestschema."user" OWNER TO postgres;

--
-- Name: user_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.user_id_seq OWNER TO postgres;

--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.user_id_seq OWNED BY gtestschema."user".id;


--
-- Name: user_open_id; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.user_open_id (
    id bigint NOT NULL,
    uid bigint NOT NULL,
    uri character varying(255) NOT NULL,
    show boolean DEFAULT false
);


ALTER TABLE gtestschema.user_open_id OWNER TO postgres;

--
-- Name: user_open_id_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.user_open_id_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.user_open_id_id_seq OWNER TO postgres;

--
-- Name: user_open_id_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.user_open_id_id_seq OWNED BY gtestschema.user_open_id.id;


--
-- Name: version; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.version (
    id bigint NOT NULL,
    version bigint
);


ALTER TABLE gtestschema.version OWNER TO postgres;

--
-- Name: version_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.version_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.version_id_seq OWNER TO postgres;

--
-- Name: version_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.version_id_seq OWNED BY gtestschema.version.id;


--
-- Name: watch; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.watch (
    id bigint NOT NULL,
    user_id bigint,
    repo_id bigint
);


ALTER TABLE gtestschema.watch OWNER TO postgres;

--
-- Name: watch_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.watch_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.watch_id_seq OWNER TO postgres;

--
-- Name: watch_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.watch_id_seq OWNED BY gtestschema.watch.id;


--
-- Name: webhook; Type: TABLE; Schema: gtestschema; Owner: postgres
--

CREATE TABLE gtestschema.webhook (
    id bigint NOT NULL,
    repo_id bigint,
    org_id bigint,
    url text,
    content_type integer,
    secret text,
    events text,
    is_ssl boolean,
    is_active boolean,
    hook_task_type integer,
    meta text,
    last_status integer,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE gtestschema.webhook OWNER TO postgres;

--
-- Name: webhook_id_seq; Type: SEQUENCE; Schema: gtestschema; Owner: postgres
--

CREATE SEQUENCE gtestschema.webhook_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gtestschema.webhook_id_seq OWNER TO postgres;

--
-- Name: webhook_id_seq; Type: SEQUENCE OWNED BY; Schema: gtestschema; Owner: postgres
--

ALTER SEQUENCE gtestschema.webhook_id_seq OWNED BY gtestschema.webhook.id;


--
-- Name: access id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.access ALTER COLUMN id SET DEFAULT nextval('gtestschema.access_id_seq'::regclass);


--
-- Name: access_token id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.access_token ALTER COLUMN id SET DEFAULT nextval('gtestschema.access_token_id_seq'::regclass);


--
-- Name: action id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.action ALTER COLUMN id SET DEFAULT nextval('gtestschema.action_id_seq'::regclass);


--
-- Name: attachment id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.attachment ALTER COLUMN id SET DEFAULT nextval('gtestschema.attachment_id_seq'::regclass);


--
-- Name: collaboration id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.collaboration ALTER COLUMN id SET DEFAULT nextval('gtestschema.collaboration_id_seq'::regclass);


--
-- Name: comment id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.comment ALTER COLUMN id SET DEFAULT nextval('gtestschema.comment_id_seq'::regclass);


--
-- Name: commit_status id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.commit_status ALTER COLUMN id SET DEFAULT nextval('gtestschema.commit_status_id_seq'::regclass);


--
-- Name: deleted_branch id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.deleted_branch ALTER COLUMN id SET DEFAULT nextval('gtestschema.deleted_branch_id_seq'::regclass);


--
-- Name: deploy_key id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.deploy_key ALTER COLUMN id SET DEFAULT nextval('gtestschema.deploy_key_id_seq'::regclass);


--
-- Name: email_address id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.email_address ALTER COLUMN id SET DEFAULT nextval('gtestschema.email_address_id_seq'::regclass);


--
-- Name: follow id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.follow ALTER COLUMN id SET DEFAULT nextval('gtestschema.follow_id_seq'::regclass);


--
-- Name: gpg_key id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.gpg_key ALTER COLUMN id SET DEFAULT nextval('gtestschema.gpg_key_id_seq'::regclass);


--
-- Name: hook_task id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.hook_task ALTER COLUMN id SET DEFAULT nextval('gtestschema.hook_task_id_seq'::regclass);


--
-- Name: issue id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.issue ALTER COLUMN id SET DEFAULT nextval('gtestschema.issue_id_seq'::regclass);


--
-- Name: issue_assignees id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.issue_assignees ALTER COLUMN id SET DEFAULT nextval('gtestschema.issue_assignees_id_seq'::regclass);


--
-- Name: issue_label id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.issue_label ALTER COLUMN id SET DEFAULT nextval('gtestschema.issue_label_id_seq'::regclass);


--
-- Name: issue_user id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.issue_user ALTER COLUMN id SET DEFAULT nextval('gtestschema.issue_user_id_seq'::regclass);


--
-- Name: issue_watch id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.issue_watch ALTER COLUMN id SET DEFAULT nextval('gtestschema.issue_watch_id_seq'::regclass);


--
-- Name: label id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.label ALTER COLUMN id SET DEFAULT nextval('gtestschema.label_id_seq'::regclass);


--
-- Name: lfs_lock id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.lfs_lock ALTER COLUMN id SET DEFAULT nextval('gtestschema.lfs_lock_id_seq'::regclass);


--
-- Name: lfs_meta_object id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.lfs_meta_object ALTER COLUMN id SET DEFAULT nextval('gtestschema.lfs_meta_object_id_seq'::regclass);


--
-- Name: login_source id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.login_source ALTER COLUMN id SET DEFAULT nextval('gtestschema.login_source_id_seq'::regclass);


--
-- Name: milestone id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.milestone ALTER COLUMN id SET DEFAULT nextval('gtestschema.milestone_id_seq'::regclass);


--
-- Name: mirror id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.mirror ALTER COLUMN id SET DEFAULT nextval('gtestschema.mirror_id_seq'::regclass);


--
-- Name: notice id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.notice ALTER COLUMN id SET DEFAULT nextval('gtestschema.notice_id_seq'::regclass);


--
-- Name: notification id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.notification ALTER COLUMN id SET DEFAULT nextval('gtestschema.notification_id_seq'::regclass);


--
-- Name: org_user id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.org_user ALTER COLUMN id SET DEFAULT nextval('gtestschema.org_user_id_seq'::regclass);


--
-- Name: protected_branch id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.protected_branch ALTER COLUMN id SET DEFAULT nextval('gtestschema.protected_branch_id_seq'::regclass);


--
-- Name: public_key id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.public_key ALTER COLUMN id SET DEFAULT nextval('gtestschema.public_key_id_seq'::regclass);


--
-- Name: pull_request id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.pull_request ALTER COLUMN id SET DEFAULT nextval('gtestschema.pull_request_id_seq'::regclass);


--
-- Name: reaction id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.reaction ALTER COLUMN id SET DEFAULT nextval('gtestschema.reaction_id_seq'::regclass);


--
-- Name: release id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.release ALTER COLUMN id SET DEFAULT nextval('gtestschema.release_id_seq'::regclass);


--
-- Name: repo_indexer_status id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.repo_indexer_status ALTER COLUMN id SET DEFAULT nextval('gtestschema.repo_indexer_status_id_seq'::regclass);


--
-- Name: repo_redirect id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.repo_redirect ALTER COLUMN id SET DEFAULT nextval('gtestschema.repo_redirect_id_seq'::regclass);


--
-- Name: repo_unit id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.repo_unit ALTER COLUMN id SET DEFAULT nextval('gtestschema.repo_unit_id_seq'::regclass);


--
-- Name: repository id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.repository ALTER COLUMN id SET DEFAULT nextval('gtestschema.repository_id_seq'::regclass);


--
-- Name: star id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.star ALTER COLUMN id SET DEFAULT nextval('gtestschema.star_id_seq'::regclass);


--
-- Name: stopwatch id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.stopwatch ALTER COLUMN id SET DEFAULT nextval('gtestschema.stopwatch_id_seq'::regclass);


--
-- Name: team id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.team ALTER COLUMN id SET DEFAULT nextval('gtestschema.team_id_seq'::regclass);


--
-- Name: team_repo id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.team_repo ALTER COLUMN id SET DEFAULT nextval('gtestschema.team_repo_id_seq'::regclass);


--
-- Name: team_unit id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.team_unit ALTER COLUMN id SET DEFAULT nextval('gtestschema.team_unit_id_seq'::regclass);


--
-- Name: team_user id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.team_user ALTER COLUMN id SET DEFAULT nextval('gtestschema.team_user_id_seq'::regclass);


--
-- Name: topic id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.topic ALTER COLUMN id SET DEFAULT nextval('gtestschema.topic_id_seq'::regclass);


--
-- Name: tracked_time id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.tracked_time ALTER COLUMN id SET DEFAULT nextval('gtestschema.tracked_time_id_seq'::regclass);


--
-- Name: two_factor id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.two_factor ALTER COLUMN id SET DEFAULT nextval('gtestschema.two_factor_id_seq'::regclass);


--
-- Name: u2f_registration id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.u2f_registration ALTER COLUMN id SET DEFAULT nextval('gtestschema.u2f_registration_id_seq'::regclass);


--
-- Name: upload id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.upload ALTER COLUMN id SET DEFAULT nextval('gtestschema.upload_id_seq'::regclass);


--
-- Name: user id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema."user" ALTER COLUMN id SET DEFAULT nextval('gtestschema.user_id_seq'::regclass);


--
-- Name: user_open_id id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.user_open_id ALTER COLUMN id SET DEFAULT nextval('gtestschema.user_open_id_id_seq'::regclass);


--
-- Name: version id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.version ALTER COLUMN id SET DEFAULT nextval('gtestschema.version_id_seq'::regclass);


--
-- Name: watch id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.watch ALTER COLUMN id SET DEFAULT nextval('gtestschema.watch_id_seq'::regclass);


--
-- Name: webhook id; Type: DEFAULT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.webhook ALTER COLUMN id SET DEFAULT nextval('gtestschema.webhook_id_seq'::regclass);


--
-- Data for Name: access; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.access (id, user_id, repo_id, mode) VALUES (1, 2, 3, 2);
INSERT INTO gtestschema.access (id, user_id, repo_id, mode) VALUES (2, 4, 4, 2);
INSERT INTO gtestschema.access (id, user_id, repo_id, mode) VALUES (3, 4, 3, 2);
INSERT INTO gtestschema.access (id, user_id, repo_id, mode) VALUES (4, 15, 22, 2);
INSERT INTO gtestschema.access (id, user_id, repo_id, mode) VALUES (5, 15, 21, 2);
INSERT INTO gtestschema.access (id, user_id, repo_id, mode) VALUES (6, 15, 23, 4);
INSERT INTO gtestschema.access (id, user_id, repo_id, mode) VALUES (7, 15, 24, 4);
INSERT INTO gtestschema.access (id, user_id, repo_id, mode) VALUES (8, 18, 23, 4);
INSERT INTO gtestschema.access (id, user_id, repo_id, mode) VALUES (9, 18, 24, 4);
INSERT INTO gtestschema.access (id, user_id, repo_id, mode) VALUES (10, 18, 22, 2);
INSERT INTO gtestschema.access (id, user_id, repo_id, mode) VALUES (11, 18, 21, 2);
INSERT INTO gtestschema.access (id, user_id, repo_id, mode) VALUES (12, 20, 27, 4);
INSERT INTO gtestschema.access (id, user_id, repo_id, mode) VALUES (13, 20, 28, 4);


--
-- Data for Name: access_token; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.access_token (id, uid, name, sha1, created_unix, updated_unix) VALUES (1, 1, 'Token A', 'hash1', 946687980, 946687980);
INSERT INTO gtestschema.access_token (id, uid, name, sha1, created_unix, updated_unix) VALUES (2, 1, 'Token B', 'hash2', 946687980, 946687980);
INSERT INTO gtestschema.access_token (id, uid, name, sha1, created_unix, updated_unix) VALUES (3, 2, 'Token A', 'hash3', 946687980, 946687980);


--
-- Data for Name: action; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.action (id, user_id, op_type, act_user_id, repo_id, comment_id, is_deleted, ref_name, is_private, content, created_unix) VALUES (1, 2, 12, 2, 2, NULL, false, NULL, true, NULL, NULL);
INSERT INTO gtestschema.action (id, user_id, op_type, act_user_id, repo_id, comment_id, is_deleted, ref_name, is_private, content, created_unix) VALUES (2, 3, 2, 2, 3, NULL, false, NULL, true, 'oldRepoName', NULL);
INSERT INTO gtestschema.action (id, user_id, op_type, act_user_id, repo_id, comment_id, is_deleted, ref_name, is_private, content, created_unix) VALUES (3, 11, 1, 11, 9, NULL, false, NULL, false, NULL, NULL);


--
-- Data for Name: attachment; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.attachment (id, uuid, issue_id, release_id, comment_id, name, download_count, size, created_unix) VALUES (1, 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 1, NULL, 0, 'attach1', 0, 0, 946684800);
INSERT INTO gtestschema.attachment (id, uuid, issue_id, release_id, comment_id, name, download_count, size, created_unix) VALUES (2, 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', 1, NULL, 0, 'attach2', 1, 0, 946684800);
INSERT INTO gtestschema.attachment (id, uuid, issue_id, release_id, comment_id, name, download_count, size, created_unix) VALUES (3, 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a13', 2, NULL, 1, 'attach1', 0, 0, 946684800);
INSERT INTO gtestschema.attachment (id, uuid, issue_id, release_id, comment_id, name, download_count, size, created_unix) VALUES (4, 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a14', 3, NULL, 1, 'attach2', 1, 0, 946684800);
INSERT INTO gtestschema.attachment (id, uuid, issue_id, release_id, comment_id, name, download_count, size, created_unix) VALUES (5, 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a15', 4, NULL, 0, 'attach1', 0, 0, 946684800);
INSERT INTO gtestschema.attachment (id, uuid, issue_id, release_id, comment_id, name, download_count, size, created_unix) VALUES (6, 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a16', 5, NULL, 2, 'attach1', 0, 0, 946684800);
INSERT INTO gtestschema.attachment (id, uuid, issue_id, release_id, comment_id, name, download_count, size, created_unix) VALUES (7, 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a17', 5, NULL, 2, 'attach1', 0, 0, 946684800);
INSERT INTO gtestschema.attachment (id, uuid, issue_id, release_id, comment_id, name, download_count, size, created_unix) VALUES (8, 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a18', 6, NULL, 0, 'attach1', 0, 0, 946684800);


--
-- Data for Name: collaboration; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.collaboration (id, repo_id, user_id, mode) VALUES (1, 3, 2, 2);
INSERT INTO gtestschema.collaboration (id, repo_id, user_id, mode) VALUES (2, 4, 4, 2);


--
-- Data for Name: comment; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.comment (id, type, poster_id, issue_id, label_id, old_milestone_id, milestone_id, assignee_id, removed_assignee, old_title, new_title, commit_id, line, content, created_unix, updated_unix, commit_sha) VALUES (1, 7, 2, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 946684810, NULL, NULL);
INSERT INTO gtestschema.comment (id, type, poster_id, issue_id, label_id, old_milestone_id, milestone_id, assignee_id, removed_assignee, old_title, new_title, commit_id, line, content, created_unix, updated_unix, commit_sha) VALUES (2, 0, 3, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'good work!', 946684811, NULL, NULL);
INSERT INTO gtestschema.comment (id, type, poster_id, issue_id, label_id, old_milestone_id, milestone_id, assignee_id, removed_assignee, old_title, new_title, commit_id, line, content, created_unix, updated_unix, commit_sha) VALUES (3, 0, 5, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'meh...', 946684812, NULL, NULL);


--
-- Data for Name: commit_status; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.commit_status (id, index, repo_id, state, sha, target_url, description, context, creator_id, created_unix, updated_unix) VALUES (1, 1, 1, 'pending', '1234123412341234123412341234123412341234', 'https://example.com/builds/', 'My awesome CI-service', 'ci/awesomeness', 2, NULL, NULL);
INSERT INTO gtestschema.commit_status (id, index, repo_id, state, sha, target_url, description, context, creator_id, created_unix, updated_unix) VALUES (2, 2, 1, 'warning', '1234123412341234123412341234123412341234', 'https://example.com/converage/', 'My awesome Coverage service', 'cov/awesomeness', 2, NULL, NULL);
INSERT INTO gtestschema.commit_status (id, index, repo_id, state, sha, target_url, description, context, creator_id, created_unix, updated_unix) VALUES (3, 3, 1, 'success', '1234123412341234123412341234123412341234', 'https://example.com/converage/', 'My awesome Coverage service', 'cov/awesomeness', 2, NULL, NULL);
INSERT INTO gtestschema.commit_status (id, index, repo_id, state, sha, target_url, description, context, creator_id, created_unix, updated_unix) VALUES (4, 4, 1, 'failure', '1234123412341234123412341234123412341234', 'https://example.com/builds/', 'My awesome CI-service', 'ci/awesomeness', 2, NULL, NULL);
INSERT INTO gtestschema.commit_status (id, index, repo_id, state, sha, target_url, description, context, creator_id, created_unix, updated_unix) VALUES (5, 5, 1, 'error', '1234123412341234123412341234123412341234', 'https://example.com/builds/', 'My awesome deploy service', 'deploy/awesomeness', 2, NULL, NULL);


--
-- Data for Name: deleted_branch; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.deleted_branch (id, repo_id, name, commit, deleted_by_id, deleted_unix) VALUES (1, 1, 'foo', '1213212312313213200000000', 1, 978307200);
INSERT INTO gtestschema.deleted_branch (id, repo_id, name, commit, deleted_by_id, deleted_unix) VALUES (2, 1, 'bar', '5655464564554545000000000', 99, 978307200);


--
-- Data for Name: deploy_key; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--



--
-- Data for Name: email_address; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.email_address (id, uid, email, is_activated) VALUES (1, 1, 'user11@example.com', false);
INSERT INTO gtestschema.email_address (id, uid, email, is_activated) VALUES (2, 1, 'user12@example.com', false);
INSERT INTO gtestschema.email_address (id, uid, email, is_activated) VALUES (3, 2, 'user2@example.com', true);
INSERT INTO gtestschema.email_address (id, uid, email, is_activated) VALUES (4, 2, 'user21@example.com', false);
INSERT INTO gtestschema.email_address (id, uid, email, is_activated) VALUES (5, 9999999, 'user9999999@example.com', true);
INSERT INTO gtestschema.email_address (id, uid, email, is_activated) VALUES (6, 10, 'user101@example.com', true);


--
-- Data for Name: external_login_user; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--



--
-- Data for Name: follow; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.follow (id, user_id, follow_id) VALUES (1, 4, 2);
INSERT INTO gtestschema.follow (id, user_id, follow_id) VALUES (2, 8, 2);
INSERT INTO gtestschema.follow (id, user_id, follow_id) VALUES (3, 2, 8);


--
-- Data for Name: gpg_key; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--



--
-- Data for Name: hook_task; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.hook_task (id, repo_id, hook_id, uuid, type, url, payload_content, content_type, event_type, is_ssl, is_delivered, delivered, is_succeed, request_content, response_content) VALUES (1, 1, 1, 'uuid1', NULL, NULL, NULL, NULL, NULL, NULL, true, NULL, NULL, NULL, NULL);


--
-- Data for Name: issue; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.issue (id, repo_id, index, poster_id, name, content, milestone_id, priority, is_closed, is_pull, num_comments, ref, deadline_unix, created_unix, updated_unix, closed_unix) VALUES (1, 1, 1, 1, 'issue1', 'content for the first issue', NULL, NULL, false, false, 2, NULL, NULL, 946684800, 978307200, NULL);
INSERT INTO gtestschema.issue (id, repo_id, index, poster_id, name, content, milestone_id, priority, is_closed, is_pull, num_comments, ref, deadline_unix, created_unix, updated_unix, closed_unix) VALUES (2, 1, 2, 1, 'issue2', 'content for the second issue', 1, NULL, false, true, NULL, NULL, NULL, 946684810, 978307190, NULL);
INSERT INTO gtestschema.issue (id, repo_id, index, poster_id, name, content, milestone_id, priority, is_closed, is_pull, num_comments, ref, deadline_unix, created_unix, updated_unix, closed_unix) VALUES (3, 1, 3, 1, 'issue3', 'content for the third issue', NULL, NULL, false, true, NULL, NULL, NULL, 946684820, 978307180, NULL);
INSERT INTO gtestschema.issue (id, repo_id, index, poster_id, name, content, milestone_id, priority, is_closed, is_pull, num_comments, ref, deadline_unix, created_unix, updated_unix, closed_unix) VALUES (4, 2, 1, 2, 'issue4', 'content for the fourth issue', NULL, NULL, true, false, NULL, NULL, NULL, 946684830, 978307200, NULL);
INSERT INTO gtestschema.issue (id, repo_id, index, poster_id, name, content, milestone_id, priority, is_closed, is_pull, num_comments, ref, deadline_unix, created_unix, updated_unix, closed_unix) VALUES (5, 1, 4, 2, 'issue5', 'content for the fifth issue', NULL, NULL, true, false, NULL, NULL, NULL, 946684840, 978307200, NULL);
INSERT INTO gtestschema.issue (id, repo_id, index, poster_id, name, content, milestone_id, priority, is_closed, is_pull, num_comments, ref, deadline_unix, created_unix, updated_unix, closed_unix) VALUES (6, 3, 1, 1, 'issue6', 'content6', NULL, NULL, false, false, 0, NULL, NULL, 946684850, 978307200, NULL);


--
-- Data for Name: issue_assignees; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.issue_assignees (id, assignee_id, issue_id) VALUES (1, 1, 1);
INSERT INTO gtestschema.issue_assignees (id, assignee_id, issue_id) VALUES (2, 1, 6);


--
-- Data for Name: issue_label; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.issue_label (id, issue_id, label_id) VALUES (1, 1, 1);
INSERT INTO gtestschema.issue_label (id, issue_id, label_id) VALUES (2, 5, 2);
INSERT INTO gtestschema.issue_label (id, issue_id, label_id) VALUES (3, 2, 1);


--
-- Data for Name: issue_user; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.issue_user (id, uid, issue_id, is_read, is_mentioned) VALUES (1, 1, 1, true, false);
INSERT INTO gtestschema.issue_user (id, uid, issue_id, is_read, is_mentioned) VALUES (2, 2, 1, true, false);
INSERT INTO gtestschema.issue_user (id, uid, issue_id, is_read, is_mentioned) VALUES (3, 4, 1, false, false);


--
-- Data for Name: issue_watch; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.issue_watch (id, user_id, issue_id, is_watching, created_unix, updated_unix) VALUES (1, 9, 1, true, 946684800, 946684800);
INSERT INTO gtestschema.issue_watch (id, user_id, issue_id, is_watching, created_unix, updated_unix) VALUES (2, 2, 2, false, 946684800, 946684800);


--
-- Data for Name: label; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.label (id, repo_id, name, description, color, num_issues, num_closed_issues) VALUES (1, 1, 'label1', NULL, '#abcdef', 2, 0);
INSERT INTO gtestschema.label (id, repo_id, name, description, color, num_issues, num_closed_issues) VALUES (2, 1, 'label2', NULL, '#000000', 1, 1);


--
-- Data for Name: lfs_lock; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--



--
-- Data for Name: lfs_meta_object; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--



--
-- Data for Name: login_source; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--



--
-- Data for Name: milestone; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.milestone (id, repo_id, name, content, is_closed, num_issues, num_closed_issues, completeness, deadline_unix, closed_date_unix) VALUES (1, 1, 'milestone1', 'content1', false, 1, NULL, NULL, NULL, NULL);
INSERT INTO gtestschema.milestone (id, repo_id, name, content, is_closed, num_issues, num_closed_issues, completeness, deadline_unix, closed_date_unix) VALUES (2, 1, 'milestone2', 'content2', false, 0, NULL, NULL, NULL, NULL);


--
-- Data for Name: mirror; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--



--
-- Data for Name: notice; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.notice (id, type, description, created_unix) VALUES (1, 1, 'description1', NULL);
INSERT INTO gtestschema.notice (id, type, description, created_unix) VALUES (2, 1, 'description2', NULL);
INSERT INTO gtestschema.notice (id, type, description, created_unix) VALUES (3, 1, 'description3', NULL);


--
-- Data for Name: notification; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.notification (id, user_id, repo_id, status, source, issue_id, commit_id, updated_by, created_unix, updated_unix) VALUES (1, 1, 1, 1, 1, 1, NULL, 2, 946684800, 946684800);
INSERT INTO gtestschema.notification (id, user_id, repo_id, status, source, issue_id, commit_id, updated_by, created_unix, updated_unix) VALUES (2, 2, 1, 2, 1, 2, NULL, 1, 946684800, 946684800);
INSERT INTO gtestschema.notification (id, user_id, repo_id, status, source, issue_id, commit_id, updated_by, created_unix, updated_unix) VALUES (3, 2, 1, 3, 1, 2, NULL, 1, 946684800, 946684800);
INSERT INTO gtestschema.notification (id, user_id, repo_id, status, source, issue_id, commit_id, updated_by, created_unix, updated_unix) VALUES (4, 2, 1, 1, 1, 2, NULL, 1, 946684800, 946684800);


--
-- Data for Name: oauth2_session; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--



--
-- Data for Name: org_user; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.org_user (id, uid, org_id, is_public) VALUES (1, 2, 3, true);
INSERT INTO gtestschema.org_user (id, uid, org_id, is_public) VALUES (2, 4, 3, false);
INSERT INTO gtestschema.org_user (id, uid, org_id, is_public) VALUES (3, 5, 6, true);
INSERT INTO gtestschema.org_user (id, uid, org_id, is_public) VALUES (4, 5, 7, false);
INSERT INTO gtestschema.org_user (id, uid, org_id, is_public) VALUES (5, 15, 17, true);
INSERT INTO gtestschema.org_user (id, uid, org_id, is_public) VALUES (6, 18, 17, false);
INSERT INTO gtestschema.org_user (id, uid, org_id, is_public) VALUES (7, 20, 19, true);


--
-- Data for Name: protected_branch; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--



--
-- Data for Name: public_key; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--



--
-- Data for Name: pull_request; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.pull_request (id, type, status, issue_id, index, head_repo_id, base_repo_id, head_user_name, head_branch, base_branch, merge_base, has_merged, merged_commit_id, merger_id, merged_unix) VALUES (1, 0, 2, 2, 2, 1, 1, 'user1', 'branch1', 'master', '1234567890abcdef', true, NULL, 2, NULL);
INSERT INTO gtestschema.pull_request (id, type, status, issue_id, index, head_repo_id, base_repo_id, head_user_name, head_branch, base_branch, merge_base, has_merged, merged_commit_id, merger_id, merged_unix) VALUES (2, 0, 2, 3, 3, 1, 1, 'user1', 'branch2', 'master', 'fedcba9876543210', false, NULL, NULL, NULL);


--
-- Data for Name: reaction; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--



--
-- Data for Name: release; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--



--
-- Data for Name: repo_indexer_status; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--



--
-- Data for Name: repo_redirect; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.repo_redirect (id, owner_id, lower_name, redirect_repo_id) VALUES (1, 2, 'oldrepo1', 1);


--
-- Data for Name: repo_topic; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.repo_topic (repo_id, topic_id) VALUES (1, 1);
INSERT INTO gtestschema.repo_topic (repo_id, topic_id) VALUES (1, 2);
INSERT INTO gtestschema.repo_topic (repo_id, topic_id) VALUES (1, 3);


--
-- Data for Name: repo_unit; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.repo_unit (id, repo_id, type, config, created_unix) VALUES (1, 1, 4, '{}', 946684810);
INSERT INTO gtestschema.repo_unit (id, repo_id, type, config, created_unix) VALUES (2, 1, 5, '{}', 946684810);
INSERT INTO gtestschema.repo_unit (id, repo_id, type, config, created_unix) VALUES (3, 1, 1, '{}', 946684810);
INSERT INTO gtestschema.repo_unit (id, repo_id, type, config, created_unix) VALUES (4, 1, 2, '{"EnableTimetracker":true,"AllowOnlyContributorsToTrackTime":true}', 946684810);
INSERT INTO gtestschema.repo_unit (id, repo_id, type, config, created_unix) VALUES (5, 1, 3, '{"IgnoreWhitespaceConflicts":false,"AllowMerge":true,"AllowRebase":true,"AllowSquash":true}', 946684810);
INSERT INTO gtestschema.repo_unit (id, repo_id, type, config, created_unix) VALUES (6, 3, 1, '{}', 946684810);
INSERT INTO gtestschema.repo_unit (id, repo_id, type, config, created_unix) VALUES (7, 3, 2, '{"EnableTimetracker":false,"AllowOnlyContributorsToTrackTime":false}', 946684810);
INSERT INTO gtestschema.repo_unit (id, repo_id, type, config, created_unix) VALUES (8, 3, 3, '{"IgnoreWhitespaceConflicts":true,"AllowMerge":true,"AllowRebase":false,"AllowSquash":false}', 946684810);
INSERT INTO gtestschema.repo_unit (id, repo_id, type, config, created_unix) VALUES (9, 3, 4, '{}', 946684810);
INSERT INTO gtestschema.repo_unit (id, repo_id, type, config, created_unix) VALUES (10, 3, 5, '{}', 946684810);
INSERT INTO gtestschema.repo_unit (id, repo_id, type, config, created_unix) VALUES (11, 31, 1, '{}', 1524304355);
INSERT INTO gtestschema.repo_unit (id, repo_id, type, config, created_unix) VALUES (12, 33, 1, '{}', 1535593231);
INSERT INTO gtestschema.repo_unit (id, repo_id, type, config, created_unix) VALUES (13, 33, 2, '{"EnableTimetracker":true,"AllowOnlyContributorsToTrackTime":true}', 1535593231);
INSERT INTO gtestschema.repo_unit (id, repo_id, type, config, created_unix) VALUES (14, 33, 3, '{"IgnoreWhitespaceConflicts":false,"AllowMerge":true,"AllowRebase":true,"AllowSquash":true}', 1535593231);
INSERT INTO gtestschema.repo_unit (id, repo_id, type, config, created_unix) VALUES (15, 33, 4, '{}', 1535593231);
INSERT INTO gtestschema.repo_unit (id, repo_id, type, config, created_unix) VALUES (16, 33, 5, '{}', 1535593231);


--
-- Data for Name: repository; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (1, 2, 'repo1', 'repo1', NULL, NULL, NULL, 3, NULL, NULL, 2, 1, 2, 0, 2, 0, false, NULL, NULL, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO gtestschema.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (2, 2, 'repo2', 'repo2', NULL, NULL, NULL, NULL, 1, NULL, 1, 1, 0, 0, 0, 0, true, NULL, NULL, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO gtestschema.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (3, 3, 'repo3', 'repo3', NULL, NULL, NULL, 0, NULL, NULL, 1, 0, 0, 0, 0, 0, true, NULL, NULL, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO gtestschema.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (4, 5, 'repo4', 'repo4', NULL, NULL, NULL, NULL, 1, NULL, 0, 0, 0, 0, 0, 0, false, NULL, NULL, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO gtestschema.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (5, 3, 'repo5', 'repo5', NULL, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, true, NULL, true, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO gtestschema.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (6, 10, 'repo6', 'repo6', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, true, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO gtestschema.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (7, 10, 'repo7', 'repo7', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, true, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO gtestschema.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (8, 10, 'repo8', 'repo8', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, false, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO gtestschema.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (9, 11, 'repo9', 'repo9', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, false, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO gtestschema.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (10, 12, 'repo10', 'repo10', NULL, NULL, NULL, NULL, NULL, 1, 0, 0, 0, 0, 0, 0, false, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO gtestschema.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (11, 13, 'repo11', 'repo11', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, false, NULL, false, false, 10, 0, true, NULL, NULL, NULL);
INSERT INTO gtestschema.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (12, 14, 'test_repo_12', 'test_repo_12', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, false, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO gtestschema.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (13, 14, 'test_repo_13', 'test_repo_13', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, true, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO gtestschema.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (14, 14, 'test_repo_14', 'test_repo_14', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, false, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO gtestschema.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (15, 2, 'repo15', 'repo15', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, true, NULL, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO gtestschema.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (16, 2, 'repo16', 'repo16', NULL, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, true, NULL, NULL, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO gtestschema.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (17, 15, 'big_test_public_1', 'big_test_public_1', NULL, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, false, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO gtestschema.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (18, 15, 'big_test_public_2', 'big_test_public_2', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, false, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO gtestschema.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (19, 15, 'big_test_private_1', 'big_test_private_1', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, true, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO gtestschema.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (20, 15, 'big_test_private_2', 'big_test_private_2', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, true, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO gtestschema.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (21, 16, 'big_test_public_3', 'big_test_public_3', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, false, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO gtestschema.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (22, 16, 'big_test_private_3', 'big_test_private_3', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, true, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO gtestschema.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (23, 17, 'big_test_public_4', 'big_test_public_4', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, false, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO gtestschema.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (24, 17, 'big_test_private_4', 'big_test_private_4', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, true, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO gtestschema.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (25, 20, 'big_test_public_mirror_5', 'big_test_public_mirror_5', NULL, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, false, NULL, true, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO gtestschema.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (26, 20, 'big_test_private_mirror_5', 'big_test_private_mirror_5', NULL, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, true, NULL, true, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO gtestschema.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (27, 19, 'big_test_public_mirror_6', 'big_test_public_mirror_6', NULL, NULL, NULL, 0, NULL, 1, 0, 0, 0, 0, 0, 0, false, NULL, true, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO gtestschema.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (28, 19, 'big_test_private_mirror_6', 'big_test_private_mirror_6', NULL, NULL, NULL, 0, NULL, 1, 0, 0, 0, 0, 0, 0, true, NULL, true, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO gtestschema.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (29, 20, 'big_test_public_fork_7', 'big_test_public_fork_7', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, false, NULL, false, true, 27, 0, true, NULL, NULL, NULL);
INSERT INTO gtestschema.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (30, 20, 'big_test_private_fork_7', 'big_test_private_fork_7', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, true, NULL, false, true, 28, 0, true, NULL, NULL, NULL);
INSERT INTO gtestschema.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (31, 2, 'repo20', 'repo20', NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, 0, 0, NULL, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO gtestschema.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (32, 3, 'repo21', 'repo21', NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, 0, 0, false, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO gtestschema.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (33, 2, 'utf8', 'utf8', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, false, NULL, NULL, false, NULL, 0, true, NULL, NULL, NULL);


--
-- Data for Name: star; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.star (id, uid, repo_id) VALUES (1, 2, 2);
INSERT INTO gtestschema.star (id, uid, repo_id) VALUES (2, 2, 4);


--
-- Data for Name: stopwatch; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.stopwatch (id, issue_id, user_id, created_unix) VALUES (1, 1, 1, 1500988502);
INSERT INTO gtestschema.stopwatch (id, issue_id, user_id, created_unix) VALUES (2, 2, 2, 1500988502);


--
-- Data for Name: team; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.team (id, org_id, lower_name, name, description, authorize, num_repos, num_members) VALUES (1, 3, 'owners', 'Owners', NULL, 4, 3, 1);
INSERT INTO gtestschema.team (id, org_id, lower_name, name, description, authorize, num_repos, num_members) VALUES (2, 3, 'team1', 'team1', NULL, 2, 1, 2);
INSERT INTO gtestschema.team (id, org_id, lower_name, name, description, authorize, num_repos, num_members) VALUES (3, 6, 'owners', 'Owners', NULL, 4, 0, 1);
INSERT INTO gtestschema.team (id, org_id, lower_name, name, description, authorize, num_repos, num_members) VALUES (4, 7, 'owners', 'Owners', NULL, 4, 0, 1);
INSERT INTO gtestschema.team (id, org_id, lower_name, name, description, authorize, num_repos, num_members) VALUES (5, 17, 'owners', 'Owners', NULL, 4, 2, 2);
INSERT INTO gtestschema.team (id, org_id, lower_name, name, description, authorize, num_repos, num_members) VALUES (6, 19, 'owners', 'Owners', NULL, 4, 2, 1);


--
-- Data for Name: team_repo; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.team_repo (id, org_id, team_id, repo_id) VALUES (1, 3, 1, 3);
INSERT INTO gtestschema.team_repo (id, org_id, team_id, repo_id) VALUES (2, 3, 2, 3);
INSERT INTO gtestschema.team_repo (id, org_id, team_id, repo_id) VALUES (3, 3, 1, 5);
INSERT INTO gtestschema.team_repo (id, org_id, team_id, repo_id) VALUES (4, 17, 5, 23);
INSERT INTO gtestschema.team_repo (id, org_id, team_id, repo_id) VALUES (5, 17, 5, 24);
INSERT INTO gtestschema.team_repo (id, org_id, team_id, repo_id) VALUES (6, 19, 6, 27);
INSERT INTO gtestschema.team_repo (id, org_id, team_id, repo_id) VALUES (7, 19, 6, 28);
INSERT INTO gtestschema.team_repo (id, org_id, team_id, repo_id) VALUES (8, 3, 1, 32);


--
-- Data for Name: team_unit; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (1, NULL, 1, 1);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (2, NULL, 1, 2);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (3, NULL, 1, 3);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (4, NULL, 1, 4);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (5, NULL, 1, 5);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (6, NULL, 1, 6);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (7, NULL, 1, 7);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (8, NULL, 2, 1);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (9, NULL, 2, 2);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (10, NULL, 2, 3);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (11, NULL, 2, 4);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (12, NULL, 2, 5);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (13, NULL, 2, 6);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (14, NULL, 2, 7);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (15, NULL, 3, 1);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (16, NULL, 3, 2);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (17, NULL, 3, 3);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (18, NULL, 3, 4);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (19, NULL, 3, 5);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (20, NULL, 3, 6);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (21, NULL, 3, 7);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (22, NULL, 4, 1);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (23, NULL, 4, 2);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (24, NULL, 4, 3);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (25, NULL, 4, 4);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (26, NULL, 4, 5);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (27, NULL, 4, 6);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (28, NULL, 4, 7);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (29, NULL, 5, 1);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (30, NULL, 5, 2);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (31, NULL, 5, 3);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (32, NULL, 5, 4);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (33, NULL, 5, 5);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (34, NULL, 5, 6);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (35, NULL, 5, 7);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (36, NULL, 6, 1);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (37, NULL, 6, 2);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (38, NULL, 6, 3);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (39, NULL, 6, 4);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (40, NULL, 6, 5);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (41, NULL, 6, 6);
INSERT INTO gtestschema.team_unit (id, org_id, team_id, type) VALUES (42, NULL, 6, 7);


--
-- Data for Name: team_user; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.team_user (id, org_id, team_id, uid) VALUES (1, 3, 1, 2);
INSERT INTO gtestschema.team_user (id, org_id, team_id, uid) VALUES (2, 3, 2, 2);
INSERT INTO gtestschema.team_user (id, org_id, team_id, uid) VALUES (3, 3, 2, 4);
INSERT INTO gtestschema.team_user (id, org_id, team_id, uid) VALUES (4, 6, 3, 5);
INSERT INTO gtestschema.team_user (id, org_id, team_id, uid) VALUES (5, 7, 4, 5);
INSERT INTO gtestschema.team_user (id, org_id, team_id, uid) VALUES (6, 17, 5, 15);
INSERT INTO gtestschema.team_user (id, org_id, team_id, uid) VALUES (7, 17, 5, 18);
INSERT INTO gtestschema.team_user (id, org_id, team_id, uid) VALUES (8, 19, 6, 20);


--
-- Data for Name: topic; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.topic (id, name, repo_count, created_unix, updated_unix) VALUES (1, 'golang', 1, NULL, NULL);
INSERT INTO gtestschema.topic (id, name, repo_count, created_unix, updated_unix) VALUES (2, 'database', 1, NULL, NULL);
INSERT INTO gtestschema.topic (id, name, repo_count, created_unix, updated_unix) VALUES (3, 'SQL', 1, NULL, NULL);


--
-- Data for Name: tracked_time; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.tracked_time (id, issue_id, user_id, created_unix, "time") VALUES (1, 1, 1, 946684800, 400);
INSERT INTO gtestschema.tracked_time (id, issue_id, user_id, created_unix, "time") VALUES (2, 2, 2, 946684801, 3661);
INSERT INTO gtestschema.tracked_time (id, issue_id, user_id, created_unix, "time") VALUES (3, 2, 2, 946684802, 1);
INSERT INTO gtestschema.tracked_time (id, issue_id, user_id, created_unix, "time") VALUES (4, 4, -1, 946684802, 1);
INSERT INTO gtestschema.tracked_time (id, issue_id, user_id, created_unix, "time") VALUES (5, 5, 2, 946684802, 1);


--
-- Data for Name: two_factor; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--



--
-- Data for Name: u2f_registration; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.u2f_registration (id, name, user_id, raw, counter, created_unix, updated_unix) VALUES (1, 'U2F Key', 1, NULL, 0, 946684800, 946684800);


--
-- Data for Name: upload; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--



--
-- Data for Name: user; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (1, 'user1', 'user1', 'User One', 'user1@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 0, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, true, true, NULL, NULL, true, false, 'avatar1', 'user1@example.com', NULL, NULL, 0, NULL, 0, NULL, NULL, NULL, '');
INSERT INTO gtestschema."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (2, 'user2', 'user2', 'User Two', 'user2@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 0, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, true, false, NULL, NULL, true, false, 'avatar2', 'user2@example.com', NULL, 2, 1, 2, 6, NULL, NULL, NULL, '');
INSERT INTO gtestschema."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (3, 'user3', 'user3', 'User Three', 'user3@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 1, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, NULL, false, NULL, NULL, true, false, 'avatar3', 'user3@example.com', NULL, NULL, 0, NULL, 3, NULL, 2, 2, '');
INSERT INTO gtestschema."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (4, 'user4', 'user4', 'User Four', 'user4@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 0, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, true, false, NULL, NULL, true, false, 'avatar4', 'user4@example.com', NULL, NULL, 1, NULL, 0, NULL, NULL, NULL, '');
INSERT INTO gtestschema."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (5, 'user5', 'user5', 'User Five', 'user5@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 0, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, true, false, NULL, NULL, false, false, 'avatar5', 'user5@example.com', NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, '');
INSERT INTO gtestschema."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (6, 'user6', 'user6', 'User Six', 'user6@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 1, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, NULL, false, NULL, NULL, true, false, 'avatar6', 'user6@example.com', NULL, NULL, 0, NULL, 0, NULL, 1, 1, '');
INSERT INTO gtestschema."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (7, 'user7', 'user7', 'User Seven', 'user7@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 1, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, NULL, false, NULL, NULL, true, false, 'avatar7', 'user7@example.com', NULL, NULL, 0, NULL, 0, NULL, 1, 1, '');
INSERT INTO gtestschema."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (8, 'user8', 'user8', 'User Eight', 'user8@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 0, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, true, false, NULL, NULL, true, false, 'avatar8', 'user8@example.com', NULL, 1, 1, NULL, 0, NULL, NULL, NULL, '');
INSERT INTO gtestschema."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (9, 'user9', 'user9', 'User Nine', 'user9@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 0, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, false, false, NULL, NULL, true, false, 'avatar9', 'user9@example.com', NULL, NULL, 0, NULL, 0, NULL, NULL, NULL, '');
INSERT INTO gtestschema."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (10, 'user10', 'user10', 'User Ten', 'user10@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 0, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, true, false, NULL, NULL, true, false, 'avatar10', 'user10@example.com', NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, '');
INSERT INTO gtestschema."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (11, 'user11', 'user11', 'User Eleven', 'user11@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 0, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, true, false, NULL, NULL, true, false, 'avatar11', 'user11@example.com', NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, '');
INSERT INTO gtestschema."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (12, 'user12', 'user12', 'User 12', 'user12@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 0, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, true, false, NULL, NULL, true, false, 'avatar12', 'user12@example.com', NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, '');
INSERT INTO gtestschema."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (13, 'user13', 'user13', 'User 13', 'user13@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 0, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, true, false, NULL, NULL, true, false, 'avatar13', 'user13@example.com', NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, '');
INSERT INTO gtestschema."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (14, 'user14', 'user14', 'User 14', 'user14@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 0, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, true, false, NULL, NULL, true, false, 'avatar14', 'user13@example.com', NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, '');
INSERT INTO gtestschema."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (15, 'user15', 'user15', 'User 15', 'user15@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 0, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, true, false, NULL, NULL, true, false, 'avatar15', 'user15@example.com', NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, '');
INSERT INTO gtestschema."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (16, 'user16', 'user16', 'User 16', 'user16@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 0, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, true, false, NULL, NULL, true, false, 'avatar16', 'user16@example.com', NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, '');
INSERT INTO gtestschema."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (17, 'user17', 'user17', 'User 17', 'user17@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 1, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, true, false, NULL, NULL, true, false, 'avatar17', 'user17@example.com', NULL, NULL, 0, NULL, 2, NULL, 1, 2, '');
INSERT INTO gtestschema."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (18, 'user18', 'user18', 'User 18', 'user18@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 0, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, true, false, NULL, NULL, true, false, 'avatar18', 'user18@example.com', NULL, NULL, 0, NULL, 0, NULL, NULL, NULL, '');
INSERT INTO gtestschema."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (19, 'user19', 'user19', 'User 19', 'user19@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 1, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, true, false, NULL, NULL, true, false, 'avatar19', 'user19@example.com', NULL, NULL, 0, NULL, 2, NULL, 1, 1, '');
INSERT INTO gtestschema."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (20, 'user20', 'user20', 'User 20', 'user20@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 0, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, true, false, NULL, NULL, true, false, 'avatar20', 'user20@example.com', NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, '');


--
-- Data for Name: user_open_id; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.user_open_id (id, uid, uri, show) VALUES (1, 1, 'https://user1.domain1.tld/', false);
INSERT INTO gtestschema.user_open_id (id, uid, uri, show) VALUES (2, 1, 'http://user1.domain2.tld/', true);
INSERT INTO gtestschema.user_open_id (id, uid, uri, show) VALUES (3, 2, 'https://domain1.tld/user2/', true);


--
-- Data for Name: version; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.version (id, version) VALUES (1, 70);


--
-- Data for Name: watch; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.watch (id, user_id, repo_id) VALUES (1, 1, 1);
INSERT INTO gtestschema.watch (id, user_id, repo_id) VALUES (2, 4, 1);
INSERT INTO gtestschema.watch (id, user_id, repo_id) VALUES (3, 9, 1);


--
-- Data for Name: webhook; Type: TABLE DATA; Schema: gtestschema; Owner: postgres
--

INSERT INTO gtestschema.webhook (id, repo_id, org_id, url, content_type, secret, events, is_ssl, is_active, hook_task_type, meta, last_status, created_unix, updated_unix) VALUES (1, 1, NULL, 'www.example.com/url1', 1, NULL, '{"push_only":true,"send_everything":false,"choose_events":false,"events":{"create":false,"push":true,"pull_request":false}}', NULL, true, NULL, NULL, NULL, NULL, NULL);
INSERT INTO gtestschema.webhook (id, repo_id, org_id, url, content_type, secret, events, is_ssl, is_active, hook_task_type, meta, last_status, created_unix, updated_unix) VALUES (2, 1, NULL, 'www.example.com/url2', 1, NULL, '{"push_only":false,"send_everything":false,"choose_events":false,"events":{"create":false,"push":true,"pull_request":true}}', NULL, false, NULL, NULL, NULL, NULL, NULL);
INSERT INTO gtestschema.webhook (id, repo_id, org_id, url, content_type, secret, events, is_ssl, is_active, hook_task_type, meta, last_status, created_unix, updated_unix) VALUES (3, 3, 3, 'www.example.com/url3', 1, NULL, '{"push_only":false,"send_everything":false,"choose_events":false,"events":{"create":false,"push":true,"pull_request":true}}', NULL, true, NULL, NULL, NULL, NULL, NULL);


--
-- Name: access_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.access_id_seq', 10000, true);


--
-- Name: access_token_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.access_token_id_seq', 10000, true);


--
-- Name: action_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.action_id_seq', 10000, true);


--
-- Name: attachment_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.attachment_id_seq', 10000, true);


--
-- Name: collaboration_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.collaboration_id_seq', 10000, true);


--
-- Name: comment_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.comment_id_seq', 10000, true);


--
-- Name: commit_status_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.commit_status_id_seq', 10000, true);


--
-- Name: deleted_branch_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.deleted_branch_id_seq', 10000, true);


--
-- Name: deploy_key_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.deploy_key_id_seq', 10000, true);


--
-- Name: email_address_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.email_address_id_seq', 10000, true);


--
-- Name: follow_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.follow_id_seq', 10000, true);


--
-- Name: gpg_key_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.gpg_key_id_seq', 10000, true);


--
-- Name: hook_task_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.hook_task_id_seq', 10000, true);


--
-- Name: issue_assignees_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.issue_assignees_id_seq', 10000, true);


--
-- Name: issue_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.issue_id_seq', 10000, true);


--
-- Name: issue_label_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.issue_label_id_seq', 10000, true);


--
-- Name: issue_user_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.issue_user_id_seq', 10000, true);


--
-- Name: issue_watch_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.issue_watch_id_seq', 10000, true);


--
-- Name: label_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.label_id_seq', 10000, true);


--
-- Name: lfs_lock_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.lfs_lock_id_seq', 10000, true);


--
-- Name: lfs_meta_object_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.lfs_meta_object_id_seq', 10000, true);


--
-- Name: login_source_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.login_source_id_seq', 10000, true);


--
-- Name: milestone_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.milestone_id_seq', 10000, true);


--
-- Name: mirror_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.mirror_id_seq', 10000, true);


--
-- Name: notice_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.notice_id_seq', 10000, true);


--
-- Name: notification_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.notification_id_seq', 10000, true);


--
-- Name: org_user_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.org_user_id_seq', 10000, true);


--
-- Name: protected_branch_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.protected_branch_id_seq', 10000, true);


--
-- Name: public_key_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.public_key_id_seq', 10000, true);


--
-- Name: pull_request_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.pull_request_id_seq', 10000, true);


--
-- Name: reaction_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.reaction_id_seq', 10000, true);


--
-- Name: release_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.release_id_seq', 10000, true);


--
-- Name: repo_indexer_status_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.repo_indexer_status_id_seq', 10000, true);


--
-- Name: repo_redirect_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.repo_redirect_id_seq', 10000, true);


--
-- Name: repo_unit_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.repo_unit_id_seq', 10000, true);


--
-- Name: repository_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.repository_id_seq', 10000, true);


--
-- Name: star_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.star_id_seq', 10000, true);


--
-- Name: stopwatch_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.stopwatch_id_seq', 10000, true);


--
-- Name: team_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.team_id_seq', 10000, true);


--
-- Name: team_repo_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.team_repo_id_seq', 10000, true);


--
-- Name: team_unit_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.team_unit_id_seq', 10000, true);


--
-- Name: team_user_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.team_user_id_seq', 10000, true);


--
-- Name: topic_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.topic_id_seq', 10000, true);


--
-- Name: tracked_time_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.tracked_time_id_seq', 10000, true);


--
-- Name: two_factor_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.two_factor_id_seq', 10000, true);


--
-- Name: u2f_registration_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.u2f_registration_id_seq', 10000, true);


--
-- Name: upload_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.upload_id_seq', 10000, true);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.user_id_seq', 10000, true);


--
-- Name: user_open_id_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.user_open_id_id_seq', 10000, true);


--
-- Name: version_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.version_id_seq', 10000, true);


--
-- Name: watch_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.watch_id_seq', 10000, true);


--
-- Name: webhook_id_seq; Type: SEQUENCE SET; Schema: gtestschema; Owner: postgres
--

SELECT pg_catalog.setval('gtestschema.webhook_id_seq', 10000, true);


--
-- Name: access access_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.access
    ADD CONSTRAINT access_pkey PRIMARY KEY (id);


--
-- Name: access_token access_token_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.access_token
    ADD CONSTRAINT access_token_pkey PRIMARY KEY (id);


--
-- Name: action action_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.action
    ADD CONSTRAINT action_pkey PRIMARY KEY (id);


--
-- Name: attachment attachment_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.attachment
    ADD CONSTRAINT attachment_pkey PRIMARY KEY (id);


--
-- Name: collaboration collaboration_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.collaboration
    ADD CONSTRAINT collaboration_pkey PRIMARY KEY (id);


--
-- Name: comment comment_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.comment
    ADD CONSTRAINT comment_pkey PRIMARY KEY (id);


--
-- Name: commit_status commit_status_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.commit_status
    ADD CONSTRAINT commit_status_pkey PRIMARY KEY (id);


--
-- Name: deleted_branch deleted_branch_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.deleted_branch
    ADD CONSTRAINT deleted_branch_pkey PRIMARY KEY (id);


--
-- Name: deploy_key deploy_key_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.deploy_key
    ADD CONSTRAINT deploy_key_pkey PRIMARY KEY (id);


--
-- Name: email_address email_address_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.email_address
    ADD CONSTRAINT email_address_pkey PRIMARY KEY (id);


--
-- Name: external_login_user external_login_user_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.external_login_user
    ADD CONSTRAINT external_login_user_pkey PRIMARY KEY (external_id, login_source_id);


--
-- Name: follow follow_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.follow
    ADD CONSTRAINT follow_pkey PRIMARY KEY (id);


--
-- Name: gpg_key gpg_key_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.gpg_key
    ADD CONSTRAINT gpg_key_pkey PRIMARY KEY (id);


--
-- Name: hook_task hook_task_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.hook_task
    ADD CONSTRAINT hook_task_pkey PRIMARY KEY (id);


--
-- Name: issue_assignees issue_assignees_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.issue_assignees
    ADD CONSTRAINT issue_assignees_pkey PRIMARY KEY (id);


--
-- Name: issue_label issue_label_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.issue_label
    ADD CONSTRAINT issue_label_pkey PRIMARY KEY (id);


--
-- Name: issue issue_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.issue
    ADD CONSTRAINT issue_pkey PRIMARY KEY (id);


--
-- Name: issue_user issue_user_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.issue_user
    ADD CONSTRAINT issue_user_pkey PRIMARY KEY (id);


--
-- Name: issue_watch issue_watch_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.issue_watch
    ADD CONSTRAINT issue_watch_pkey PRIMARY KEY (id);


--
-- Name: label label_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.label
    ADD CONSTRAINT label_pkey PRIMARY KEY (id);


--
-- Name: lfs_lock lfs_lock_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.lfs_lock
    ADD CONSTRAINT lfs_lock_pkey PRIMARY KEY (id);


--
-- Name: lfs_meta_object lfs_meta_object_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.lfs_meta_object
    ADD CONSTRAINT lfs_meta_object_pkey PRIMARY KEY (id);


--
-- Name: login_source login_source_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.login_source
    ADD CONSTRAINT login_source_pkey PRIMARY KEY (id);


--
-- Name: milestone milestone_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.milestone
    ADD CONSTRAINT milestone_pkey PRIMARY KEY (id);


--
-- Name: mirror mirror_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.mirror
    ADD CONSTRAINT mirror_pkey PRIMARY KEY (id);


--
-- Name: notice notice_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.notice
    ADD CONSTRAINT notice_pkey PRIMARY KEY (id);


--
-- Name: notification notification_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.notification
    ADD CONSTRAINT notification_pkey PRIMARY KEY (id);


--
-- Name: oauth2_session oauth2_session_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.oauth2_session
    ADD CONSTRAINT oauth2_session_pkey PRIMARY KEY (id);


--
-- Name: org_user org_user_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.org_user
    ADD CONSTRAINT org_user_pkey PRIMARY KEY (id);


--
-- Name: protected_branch protected_branch_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.protected_branch
    ADD CONSTRAINT protected_branch_pkey PRIMARY KEY (id);


--
-- Name: public_key public_key_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.public_key
    ADD CONSTRAINT public_key_pkey PRIMARY KEY (id);


--
-- Name: pull_request pull_request_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.pull_request
    ADD CONSTRAINT pull_request_pkey PRIMARY KEY (id);


--
-- Name: reaction reaction_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.reaction
    ADD CONSTRAINT reaction_pkey PRIMARY KEY (id);


--
-- Name: release release_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.release
    ADD CONSTRAINT release_pkey PRIMARY KEY (id);


--
-- Name: repo_indexer_status repo_indexer_status_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.repo_indexer_status
    ADD CONSTRAINT repo_indexer_status_pkey PRIMARY KEY (id);


--
-- Name: repo_redirect repo_redirect_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.repo_redirect
    ADD CONSTRAINT repo_redirect_pkey PRIMARY KEY (id);


--
-- Name: repo_unit repo_unit_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.repo_unit
    ADD CONSTRAINT repo_unit_pkey PRIMARY KEY (id);


--
-- Name: repository repository_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.repository
    ADD CONSTRAINT repository_pkey PRIMARY KEY (id);


--
-- Name: star star_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.star
    ADD CONSTRAINT star_pkey PRIMARY KEY (id);


--
-- Name: stopwatch stopwatch_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.stopwatch
    ADD CONSTRAINT stopwatch_pkey PRIMARY KEY (id);


--
-- Name: team team_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.team
    ADD CONSTRAINT team_pkey PRIMARY KEY (id);


--
-- Name: team_repo team_repo_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.team_repo
    ADD CONSTRAINT team_repo_pkey PRIMARY KEY (id);


--
-- Name: team_unit team_unit_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.team_unit
    ADD CONSTRAINT team_unit_pkey PRIMARY KEY (id);


--
-- Name: team_user team_user_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.team_user
    ADD CONSTRAINT team_user_pkey PRIMARY KEY (id);


--
-- Name: topic topic_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.topic
    ADD CONSTRAINT topic_pkey PRIMARY KEY (id);


--
-- Name: tracked_time tracked_time_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.tracked_time
    ADD CONSTRAINT tracked_time_pkey PRIMARY KEY (id);


--
-- Name: two_factor two_factor_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.two_factor
    ADD CONSTRAINT two_factor_pkey PRIMARY KEY (id);


--
-- Name: u2f_registration u2f_registration_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.u2f_registration
    ADD CONSTRAINT u2f_registration_pkey PRIMARY KEY (id);


--
-- Name: upload upload_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.upload
    ADD CONSTRAINT upload_pkey PRIMARY KEY (id);


--
-- Name: user_open_id user_open_id_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.user_open_id
    ADD CONSTRAINT user_open_id_pkey PRIMARY KEY (id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: version version_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.version
    ADD CONSTRAINT version_pkey PRIMARY KEY (id);


--
-- Name: watch watch_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.watch
    ADD CONSTRAINT watch_pkey PRIMARY KEY (id);


--
-- Name: webhook webhook_pkey; Type: CONSTRAINT; Schema: gtestschema; Owner: postgres
--

ALTER TABLE ONLY gtestschema.webhook
    ADD CONSTRAINT webhook_pkey PRIMARY KEY (id);


--
-- Name: IDX_access_token_created_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_access_token_created_unix" ON gtestschema.access_token USING btree (created_unix);


--
-- Name: IDX_access_token_uid; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_access_token_uid" ON gtestschema.access_token USING btree (uid);


--
-- Name: IDX_access_token_updated_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_access_token_updated_unix" ON gtestschema.access_token USING btree (updated_unix);


--
-- Name: IDX_action_act_user_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_action_act_user_id" ON gtestschema.action USING btree (act_user_id);


--
-- Name: IDX_action_comment_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_action_comment_id" ON gtestschema.action USING btree (comment_id);


--
-- Name: IDX_action_created_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_action_created_unix" ON gtestschema.action USING btree (created_unix);


--
-- Name: IDX_action_is_deleted; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_action_is_deleted" ON gtestschema.action USING btree (is_deleted);


--
-- Name: IDX_action_is_private; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_action_is_private" ON gtestschema.action USING btree (is_private);


--
-- Name: IDX_action_repo_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_action_repo_id" ON gtestschema.action USING btree (repo_id);


--
-- Name: IDX_action_user_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_action_user_id" ON gtestschema.action USING btree (user_id);


--
-- Name: IDX_attachment_issue_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_attachment_issue_id" ON gtestschema.attachment USING btree (issue_id);


--
-- Name: IDX_attachment_release_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_attachment_release_id" ON gtestschema.attachment USING btree (release_id);


--
-- Name: IDX_collaboration_repo_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_collaboration_repo_id" ON gtestschema.collaboration USING btree (repo_id);


--
-- Name: IDX_collaboration_user_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_collaboration_user_id" ON gtestschema.collaboration USING btree (user_id);


--
-- Name: IDX_comment_created_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_comment_created_unix" ON gtestschema.comment USING btree (created_unix);


--
-- Name: IDX_comment_issue_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_comment_issue_id" ON gtestschema.comment USING btree (issue_id);


--
-- Name: IDX_comment_poster_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_comment_poster_id" ON gtestschema.comment USING btree (poster_id);


--
-- Name: IDX_comment_updated_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_comment_updated_unix" ON gtestschema.comment USING btree (updated_unix);


--
-- Name: IDX_commit_status_created_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_commit_status_created_unix" ON gtestschema.commit_status USING btree (created_unix);


--
-- Name: IDX_commit_status_index; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_commit_status_index" ON gtestschema.commit_status USING btree (index);


--
-- Name: IDX_commit_status_repo_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_commit_status_repo_id" ON gtestschema.commit_status USING btree (repo_id);


--
-- Name: IDX_commit_status_sha; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_commit_status_sha" ON gtestschema.commit_status USING btree (sha);


--
-- Name: IDX_commit_status_updated_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_commit_status_updated_unix" ON gtestschema.commit_status USING btree (updated_unix);


--
-- Name: IDX_deleted_branch_deleted_by_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_deleted_branch_deleted_by_id" ON gtestschema.deleted_branch USING btree (deleted_by_id);


--
-- Name: IDX_deleted_branch_deleted_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_deleted_branch_deleted_unix" ON gtestschema.deleted_branch USING btree (deleted_unix);


--
-- Name: IDX_deleted_branch_repo_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_deleted_branch_repo_id" ON gtestschema.deleted_branch USING btree (repo_id);


--
-- Name: IDX_deploy_key_key_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_deploy_key_key_id" ON gtestschema.deploy_key USING btree (key_id);


--
-- Name: IDX_deploy_key_repo_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_deploy_key_repo_id" ON gtestschema.deploy_key USING btree (repo_id);


--
-- Name: IDX_email_address_uid; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_email_address_uid" ON gtestschema.email_address USING btree (uid);


--
-- Name: IDX_external_login_user_user_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_external_login_user_user_id" ON gtestschema.external_login_user USING btree (user_id);


--
-- Name: IDX_gpg_key_key_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_gpg_key_key_id" ON gtestschema.gpg_key USING btree (key_id);


--
-- Name: IDX_gpg_key_owner_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_gpg_key_owner_id" ON gtestschema.gpg_key USING btree (owner_id);


--
-- Name: IDX_hook_task_repo_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_hook_task_repo_id" ON gtestschema.hook_task USING btree (repo_id);


--
-- Name: IDX_issue_assignees_assignee_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_issue_assignees_assignee_id" ON gtestschema.issue_assignees USING btree (assignee_id);


--
-- Name: IDX_issue_assignees_issue_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_issue_assignees_issue_id" ON gtestschema.issue_assignees USING btree (issue_id);


--
-- Name: IDX_issue_closed_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_issue_closed_unix" ON gtestschema.issue USING btree (closed_unix);


--
-- Name: IDX_issue_created_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_issue_created_unix" ON gtestschema.issue USING btree (created_unix);


--
-- Name: IDX_issue_deadline_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_issue_deadline_unix" ON gtestschema.issue USING btree (deadline_unix);


--
-- Name: IDX_issue_is_closed; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_issue_is_closed" ON gtestschema.issue USING btree (is_closed);


--
-- Name: IDX_issue_is_pull; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_issue_is_pull" ON gtestschema.issue USING btree (is_pull);


--
-- Name: IDX_issue_milestone_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_issue_milestone_id" ON gtestschema.issue USING btree (milestone_id);


--
-- Name: IDX_issue_poster_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_issue_poster_id" ON gtestschema.issue USING btree (poster_id);


--
-- Name: IDX_issue_repo_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_issue_repo_id" ON gtestschema.issue USING btree (repo_id);


--
-- Name: IDX_issue_updated_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_issue_updated_unix" ON gtestschema.issue USING btree (updated_unix);


--
-- Name: IDX_issue_user_uid; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_issue_user_uid" ON gtestschema.issue_user USING btree (uid);


--
-- Name: IDX_label_repo_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_label_repo_id" ON gtestschema.label USING btree (repo_id);


--
-- Name: IDX_lfs_lock_owner_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_lfs_lock_owner_id" ON gtestschema.lfs_lock USING btree (owner_id);


--
-- Name: IDX_lfs_lock_repo_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_lfs_lock_repo_id" ON gtestschema.lfs_lock USING btree (repo_id);


--
-- Name: IDX_lfs_meta_object_oid; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_lfs_meta_object_oid" ON gtestschema.lfs_meta_object USING btree (oid);


--
-- Name: IDX_lfs_meta_object_repository_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_lfs_meta_object_repository_id" ON gtestschema.lfs_meta_object USING btree (repository_id);


--
-- Name: IDX_login_source_created_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_login_source_created_unix" ON gtestschema.login_source USING btree (created_unix);


--
-- Name: IDX_login_source_is_actived; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_login_source_is_actived" ON gtestschema.login_source USING btree (is_actived);


--
-- Name: IDX_login_source_is_sync_enabled; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_login_source_is_sync_enabled" ON gtestschema.login_source USING btree (is_sync_enabled);


--
-- Name: IDX_login_source_updated_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_login_source_updated_unix" ON gtestschema.login_source USING btree (updated_unix);


--
-- Name: IDX_milestone_repo_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_milestone_repo_id" ON gtestschema.milestone USING btree (repo_id);


--
-- Name: IDX_mirror_next_update_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_mirror_next_update_unix" ON gtestschema.mirror USING btree (next_update_unix);


--
-- Name: IDX_mirror_repo_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_mirror_repo_id" ON gtestschema.mirror USING btree (repo_id);


--
-- Name: IDX_mirror_updated_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_mirror_updated_unix" ON gtestschema.mirror USING btree (updated_unix);


--
-- Name: IDX_notice_created_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_notice_created_unix" ON gtestschema.notice USING btree (created_unix);


--
-- Name: IDX_notification_commit_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_notification_commit_id" ON gtestschema.notification USING btree (commit_id);


--
-- Name: IDX_notification_created_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_notification_created_unix" ON gtestschema.notification USING btree (created_unix);


--
-- Name: IDX_notification_issue_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_notification_issue_id" ON gtestschema.notification USING btree (issue_id);


--
-- Name: IDX_notification_repo_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_notification_repo_id" ON gtestschema.notification USING btree (repo_id);


--
-- Name: IDX_notification_source; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_notification_source" ON gtestschema.notification USING btree (source);


--
-- Name: IDX_notification_status; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_notification_status" ON gtestschema.notification USING btree (status);


--
-- Name: IDX_notification_updated_by; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_notification_updated_by" ON gtestschema.notification USING btree (updated_by);


--
-- Name: IDX_notification_updated_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_notification_updated_unix" ON gtestschema.notification USING btree (updated_unix);


--
-- Name: IDX_notification_user_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_notification_user_id" ON gtestschema.notification USING btree (user_id);


--
-- Name: IDX_oauth2_session_expires_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_oauth2_session_expires_unix" ON gtestschema.oauth2_session USING btree (expires_unix);


--
-- Name: IDX_org_user_is_public; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_org_user_is_public" ON gtestschema.org_user USING btree (is_public);


--
-- Name: IDX_org_user_org_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_org_user_org_id" ON gtestschema.org_user USING btree (org_id);


--
-- Name: IDX_org_user_uid; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_org_user_uid" ON gtestschema.org_user USING btree (uid);


--
-- Name: IDX_public_key_owner_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_public_key_owner_id" ON gtestschema.public_key USING btree (owner_id);


--
-- Name: IDX_pull_request_base_repo_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_pull_request_base_repo_id" ON gtestschema.pull_request USING btree (base_repo_id);


--
-- Name: IDX_pull_request_has_merged; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_pull_request_has_merged" ON gtestschema.pull_request USING btree (has_merged);


--
-- Name: IDX_pull_request_head_repo_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_pull_request_head_repo_id" ON gtestschema.pull_request USING btree (head_repo_id);


--
-- Name: IDX_pull_request_issue_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_pull_request_issue_id" ON gtestschema.pull_request USING btree (issue_id);


--
-- Name: IDX_pull_request_merged_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_pull_request_merged_unix" ON gtestschema.pull_request USING btree (merged_unix);


--
-- Name: IDX_pull_request_merger_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_pull_request_merger_id" ON gtestschema.pull_request USING btree (merger_id);


--
-- Name: IDX_reaction_comment_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_reaction_comment_id" ON gtestschema.reaction USING btree (comment_id);


--
-- Name: IDX_reaction_created_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_reaction_created_unix" ON gtestschema.reaction USING btree (created_unix);


--
-- Name: IDX_reaction_issue_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_reaction_issue_id" ON gtestschema.reaction USING btree (issue_id);


--
-- Name: IDX_reaction_type; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_reaction_type" ON gtestschema.reaction USING btree (type);


--
-- Name: IDX_reaction_user_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_reaction_user_id" ON gtestschema.reaction USING btree (user_id);


--
-- Name: IDX_release_created_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_release_created_unix" ON gtestschema.release USING btree (created_unix);


--
-- Name: IDX_release_publisher_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_release_publisher_id" ON gtestschema.release USING btree (publisher_id);


--
-- Name: IDX_release_repo_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_release_repo_id" ON gtestschema.release USING btree (repo_id);


--
-- Name: IDX_release_tag_name; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_release_tag_name" ON gtestschema.release USING btree (tag_name);


--
-- Name: IDX_repo_indexer_status_repo_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_repo_indexer_status_repo_id" ON gtestschema.repo_indexer_status USING btree (repo_id);


--
-- Name: IDX_repo_redirect_lower_name; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_repo_redirect_lower_name" ON gtestschema.repo_redirect USING btree (lower_name);


--
-- Name: IDX_repo_unit_created_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_repo_unit_created_unix" ON gtestschema.repo_unit USING btree (created_unix);


--
-- Name: IDX_repo_unit_s; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_repo_unit_s" ON gtestschema.repo_unit USING btree (repo_id, type);


--
-- Name: IDX_repository_created_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_repository_created_unix" ON gtestschema.repository USING btree (created_unix);


--
-- Name: IDX_repository_fork_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_repository_fork_id" ON gtestschema.repository USING btree (fork_id);


--
-- Name: IDX_repository_is_bare; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_repository_is_bare" ON gtestschema.repository USING btree (is_bare);


--
-- Name: IDX_repository_is_fork; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_repository_is_fork" ON gtestschema.repository USING btree (is_fork);


--
-- Name: IDX_repository_is_mirror; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_repository_is_mirror" ON gtestschema.repository USING btree (is_mirror);


--
-- Name: IDX_repository_is_private; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_repository_is_private" ON gtestschema.repository USING btree (is_private);


--
-- Name: IDX_repository_lower_name; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_repository_lower_name" ON gtestschema.repository USING btree (lower_name);


--
-- Name: IDX_repository_name; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_repository_name" ON gtestschema.repository USING btree (name);


--
-- Name: IDX_repository_updated_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_repository_updated_unix" ON gtestschema.repository USING btree (updated_unix);


--
-- Name: IDX_stopwatch_issue_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_stopwatch_issue_id" ON gtestschema.stopwatch USING btree (issue_id);


--
-- Name: IDX_stopwatch_user_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_stopwatch_user_id" ON gtestschema.stopwatch USING btree (user_id);


--
-- Name: IDX_team_org_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_team_org_id" ON gtestschema.team USING btree (org_id);


--
-- Name: IDX_team_repo_org_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_team_repo_org_id" ON gtestschema.team_repo USING btree (org_id);


--
-- Name: IDX_team_unit_org_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_team_unit_org_id" ON gtestschema.team_unit USING btree (org_id);


--
-- Name: IDX_team_user_org_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_team_user_org_id" ON gtestschema.team_user USING btree (org_id);


--
-- Name: IDX_topic_created_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_topic_created_unix" ON gtestschema.topic USING btree (created_unix);


--
-- Name: IDX_topic_updated_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_topic_updated_unix" ON gtestschema.topic USING btree (updated_unix);


--
-- Name: IDX_tracked_time_issue_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_tracked_time_issue_id" ON gtestschema.tracked_time USING btree (issue_id);


--
-- Name: IDX_tracked_time_user_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_tracked_time_user_id" ON gtestschema.tracked_time USING btree (user_id);


--
-- Name: IDX_two_factor_created_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_two_factor_created_unix" ON gtestschema.two_factor USING btree (created_unix);


--
-- Name: IDX_two_factor_updated_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_two_factor_updated_unix" ON gtestschema.two_factor USING btree (updated_unix);


--
-- Name: IDX_u2f_registration_created_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_u2f_registration_created_unix" ON gtestschema.u2f_registration USING btree (created_unix);


--
-- Name: IDX_u2f_registration_updated_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_u2f_registration_updated_unix" ON gtestschema.u2f_registration USING btree (updated_unix);


--
-- Name: IDX_u2f_registration_user_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_u2f_registration_user_id" ON gtestschema.u2f_registration USING btree (user_id);


--
-- Name: IDX_user_created_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_user_created_unix" ON gtestschema."user" USING btree (created_unix);


--
-- Name: IDX_user_is_active; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_user_is_active" ON gtestschema."user" USING btree (is_active);


--
-- Name: IDX_user_last_login_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_user_last_login_unix" ON gtestschema."user" USING btree (last_login_unix);


--
-- Name: IDX_user_open_id_uid; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_user_open_id_uid" ON gtestschema.user_open_id USING btree (uid);


--
-- Name: IDX_user_updated_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_user_updated_unix" ON gtestschema."user" USING btree (updated_unix);


--
-- Name: IDX_webhook_created_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_webhook_created_unix" ON gtestschema.webhook USING btree (created_unix);


--
-- Name: IDX_webhook_is_active; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_webhook_is_active" ON gtestschema.webhook USING btree (is_active);


--
-- Name: IDX_webhook_org_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_webhook_org_id" ON gtestschema.webhook USING btree (org_id);


--
-- Name: IDX_webhook_repo_id; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_webhook_repo_id" ON gtestschema.webhook USING btree (repo_id);


--
-- Name: IDX_webhook_updated_unix; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE INDEX "IDX_webhook_updated_unix" ON gtestschema.webhook USING btree (updated_unix);


--
-- Name: UQE_access_s; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_access_s" ON gtestschema.access USING btree (user_id, repo_id);


--
-- Name: UQE_access_token_sha1; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_access_token_sha1" ON gtestschema.access_token USING btree (sha1);


--
-- Name: UQE_attachment_uuid; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_attachment_uuid" ON gtestschema.attachment USING btree (uuid);


--
-- Name: UQE_collaboration_s; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_collaboration_s" ON gtestschema.collaboration USING btree (repo_id, user_id);


--
-- Name: UQE_commit_status_repo_sha_index; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_commit_status_repo_sha_index" ON gtestschema.commit_status USING btree (index, repo_id, sha);


--
-- Name: UQE_deleted_branch_s; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_deleted_branch_s" ON gtestschema.deleted_branch USING btree (repo_id, name, commit);


--
-- Name: UQE_deploy_key_s; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_deploy_key_s" ON gtestschema.deploy_key USING btree (key_id, repo_id);


--
-- Name: UQE_email_address_email; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_email_address_email" ON gtestschema.email_address USING btree (email);


--
-- Name: UQE_follow_follow; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_follow_follow" ON gtestschema.follow USING btree (user_id, follow_id);


--
-- Name: UQE_issue_label_s; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_issue_label_s" ON gtestschema.issue_label USING btree (issue_id, label_id);


--
-- Name: UQE_issue_repo_index; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_issue_repo_index" ON gtestschema.issue USING btree (repo_id, index);


--
-- Name: UQE_issue_watch_watch; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_issue_watch_watch" ON gtestschema.issue_watch USING btree (user_id, issue_id);


--
-- Name: UQE_lfs_meta_object_s; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_lfs_meta_object_s" ON gtestschema.lfs_meta_object USING btree (oid, repository_id);


--
-- Name: UQE_login_source_name; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_login_source_name" ON gtestschema.login_source USING btree (name);


--
-- Name: UQE_org_user_s; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_org_user_s" ON gtestschema.org_user USING btree (uid, org_id);


--
-- Name: UQE_protected_branch_s; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_protected_branch_s" ON gtestschema.protected_branch USING btree (repo_id, branch_name);


--
-- Name: UQE_reaction_s; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_reaction_s" ON gtestschema.reaction USING btree (type, issue_id, comment_id, user_id);


--
-- Name: UQE_release_n; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_release_n" ON gtestschema.release USING btree (repo_id, tag_name);


--
-- Name: UQE_repo_redirect_s; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_repo_redirect_s" ON gtestschema.repo_redirect USING btree (owner_id, lower_name);


--
-- Name: UQE_repo_topic_s; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_repo_topic_s" ON gtestschema.repo_topic USING btree (repo_id, topic_id);


--
-- Name: UQE_repository_s; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_repository_s" ON gtestschema.repository USING btree (owner_id, lower_name);


--
-- Name: UQE_star_s; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_star_s" ON gtestschema.star USING btree (uid, repo_id);


--
-- Name: UQE_team_repo_s; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_team_repo_s" ON gtestschema.team_repo USING btree (team_id, repo_id);


--
-- Name: UQE_team_unit_s; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_team_unit_s" ON gtestschema.team_unit USING btree (team_id, type);


--
-- Name: UQE_team_user_s; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_team_user_s" ON gtestschema.team_user USING btree (team_id, uid);


--
-- Name: UQE_topic_name; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_topic_name" ON gtestschema.topic USING btree (name);


--
-- Name: UQE_two_factor_uid; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_two_factor_uid" ON gtestschema.two_factor USING btree (uid);


--
-- Name: UQE_upload_uuid; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_upload_uuid" ON gtestschema.upload USING btree (uuid);


--
-- Name: UQE_user_lower_name; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_user_lower_name" ON gtestschema."user" USING btree (lower_name);


--
-- Name: UQE_user_name; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_user_name" ON gtestschema."user" USING btree (name);


--
-- Name: UQE_user_open_id_uri; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_user_open_id_uri" ON gtestschema.user_open_id USING btree (uri);


--
-- Name: UQE_watch_watch; Type: INDEX; Schema: gtestschema; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_watch_watch" ON gtestschema.watch USING btree (user_id, repo_id);


--
-- Name: SCHEMA gtestschema; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON SCHEMA gtestschema TO PUBLIC;


--
-- PostgreSQL database dump complete
--

