--
-- PostgreSQL database dump
--

-- Dumped from database version 10.6 (Ubuntu 10.6-0ubuntu0.18.04.1)
-- Dumped by pg_dump version 10.6 (Ubuntu 10.6-0ubuntu0.18.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP INDEX IF EXISTS public."UQE_watch_watch";
DROP INDEX IF EXISTS public."UQE_user_open_id_uri";
DROP INDEX IF EXISTS public."UQE_user_name";
DROP INDEX IF EXISTS public."UQE_user_lower_name";
DROP INDEX IF EXISTS public."UQE_upload_uuid";
DROP INDEX IF EXISTS public."UQE_two_factor_uid";
DROP INDEX IF EXISTS public."UQE_topic_name";
DROP INDEX IF EXISTS public."UQE_team_user_s";
DROP INDEX IF EXISTS public."UQE_team_unit_s";
DROP INDEX IF EXISTS public."UQE_team_repo_s";
DROP INDEX IF EXISTS public."UQE_star_s";
DROP INDEX IF EXISTS public."UQE_repository_s";
DROP INDEX IF EXISTS public."UQE_repo_topic_s";
DROP INDEX IF EXISTS public."UQE_repo_redirect_s";
DROP INDEX IF EXISTS public."UQE_release_n";
DROP INDEX IF EXISTS public."UQE_reaction_s";
DROP INDEX IF EXISTS public."UQE_protected_branch_s";
DROP INDEX IF EXISTS public."UQE_org_user_s";
DROP INDEX IF EXISTS public."UQE_login_source_name";
DROP INDEX IF EXISTS public."UQE_lfs_meta_object_s";
DROP INDEX IF EXISTS public."UQE_issue_watch_watch";
DROP INDEX IF EXISTS public."UQE_issue_repo_index";
DROP INDEX IF EXISTS public."UQE_issue_label_s";
DROP INDEX IF EXISTS public."UQE_follow_follow";
DROP INDEX IF EXISTS public."UQE_email_address_email";
DROP INDEX IF EXISTS public."UQE_deploy_key_s";
DROP INDEX IF EXISTS public."UQE_deleted_branch_s";
DROP INDEX IF EXISTS public."UQE_commit_status_repo_sha_index";
DROP INDEX IF EXISTS public."UQE_collaboration_s";
DROP INDEX IF EXISTS public."UQE_attachment_uuid";
DROP INDEX IF EXISTS public."UQE_access_token_sha1";
DROP INDEX IF EXISTS public."UQE_access_s";
DROP INDEX IF EXISTS public."IDX_webhook_updated_unix";
DROP INDEX IF EXISTS public."IDX_webhook_repo_id";
DROP INDEX IF EXISTS public."IDX_webhook_org_id";
DROP INDEX IF EXISTS public."IDX_webhook_is_active";
DROP INDEX IF EXISTS public."IDX_webhook_created_unix";
DROP INDEX IF EXISTS public."IDX_user_updated_unix";
DROP INDEX IF EXISTS public."IDX_user_open_id_uid";
DROP INDEX IF EXISTS public."IDX_user_last_login_unix";
DROP INDEX IF EXISTS public."IDX_user_is_active";
DROP INDEX IF EXISTS public."IDX_user_created_unix";
DROP INDEX IF EXISTS public."IDX_u2f_registration_user_id";
DROP INDEX IF EXISTS public."IDX_u2f_registration_updated_unix";
DROP INDEX IF EXISTS public."IDX_u2f_registration_created_unix";
DROP INDEX IF EXISTS public."IDX_two_factor_updated_unix";
DROP INDEX IF EXISTS public."IDX_two_factor_created_unix";
DROP INDEX IF EXISTS public."IDX_tracked_time_user_id";
DROP INDEX IF EXISTS public."IDX_tracked_time_issue_id";
DROP INDEX IF EXISTS public."IDX_topic_updated_unix";
DROP INDEX IF EXISTS public."IDX_topic_created_unix";
DROP INDEX IF EXISTS public."IDX_team_user_org_id";
DROP INDEX IF EXISTS public."IDX_team_unit_org_id";
DROP INDEX IF EXISTS public."IDX_team_repo_org_id";
DROP INDEX IF EXISTS public."IDX_team_org_id";
DROP INDEX IF EXISTS public."IDX_stopwatch_user_id";
DROP INDEX IF EXISTS public."IDX_stopwatch_issue_id";
DROP INDEX IF EXISTS public."IDX_repository_updated_unix";
DROP INDEX IF EXISTS public."IDX_repository_name";
DROP INDEX IF EXISTS public."IDX_repository_lower_name";
DROP INDEX IF EXISTS public."IDX_repository_is_private";
DROP INDEX IF EXISTS public."IDX_repository_is_mirror";
DROP INDEX IF EXISTS public."IDX_repository_is_fork";
DROP INDEX IF EXISTS public."IDX_repository_is_bare";
DROP INDEX IF EXISTS public."IDX_repository_fork_id";
DROP INDEX IF EXISTS public."IDX_repository_created_unix";
DROP INDEX IF EXISTS public."IDX_repo_unit_s";
DROP INDEX IF EXISTS public."IDX_repo_unit_created_unix";
DROP INDEX IF EXISTS public."IDX_repo_redirect_lower_name";
DROP INDEX IF EXISTS public."IDX_repo_indexer_status_repo_id";
DROP INDEX IF EXISTS public."IDX_release_tag_name";
DROP INDEX IF EXISTS public."IDX_release_repo_id";
DROP INDEX IF EXISTS public."IDX_release_publisher_id";
DROP INDEX IF EXISTS public."IDX_release_created_unix";
DROP INDEX IF EXISTS public."IDX_reaction_user_id";
DROP INDEX IF EXISTS public."IDX_reaction_type";
DROP INDEX IF EXISTS public."IDX_reaction_issue_id";
DROP INDEX IF EXISTS public."IDX_reaction_created_unix";
DROP INDEX IF EXISTS public."IDX_reaction_comment_id";
DROP INDEX IF EXISTS public."IDX_pull_request_merger_id";
DROP INDEX IF EXISTS public."IDX_pull_request_merged_unix";
DROP INDEX IF EXISTS public."IDX_pull_request_issue_id";
DROP INDEX IF EXISTS public."IDX_pull_request_head_repo_id";
DROP INDEX IF EXISTS public."IDX_pull_request_has_merged";
DROP INDEX IF EXISTS public."IDX_pull_request_base_repo_id";
DROP INDEX IF EXISTS public."IDX_public_key_owner_id";
DROP INDEX IF EXISTS public."IDX_org_user_uid";
DROP INDEX IF EXISTS public."IDX_org_user_org_id";
DROP INDEX IF EXISTS public."IDX_org_user_is_public";
DROP INDEX IF EXISTS public."IDX_oauth2_session_expires_unix";
DROP INDEX IF EXISTS public."IDX_notification_user_id";
DROP INDEX IF EXISTS public."IDX_notification_updated_unix";
DROP INDEX IF EXISTS public."IDX_notification_updated_by";
DROP INDEX IF EXISTS public."IDX_notification_status";
DROP INDEX IF EXISTS public."IDX_notification_source";
DROP INDEX IF EXISTS public."IDX_notification_repo_id";
DROP INDEX IF EXISTS public."IDX_notification_issue_id";
DROP INDEX IF EXISTS public."IDX_notification_created_unix";
DROP INDEX IF EXISTS public."IDX_notification_commit_id";
DROP INDEX IF EXISTS public."IDX_notice_created_unix";
DROP INDEX IF EXISTS public."IDX_mirror_updated_unix";
DROP INDEX IF EXISTS public."IDX_mirror_repo_id";
DROP INDEX IF EXISTS public."IDX_mirror_next_update_unix";
DROP INDEX IF EXISTS public."IDX_milestone_repo_id";
DROP INDEX IF EXISTS public."IDX_login_source_updated_unix";
DROP INDEX IF EXISTS public."IDX_login_source_is_sync_enabled";
DROP INDEX IF EXISTS public."IDX_login_source_is_actived";
DROP INDEX IF EXISTS public."IDX_login_source_created_unix";
DROP INDEX IF EXISTS public."IDX_lfs_meta_object_repository_id";
DROP INDEX IF EXISTS public."IDX_lfs_meta_object_oid";
DROP INDEX IF EXISTS public."IDX_lfs_lock_repo_id";
DROP INDEX IF EXISTS public."IDX_lfs_lock_owner_id";
DROP INDEX IF EXISTS public."IDX_label_repo_id";
DROP INDEX IF EXISTS public."IDX_issue_user_uid";
DROP INDEX IF EXISTS public."IDX_issue_updated_unix";
DROP INDEX IF EXISTS public."IDX_issue_repo_id";
DROP INDEX IF EXISTS public."IDX_issue_poster_id";
DROP INDEX IF EXISTS public."IDX_issue_milestone_id";
DROP INDEX IF EXISTS public."IDX_issue_is_pull";
DROP INDEX IF EXISTS public."IDX_issue_is_closed";
DROP INDEX IF EXISTS public."IDX_issue_deadline_unix";
DROP INDEX IF EXISTS public."IDX_issue_created_unix";
DROP INDEX IF EXISTS public."IDX_issue_closed_unix";
DROP INDEX IF EXISTS public."IDX_issue_assignees_issue_id";
DROP INDEX IF EXISTS public."IDX_issue_assignees_assignee_id";
DROP INDEX IF EXISTS public."IDX_hook_task_repo_id";
DROP INDEX IF EXISTS public."IDX_gpg_key_owner_id";
DROP INDEX IF EXISTS public."IDX_gpg_key_key_id";
DROP INDEX IF EXISTS public."IDX_external_login_user_user_id";
DROP INDEX IF EXISTS public."IDX_email_address_uid";
DROP INDEX IF EXISTS public."IDX_deploy_key_repo_id";
DROP INDEX IF EXISTS public."IDX_deploy_key_key_id";
DROP INDEX IF EXISTS public."IDX_deleted_branch_repo_id";
DROP INDEX IF EXISTS public."IDX_deleted_branch_deleted_unix";
DROP INDEX IF EXISTS public."IDX_deleted_branch_deleted_by_id";
DROP INDEX IF EXISTS public."IDX_commit_status_updated_unix";
DROP INDEX IF EXISTS public."IDX_commit_status_sha";
DROP INDEX IF EXISTS public."IDX_commit_status_repo_id";
DROP INDEX IF EXISTS public."IDX_commit_status_index";
DROP INDEX IF EXISTS public."IDX_commit_status_created_unix";
DROP INDEX IF EXISTS public."IDX_comment_updated_unix";
DROP INDEX IF EXISTS public."IDX_comment_poster_id";
DROP INDEX IF EXISTS public."IDX_comment_issue_id";
DROP INDEX IF EXISTS public."IDX_comment_created_unix";
DROP INDEX IF EXISTS public."IDX_collaboration_user_id";
DROP INDEX IF EXISTS public."IDX_collaboration_repo_id";
DROP INDEX IF EXISTS public."IDX_attachment_release_id";
DROP INDEX IF EXISTS public."IDX_attachment_issue_id";
DROP INDEX IF EXISTS public."IDX_action_user_id";
DROP INDEX IF EXISTS public."IDX_action_repo_id";
DROP INDEX IF EXISTS public."IDX_action_is_private";
DROP INDEX IF EXISTS public."IDX_action_is_deleted";
DROP INDEX IF EXISTS public."IDX_action_created_unix";
DROP INDEX IF EXISTS public."IDX_action_comment_id";
DROP INDEX IF EXISTS public."IDX_action_act_user_id";
DROP INDEX IF EXISTS public."IDX_access_token_updated_unix";
DROP INDEX IF EXISTS public."IDX_access_token_uid";
DROP INDEX IF EXISTS public."IDX_access_token_created_unix";
ALTER TABLE IF EXISTS ONLY public.webhook DROP CONSTRAINT webhook_pkey;
ALTER TABLE IF EXISTS ONLY public.watch DROP CONSTRAINT watch_pkey;
ALTER TABLE IF EXISTS ONLY public.version DROP CONSTRAINT version_pkey;
ALTER TABLE IF EXISTS ONLY public."user" DROP CONSTRAINT user_pkey;
ALTER TABLE IF EXISTS ONLY public.user_open_id DROP CONSTRAINT user_open_id_pkey;
ALTER TABLE IF EXISTS ONLY public.upload DROP CONSTRAINT upload_pkey;
ALTER TABLE IF EXISTS ONLY public.u2f_registration DROP CONSTRAINT u2f_registration_pkey;
ALTER TABLE IF EXISTS ONLY public.two_factor DROP CONSTRAINT two_factor_pkey;
ALTER TABLE IF EXISTS ONLY public.tracked_time DROP CONSTRAINT tracked_time_pkey;
ALTER TABLE IF EXISTS ONLY public.topic DROP CONSTRAINT topic_pkey;
ALTER TABLE IF EXISTS ONLY public.team_user DROP CONSTRAINT team_user_pkey;
ALTER TABLE IF EXISTS ONLY public.team_unit DROP CONSTRAINT team_unit_pkey;
ALTER TABLE IF EXISTS ONLY public.team_repo DROP CONSTRAINT team_repo_pkey;
ALTER TABLE IF EXISTS ONLY public.team DROP CONSTRAINT team_pkey;
ALTER TABLE IF EXISTS ONLY public.stopwatch DROP CONSTRAINT stopwatch_pkey;
ALTER TABLE IF EXISTS ONLY public.star DROP CONSTRAINT star_pkey;
ALTER TABLE IF EXISTS ONLY public.repository DROP CONSTRAINT repository_pkey;
ALTER TABLE IF EXISTS ONLY public.repo_unit DROP CONSTRAINT repo_unit_pkey;
ALTER TABLE IF EXISTS ONLY public.repo_redirect DROP CONSTRAINT repo_redirect_pkey;
ALTER TABLE IF EXISTS ONLY public.repo_indexer_status DROP CONSTRAINT repo_indexer_status_pkey;
ALTER TABLE IF EXISTS ONLY public.release DROP CONSTRAINT release_pkey;
ALTER TABLE IF EXISTS ONLY public.reaction DROP CONSTRAINT reaction_pkey;
ALTER TABLE IF EXISTS ONLY public.pull_request DROP CONSTRAINT pull_request_pkey;
ALTER TABLE IF EXISTS ONLY public.public_key DROP CONSTRAINT public_key_pkey;
ALTER TABLE IF EXISTS ONLY public.protected_branch DROP CONSTRAINT protected_branch_pkey;
ALTER TABLE IF EXISTS ONLY public.org_user DROP CONSTRAINT org_user_pkey;
ALTER TABLE IF EXISTS ONLY public.oauth2_session DROP CONSTRAINT oauth2_session_pkey;
ALTER TABLE IF EXISTS ONLY public.notification DROP CONSTRAINT notification_pkey;
ALTER TABLE IF EXISTS ONLY public.notice DROP CONSTRAINT notice_pkey;
ALTER TABLE IF EXISTS ONLY public.mirror DROP CONSTRAINT mirror_pkey;
ALTER TABLE IF EXISTS ONLY public.milestone DROP CONSTRAINT milestone_pkey;
ALTER TABLE IF EXISTS ONLY public.login_source DROP CONSTRAINT login_source_pkey;
ALTER TABLE IF EXISTS ONLY public.lfs_meta_object DROP CONSTRAINT lfs_meta_object_pkey;
ALTER TABLE IF EXISTS ONLY public.lfs_lock DROP CONSTRAINT lfs_lock_pkey;
ALTER TABLE IF EXISTS ONLY public.label DROP CONSTRAINT label_pkey;
ALTER TABLE IF EXISTS ONLY public.issue_watch DROP CONSTRAINT issue_watch_pkey;
ALTER TABLE IF EXISTS ONLY public.issue_user DROP CONSTRAINT issue_user_pkey;
ALTER TABLE IF EXISTS ONLY public.issue DROP CONSTRAINT issue_pkey;
ALTER TABLE IF EXISTS ONLY public.issue_label DROP CONSTRAINT issue_label_pkey;
ALTER TABLE IF EXISTS ONLY public.issue_assignees DROP CONSTRAINT issue_assignees_pkey;
ALTER TABLE IF EXISTS ONLY public.hook_task DROP CONSTRAINT hook_task_pkey;
ALTER TABLE IF EXISTS ONLY public.gpg_key DROP CONSTRAINT gpg_key_pkey;
ALTER TABLE IF EXISTS ONLY public.follow DROP CONSTRAINT follow_pkey;
ALTER TABLE IF EXISTS ONLY public.external_login_user DROP CONSTRAINT external_login_user_pkey;
ALTER TABLE IF EXISTS ONLY public.email_address DROP CONSTRAINT email_address_pkey;
ALTER TABLE IF EXISTS ONLY public.deploy_key DROP CONSTRAINT deploy_key_pkey;
ALTER TABLE IF EXISTS ONLY public.deleted_branch DROP CONSTRAINT deleted_branch_pkey;
ALTER TABLE IF EXISTS ONLY public.commit_status DROP CONSTRAINT commit_status_pkey;
ALTER TABLE IF EXISTS ONLY public.comment DROP CONSTRAINT comment_pkey;
ALTER TABLE IF EXISTS ONLY public.collaboration DROP CONSTRAINT collaboration_pkey;
ALTER TABLE IF EXISTS ONLY public.attachment DROP CONSTRAINT attachment_pkey;
ALTER TABLE IF EXISTS ONLY public.action DROP CONSTRAINT action_pkey;
ALTER TABLE IF EXISTS ONLY public.access_token DROP CONSTRAINT access_token_pkey;
ALTER TABLE IF EXISTS ONLY public.access DROP CONSTRAINT access_pkey;
ALTER TABLE IF EXISTS public.webhook ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.watch ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.version ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_open_id ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public."user" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.upload ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.u2f_registration ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.two_factor ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.tracked_time ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.topic ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.team_user ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.team_unit ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.team_repo ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.team ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.stopwatch ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.star ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.repository ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.repo_unit ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.repo_redirect ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.repo_indexer_status ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.release ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.reaction ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.pull_request ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.public_key ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.protected_branch ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.org_user ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.notification ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.notice ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.mirror ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.milestone ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.login_source ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.lfs_meta_object ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.lfs_lock ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.label ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.issue_watch ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.issue_user ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.issue_label ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.issue_assignees ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.issue ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.hook_task ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.gpg_key ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.follow ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.email_address ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.deploy_key ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.deleted_branch ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commit_status ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.comment ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.collaboration ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.attachment ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.action ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.access_token ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.access ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.webhook_id_seq;
DROP TABLE IF EXISTS public.webhook;
DROP SEQUENCE IF EXISTS public.watch_id_seq;
DROP TABLE IF EXISTS public.watch;
DROP SEQUENCE IF EXISTS public.version_id_seq;
DROP TABLE IF EXISTS public.version;
DROP SEQUENCE IF EXISTS public.user_open_id_id_seq;
DROP TABLE IF EXISTS public.user_open_id;
DROP SEQUENCE IF EXISTS public.user_id_seq;
DROP TABLE IF EXISTS public."user";
DROP SEQUENCE IF EXISTS public.upload_id_seq;
DROP TABLE IF EXISTS public.upload;
DROP SEQUENCE IF EXISTS public.u2f_registration_id_seq;
DROP TABLE IF EXISTS public.u2f_registration;
DROP SEQUENCE IF EXISTS public.two_factor_id_seq;
DROP TABLE IF EXISTS public.two_factor;
DROP SEQUENCE IF EXISTS public.tracked_time_id_seq;
DROP TABLE IF EXISTS public.tracked_time;
DROP SEQUENCE IF EXISTS public.topic_id_seq;
DROP TABLE IF EXISTS public.topic;
DROP SEQUENCE IF EXISTS public.team_user_id_seq;
DROP TABLE IF EXISTS public.team_user;
DROP SEQUENCE IF EXISTS public.team_unit_id_seq;
DROP TABLE IF EXISTS public.team_unit;
DROP SEQUENCE IF EXISTS public.team_repo_id_seq;
DROP TABLE IF EXISTS public.team_repo;
DROP SEQUENCE IF EXISTS public.team_id_seq;
DROP TABLE IF EXISTS public.team;
DROP SEQUENCE IF EXISTS public.stopwatch_id_seq;
DROP TABLE IF EXISTS public.stopwatch;
DROP SEQUENCE IF EXISTS public.star_id_seq;
DROP TABLE IF EXISTS public.star;
DROP SEQUENCE IF EXISTS public.repository_id_seq;
DROP TABLE IF EXISTS public.repository;
DROP SEQUENCE IF EXISTS public.repo_unit_id_seq;
DROP TABLE IF EXISTS public.repo_unit;
DROP TABLE IF EXISTS public.repo_topic;
DROP SEQUENCE IF EXISTS public.repo_redirect_id_seq;
DROP TABLE IF EXISTS public.repo_redirect;
DROP SEQUENCE IF EXISTS public.repo_indexer_status_id_seq;
DROP TABLE IF EXISTS public.repo_indexer_status;
DROP SEQUENCE IF EXISTS public.release_id_seq;
DROP TABLE IF EXISTS public.release;
DROP SEQUENCE IF EXISTS public.reaction_id_seq;
DROP TABLE IF EXISTS public.reaction;
DROP SEQUENCE IF EXISTS public.pull_request_id_seq;
DROP TABLE IF EXISTS public.pull_request;
DROP SEQUENCE IF EXISTS public.public_key_id_seq;
DROP TABLE IF EXISTS public.public_key;
DROP SEQUENCE IF EXISTS public.protected_branch_id_seq;
DROP TABLE IF EXISTS public.protected_branch;
DROP SEQUENCE IF EXISTS public.org_user_id_seq;
DROP TABLE IF EXISTS public.org_user;
DROP TABLE IF EXISTS public.oauth2_session;
DROP SEQUENCE IF EXISTS public.notification_id_seq;
DROP TABLE IF EXISTS public.notification;
DROP SEQUENCE IF EXISTS public.notice_id_seq;
DROP TABLE IF EXISTS public.notice;
DROP SEQUENCE IF EXISTS public.mirror_id_seq;
DROP TABLE IF EXISTS public.mirror;
DROP SEQUENCE IF EXISTS public.milestone_id_seq;
DROP TABLE IF EXISTS public.milestone;
DROP SEQUENCE IF EXISTS public.login_source_id_seq;
DROP TABLE IF EXISTS public.login_source;
DROP SEQUENCE IF EXISTS public.lfs_meta_object_id_seq;
DROP TABLE IF EXISTS public.lfs_meta_object;
DROP SEQUENCE IF EXISTS public.lfs_lock_id_seq;
DROP TABLE IF EXISTS public.lfs_lock;
DROP SEQUENCE IF EXISTS public.label_id_seq;
DROP TABLE IF EXISTS public.label;
DROP SEQUENCE IF EXISTS public.issue_watch_id_seq;
DROP TABLE IF EXISTS public.issue_watch;
DROP SEQUENCE IF EXISTS public.issue_user_id_seq;
DROP TABLE IF EXISTS public.issue_user;
DROP SEQUENCE IF EXISTS public.issue_label_id_seq;
DROP TABLE IF EXISTS public.issue_label;
DROP SEQUENCE IF EXISTS public.issue_id_seq;
DROP SEQUENCE IF EXISTS public.issue_assignees_id_seq;
DROP TABLE IF EXISTS public.issue_assignees;
DROP TABLE IF EXISTS public.issue;
DROP SEQUENCE IF EXISTS public.hook_task_id_seq;
DROP TABLE IF EXISTS public.hook_task;
DROP SEQUENCE IF EXISTS public.gpg_key_id_seq;
DROP TABLE IF EXISTS public.gpg_key;
DROP SEQUENCE IF EXISTS public.follow_id_seq;
DROP TABLE IF EXISTS public.follow;
DROP TABLE IF EXISTS public.external_login_user;
DROP SEQUENCE IF EXISTS public.email_address_id_seq;
DROP TABLE IF EXISTS public.email_address;
DROP SEQUENCE IF EXISTS public.deploy_key_id_seq;
DROP TABLE IF EXISTS public.deploy_key;
DROP SEQUENCE IF EXISTS public.deleted_branch_id_seq;
DROP TABLE IF EXISTS public.deleted_branch;
DROP SEQUENCE IF EXISTS public.commit_status_id_seq;
DROP TABLE IF EXISTS public.commit_status;
DROP SEQUENCE IF EXISTS public.comment_id_seq;
DROP TABLE IF EXISTS public.comment;
DROP SEQUENCE IF EXISTS public.collaboration_id_seq;
DROP TABLE IF EXISTS public.collaboration;
DROP SEQUENCE IF EXISTS public.attachment_id_seq;
DROP TABLE IF EXISTS public.attachment;
DROP SEQUENCE IF EXISTS public.action_id_seq;
DROP TABLE IF EXISTS public.action;
DROP SEQUENCE IF EXISTS public.access_token_id_seq;
DROP TABLE IF EXISTS public.access_token;
DROP SEQUENCE IF EXISTS public.access_id_seq;
DROP TABLE IF EXISTS public.access;
DROP EXTENSION IF EXISTS plpgsql;
DROP SCHEMA IF EXISTS public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: access; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.access (
    id bigint NOT NULL,
    user_id bigint,
    repo_id bigint,
    mode integer
);


ALTER TABLE public.access OWNER TO postgres;

--
-- Name: access_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.access_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.access_id_seq OWNER TO postgres;

--
-- Name: access_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.access_id_seq OWNED BY public.access.id;


--
-- Name: access_token; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.access_token (
    id bigint NOT NULL,
    uid bigint,
    name character varying(255),
    sha1 character varying(40),
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE public.access_token OWNER TO postgres;

--
-- Name: access_token_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.access_token_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.access_token_id_seq OWNER TO postgres;

--
-- Name: access_token_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.access_token_id_seq OWNED BY public.access_token.id;


--
-- Name: action; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.action (
    id bigint NOT NULL,
    user_id bigint,
    op_type integer,
    act_user_id bigint,
    repo_id bigint,
    comment_id bigint,
    is_deleted boolean DEFAULT false NOT NULL,
    ref_name character varying(255),
    is_private boolean DEFAULT false NOT NULL,
    content text,
    created_unix bigint
);


ALTER TABLE public.action OWNER TO postgres;

--
-- Name: action_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.action_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.action_id_seq OWNER TO postgres;

--
-- Name: action_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.action_id_seq OWNED BY public.action.id;


--
-- Name: attachment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attachment (
    id bigint NOT NULL,
    uuid uuid,
    issue_id bigint,
    release_id bigint,
    comment_id bigint,
    name character varying(255),
    download_count bigint DEFAULT 0,
    size bigint DEFAULT 0,
    created_unix bigint
);


ALTER TABLE public.attachment OWNER TO postgres;

--
-- Name: attachment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attachment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.attachment_id_seq OWNER TO postgres;

--
-- Name: attachment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attachment_id_seq OWNED BY public.attachment.id;


--
-- Name: collaboration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.collaboration (
    id bigint NOT NULL,
    repo_id bigint NOT NULL,
    user_id bigint NOT NULL,
    mode integer DEFAULT 2 NOT NULL
);


ALTER TABLE public.collaboration OWNER TO postgres;

--
-- Name: collaboration_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.collaboration_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.collaboration_id_seq OWNER TO postgres;

--
-- Name: collaboration_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.collaboration_id_seq OWNED BY public.collaboration.id;


--
-- Name: comment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.comment (
    id bigint NOT NULL,
    type integer,
    poster_id bigint,
    issue_id bigint,
    label_id bigint,
    old_milestone_id bigint,
    milestone_id bigint,
    assignee_id bigint,
    removed_assignee boolean,
    old_title character varying(255),
    new_title character varying(255),
    commit_id bigint,
    line bigint,
    content text,
    created_unix bigint,
    updated_unix bigint,
    commit_sha character varying(40)
);


ALTER TABLE public.comment OWNER TO postgres;

--
-- Name: comment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.comment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.comment_id_seq OWNER TO postgres;

--
-- Name: comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.comment_id_seq OWNED BY public.comment.id;


--
-- Name: commit_status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.commit_status (
    id bigint NOT NULL,
    index bigint,
    repo_id bigint,
    state character varying(7) NOT NULL,
    sha character varying(64) NOT NULL,
    target_url text,
    description text,
    context text,
    creator_id bigint,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE public.commit_status OWNER TO postgres;

--
-- Name: commit_status_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.commit_status_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.commit_status_id_seq OWNER TO postgres;

--
-- Name: commit_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.commit_status_id_seq OWNED BY public.commit_status.id;


--
-- Name: deleted_branch; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.deleted_branch (
    id bigint NOT NULL,
    repo_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    commit character varying(255) NOT NULL,
    deleted_by_id bigint,
    deleted_unix bigint
);


ALTER TABLE public.deleted_branch OWNER TO postgres;

--
-- Name: deleted_branch_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.deleted_branch_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.deleted_branch_id_seq OWNER TO postgres;

--
-- Name: deleted_branch_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.deleted_branch_id_seq OWNED BY public.deleted_branch.id;


--
-- Name: deploy_key; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.deploy_key (
    id bigint NOT NULL,
    key_id bigint,
    repo_id bigint,
    name character varying(255),
    fingerprint character varying(255),
    mode integer DEFAULT 1 NOT NULL,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE public.deploy_key OWNER TO postgres;

--
-- Name: deploy_key_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.deploy_key_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.deploy_key_id_seq OWNER TO postgres;

--
-- Name: deploy_key_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.deploy_key_id_seq OWNED BY public.deploy_key.id;


--
-- Name: email_address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.email_address (
    id bigint NOT NULL,
    uid bigint NOT NULL,
    email character varying(255) NOT NULL,
    is_activated boolean
);


ALTER TABLE public.email_address OWNER TO postgres;

--
-- Name: email_address_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.email_address_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.email_address_id_seq OWNER TO postgres;

--
-- Name: email_address_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.email_address_id_seq OWNED BY public.email_address.id;


--
-- Name: external_login_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.external_login_user (
    external_id character varying(255) NOT NULL,
    user_id bigint NOT NULL,
    login_source_id bigint NOT NULL
);


ALTER TABLE public.external_login_user OWNER TO postgres;

--
-- Name: follow; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.follow (
    id bigint NOT NULL,
    user_id bigint,
    follow_id bigint
);


ALTER TABLE public.follow OWNER TO postgres;

--
-- Name: follow_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.follow_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.follow_id_seq OWNER TO postgres;

--
-- Name: follow_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.follow_id_seq OWNED BY public.follow.id;


--
-- Name: gpg_key; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gpg_key (
    id bigint NOT NULL,
    owner_id bigint NOT NULL,
    key_id character(16) NOT NULL,
    primary_key_id character(16),
    content text NOT NULL,
    created_unix bigint,
    expired_unix bigint,
    added_unix bigint,
    emails text,
    can_sign boolean,
    can_encrypt_comms boolean,
    can_encrypt_storage boolean,
    can_certify boolean
);


ALTER TABLE public.gpg_key OWNER TO postgres;

--
-- Name: gpg_key_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.gpg_key_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gpg_key_id_seq OWNER TO postgres;

--
-- Name: gpg_key_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.gpg_key_id_seq OWNED BY public.gpg_key.id;


--
-- Name: hook_task; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.hook_task (
    id bigint NOT NULL,
    repo_id bigint,
    hook_id bigint,
    uuid character varying(255),
    type integer,
    url text,
    payload_content text,
    content_type integer,
    event_type character varying(255),
    is_ssl boolean,
    is_delivered boolean,
    delivered bigint,
    is_succeed boolean,
    request_content text,
    response_content text
);


ALTER TABLE public.hook_task OWNER TO postgres;

--
-- Name: hook_task_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.hook_task_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.hook_task_id_seq OWNER TO postgres;

--
-- Name: hook_task_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.hook_task_id_seq OWNED BY public.hook_task.id;


--
-- Name: issue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.issue (
    id bigint NOT NULL,
    repo_id bigint,
    index bigint,
    poster_id bigint,
    name character varying(255),
    content text,
    milestone_id bigint,
    priority integer,
    is_closed boolean,
    is_pull boolean,
    num_comments integer,
    ref character varying(255),
    deadline_unix bigint,
    created_unix bigint,
    updated_unix bigint,
    closed_unix bigint
);


ALTER TABLE public.issue OWNER TO postgres;

--
-- Name: issue_assignees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.issue_assignees (
    id bigint NOT NULL,
    assignee_id bigint,
    issue_id bigint
);


ALTER TABLE public.issue_assignees OWNER TO postgres;

--
-- Name: issue_assignees_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.issue_assignees_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.issue_assignees_id_seq OWNER TO postgres;

--
-- Name: issue_assignees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.issue_assignees_id_seq OWNED BY public.issue_assignees.id;


--
-- Name: issue_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.issue_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.issue_id_seq OWNER TO postgres;

--
-- Name: issue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.issue_id_seq OWNED BY public.issue.id;


--
-- Name: issue_label; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.issue_label (
    id bigint NOT NULL,
    issue_id bigint,
    label_id bigint
);


ALTER TABLE public.issue_label OWNER TO postgres;

--
-- Name: issue_label_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.issue_label_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.issue_label_id_seq OWNER TO postgres;

--
-- Name: issue_label_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.issue_label_id_seq OWNED BY public.issue_label.id;


--
-- Name: issue_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.issue_user (
    id bigint NOT NULL,
    uid bigint,
    issue_id bigint,
    is_read boolean,
    is_mentioned boolean
);


ALTER TABLE public.issue_user OWNER TO postgres;

--
-- Name: issue_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.issue_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.issue_user_id_seq OWNER TO postgres;

--
-- Name: issue_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.issue_user_id_seq OWNED BY public.issue_user.id;


--
-- Name: issue_watch; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.issue_watch (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    issue_id bigint NOT NULL,
    is_watching boolean NOT NULL,
    created_unix bigint NOT NULL,
    updated_unix bigint NOT NULL
);


ALTER TABLE public.issue_watch OWNER TO postgres;

--
-- Name: issue_watch_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.issue_watch_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.issue_watch_id_seq OWNER TO postgres;

--
-- Name: issue_watch_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.issue_watch_id_seq OWNED BY public.issue_watch.id;


--
-- Name: label; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.label (
    id bigint NOT NULL,
    repo_id bigint,
    name character varying(255),
    description character varying(255),
    color character varying(7),
    num_issues integer,
    num_closed_issues integer
);


ALTER TABLE public.label OWNER TO postgres;

--
-- Name: label_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.label_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.label_id_seq OWNER TO postgres;

--
-- Name: label_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.label_id_seq OWNED BY public.label.id;


--
-- Name: lfs_lock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lfs_lock (
    id bigint NOT NULL,
    repo_id bigint NOT NULL,
    owner_id bigint NOT NULL,
    path text,
    created timestamp without time zone
);


ALTER TABLE public.lfs_lock OWNER TO postgres;

--
-- Name: lfs_lock_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.lfs_lock_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lfs_lock_id_seq OWNER TO postgres;

--
-- Name: lfs_lock_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.lfs_lock_id_seq OWNED BY public.lfs_lock.id;


--
-- Name: lfs_meta_object; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lfs_meta_object (
    id bigint NOT NULL,
    oid character varying(255) NOT NULL,
    size bigint NOT NULL,
    repository_id bigint NOT NULL,
    created_unix bigint
);


ALTER TABLE public.lfs_meta_object OWNER TO postgres;

--
-- Name: lfs_meta_object_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.lfs_meta_object_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lfs_meta_object_id_seq OWNER TO postgres;

--
-- Name: lfs_meta_object_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.lfs_meta_object_id_seq OWNED BY public.lfs_meta_object.id;


--
-- Name: login_source; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.login_source (
    id bigint NOT NULL,
    type integer,
    name character varying(255),
    is_actived boolean DEFAULT false NOT NULL,
    is_sync_enabled boolean DEFAULT false NOT NULL,
    cfg text,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE public.login_source OWNER TO postgres;

--
-- Name: login_source_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.login_source_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.login_source_id_seq OWNER TO postgres;

--
-- Name: login_source_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.login_source_id_seq OWNED BY public.login_source.id;


--
-- Name: milestone; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.milestone (
    id bigint NOT NULL,
    repo_id bigint,
    name character varying(255),
    content text,
    is_closed boolean,
    num_issues integer,
    num_closed_issues integer,
    completeness integer,
    deadline_unix bigint,
    closed_date_unix bigint
);


ALTER TABLE public.milestone OWNER TO postgres;

--
-- Name: milestone_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.milestone_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.milestone_id_seq OWNER TO postgres;

--
-- Name: milestone_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.milestone_id_seq OWNED BY public.milestone.id;


--
-- Name: mirror; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mirror (
    id bigint NOT NULL,
    repo_id bigint,
    "interval" bigint,
    enable_prune boolean DEFAULT true NOT NULL,
    updated_unix bigint,
    next_update_unix bigint
);


ALTER TABLE public.mirror OWNER TO postgres;

--
-- Name: mirror_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mirror_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mirror_id_seq OWNER TO postgres;

--
-- Name: mirror_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mirror_id_seq OWNED BY public.mirror.id;


--
-- Name: notice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notice (
    id bigint NOT NULL,
    type integer,
    description text,
    created_unix bigint
);


ALTER TABLE public.notice OWNER TO postgres;

--
-- Name: notice_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notice_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notice_id_seq OWNER TO postgres;

--
-- Name: notice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notice_id_seq OWNED BY public.notice.id;


--
-- Name: notification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    repo_id bigint NOT NULL,
    status smallint NOT NULL,
    source smallint NOT NULL,
    issue_id bigint NOT NULL,
    commit_id character varying(255),
    updated_by bigint NOT NULL,
    created_unix bigint NOT NULL,
    updated_unix bigint NOT NULL
);


ALTER TABLE public.notification OWNER TO postgres;

--
-- Name: notification_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notification_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notification_id_seq OWNER TO postgres;

--
-- Name: notification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notification_id_seq OWNED BY public.notification.id;


--
-- Name: oauth2_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth2_session (
    id character varying(100) NOT NULL,
    data text,
    created_unix bigint,
    updated_unix bigint,
    expires_unix bigint
);


ALTER TABLE public.oauth2_session OWNER TO postgres;

--
-- Name: org_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.org_user (
    id bigint NOT NULL,
    uid bigint,
    org_id bigint,
    is_public boolean
);


ALTER TABLE public.org_user OWNER TO postgres;

--
-- Name: org_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.org_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.org_user_id_seq OWNER TO postgres;

--
-- Name: org_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.org_user_id_seq OWNED BY public.org_user.id;


--
-- Name: protected_branch; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.protected_branch (
    id bigint NOT NULL,
    repo_id bigint,
    branch_name character varying(255),
    can_push boolean DEFAULT false NOT NULL,
    enable_whitelist boolean,
    whitelist_user_i_ds text,
    whitelist_team_i_ds text,
    enable_merge_whitelist boolean DEFAULT false NOT NULL,
    merge_whitelist_user_i_ds text,
    merge_whitelist_team_i_ds text,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE public.protected_branch OWNER TO postgres;

--
-- Name: protected_branch_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.protected_branch_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.protected_branch_id_seq OWNER TO postgres;

--
-- Name: protected_branch_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.protected_branch_id_seq OWNED BY public.protected_branch.id;


--
-- Name: public_key; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.public_key (
    id bigint NOT NULL,
    owner_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    fingerprint character varying(255) NOT NULL,
    content text NOT NULL,
    mode integer DEFAULT 2 NOT NULL,
    type integer DEFAULT 1 NOT NULL,
    login_source_id bigint DEFAULT 0 NOT NULL,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE public.public_key OWNER TO postgres;

--
-- Name: public_key_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.public_key_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.public_key_id_seq OWNER TO postgres;

--
-- Name: public_key_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.public_key_id_seq OWNED BY public.public_key.id;


--
-- Name: pull_request; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pull_request (
    id bigint NOT NULL,
    type integer,
    status integer,
    issue_id bigint,
    index bigint,
    head_repo_id bigint,
    base_repo_id bigint,
    head_user_name character varying(255),
    head_branch character varying(255),
    base_branch character varying(255),
    merge_base character varying(40),
    has_merged boolean,
    merged_commit_id character varying(40),
    merger_id bigint,
    merged_unix bigint
);


ALTER TABLE public.pull_request OWNER TO postgres;

--
-- Name: pull_request_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pull_request_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pull_request_id_seq OWNER TO postgres;

--
-- Name: pull_request_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pull_request_id_seq OWNED BY public.pull_request.id;


--
-- Name: reaction; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reaction (
    id bigint NOT NULL,
    type character varying(255) NOT NULL,
    issue_id bigint NOT NULL,
    comment_id bigint,
    user_id bigint NOT NULL,
    created_unix bigint
);


ALTER TABLE public.reaction OWNER TO postgres;

--
-- Name: reaction_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reaction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reaction_id_seq OWNER TO postgres;

--
-- Name: reaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reaction_id_seq OWNED BY public.reaction.id;


--
-- Name: release; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.release (
    id bigint NOT NULL,
    repo_id bigint,
    publisher_id bigint,
    tag_name character varying(255),
    lower_tag_name character varying(255),
    target character varying(255),
    title character varying(255),
    sha1 character varying(40),
    num_commits bigint,
    note text,
    is_draft boolean DEFAULT false NOT NULL,
    is_prerelease boolean DEFAULT false NOT NULL,
    is_tag boolean DEFAULT false NOT NULL,
    created_unix bigint
);


ALTER TABLE public.release OWNER TO postgres;

--
-- Name: release_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.release_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.release_id_seq OWNER TO postgres;

--
-- Name: release_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.release_id_seq OWNED BY public.release.id;


--
-- Name: repo_indexer_status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.repo_indexer_status (
    id bigint NOT NULL,
    repo_id bigint,
    commit_sha character varying(40)
);


ALTER TABLE public.repo_indexer_status OWNER TO postgres;

--
-- Name: repo_indexer_status_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.repo_indexer_status_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.repo_indexer_status_id_seq OWNER TO postgres;

--
-- Name: repo_indexer_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.repo_indexer_status_id_seq OWNED BY public.repo_indexer_status.id;


--
-- Name: repo_redirect; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.repo_redirect (
    id bigint NOT NULL,
    owner_id bigint,
    lower_name character varying(255) NOT NULL,
    redirect_repo_id bigint
);


ALTER TABLE public.repo_redirect OWNER TO postgres;

--
-- Name: repo_redirect_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.repo_redirect_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.repo_redirect_id_seq OWNER TO postgres;

--
-- Name: repo_redirect_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.repo_redirect_id_seq OWNED BY public.repo_redirect.id;


--
-- Name: repo_topic; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.repo_topic (
    repo_id bigint,
    topic_id bigint
);


ALTER TABLE public.repo_topic OWNER TO postgres;

--
-- Name: repo_unit; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.repo_unit (
    id bigint NOT NULL,
    repo_id bigint,
    type integer,
    config text,
    created_unix bigint
);


ALTER TABLE public.repo_unit OWNER TO postgres;

--
-- Name: repo_unit_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.repo_unit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.repo_unit_id_seq OWNER TO postgres;

--
-- Name: repo_unit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.repo_unit_id_seq OWNED BY public.repo_unit.id;


--
-- Name: repository; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.repository (
    id bigint NOT NULL,
    owner_id bigint,
    lower_name character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255),
    website character varying(255),
    default_branch character varying(255),
    num_watches integer,
    num_stars integer,
    num_forks integer,
    num_issues integer,
    num_closed_issues integer,
    num_pulls integer,
    num_closed_pulls integer,
    num_milestones integer DEFAULT 0 NOT NULL,
    num_closed_milestones integer DEFAULT 0 NOT NULL,
    is_private boolean,
    is_bare boolean,
    is_mirror boolean,
    is_fork boolean DEFAULT false NOT NULL,
    fork_id bigint,
    size bigint DEFAULT 0 NOT NULL,
    is_fsck_enabled boolean DEFAULT true NOT NULL,
    topics json,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE public.repository OWNER TO postgres;

--
-- Name: repository_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.repository_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.repository_id_seq OWNER TO postgres;

--
-- Name: repository_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.repository_id_seq OWNED BY public.repository.id;


--
-- Name: star; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.star (
    id bigint NOT NULL,
    uid bigint,
    repo_id bigint
);


ALTER TABLE public.star OWNER TO postgres;

--
-- Name: star_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.star_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.star_id_seq OWNER TO postgres;

--
-- Name: star_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.star_id_seq OWNED BY public.star.id;


--
-- Name: stopwatch; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stopwatch (
    id bigint NOT NULL,
    issue_id bigint,
    user_id bigint,
    created_unix bigint
);


ALTER TABLE public.stopwatch OWNER TO postgres;

--
-- Name: stopwatch_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.stopwatch_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stopwatch_id_seq OWNER TO postgres;

--
-- Name: stopwatch_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.stopwatch_id_seq OWNED BY public.stopwatch.id;


--
-- Name: team; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.team (
    id bigint NOT NULL,
    org_id bigint,
    lower_name character varying(255),
    name character varying(255),
    description character varying(255),
    authorize integer,
    num_repos integer,
    num_members integer
);


ALTER TABLE public.team OWNER TO postgres;

--
-- Name: team_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.team_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.team_id_seq OWNER TO postgres;

--
-- Name: team_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.team_id_seq OWNED BY public.team.id;


--
-- Name: team_repo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.team_repo (
    id bigint NOT NULL,
    org_id bigint,
    team_id bigint,
    repo_id bigint
);


ALTER TABLE public.team_repo OWNER TO postgres;

--
-- Name: team_repo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.team_repo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.team_repo_id_seq OWNER TO postgres;

--
-- Name: team_repo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.team_repo_id_seq OWNED BY public.team_repo.id;


--
-- Name: team_unit; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.team_unit (
    id bigint NOT NULL,
    org_id bigint,
    team_id bigint,
    type integer
);


ALTER TABLE public.team_unit OWNER TO postgres;

--
-- Name: team_unit_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.team_unit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.team_unit_id_seq OWNER TO postgres;

--
-- Name: team_unit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.team_unit_id_seq OWNED BY public.team_unit.id;


--
-- Name: team_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.team_user (
    id bigint NOT NULL,
    org_id bigint,
    team_id bigint,
    uid bigint
);


ALTER TABLE public.team_user OWNER TO postgres;

--
-- Name: team_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.team_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.team_user_id_seq OWNER TO postgres;

--
-- Name: team_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.team_user_id_seq OWNED BY public.team_user.id;


--
-- Name: topic; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.topic (
    id bigint NOT NULL,
    name character varying(255),
    repo_count integer,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE public.topic OWNER TO postgres;

--
-- Name: topic_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.topic_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.topic_id_seq OWNER TO postgres;

--
-- Name: topic_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.topic_id_seq OWNED BY public.topic.id;


--
-- Name: tracked_time; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tracked_time (
    id bigint NOT NULL,
    issue_id bigint,
    user_id bigint,
    created_unix bigint,
    "time" bigint
);


ALTER TABLE public.tracked_time OWNER TO postgres;

--
-- Name: tracked_time_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tracked_time_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tracked_time_id_seq OWNER TO postgres;

--
-- Name: tracked_time_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tracked_time_id_seq OWNED BY public.tracked_time.id;


--
-- Name: two_factor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.two_factor (
    id bigint NOT NULL,
    uid bigint,
    secret character varying(255),
    scratch_token character varying(255),
    last_used_passcode character varying(10),
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE public.two_factor OWNER TO postgres;

--
-- Name: two_factor_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.two_factor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.two_factor_id_seq OWNER TO postgres;

--
-- Name: two_factor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.two_factor_id_seq OWNED BY public.two_factor.id;


--
-- Name: u2f_registration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.u2f_registration (
    id bigint NOT NULL,
    name character varying(255),
    user_id bigint,
    raw bytea,
    counter integer,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE public.u2f_registration OWNER TO postgres;

--
-- Name: u2f_registration_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.u2f_registration_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.u2f_registration_id_seq OWNER TO postgres;

--
-- Name: u2f_registration_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.u2f_registration_id_seq OWNED BY public.u2f_registration.id;


--
-- Name: upload; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.upload (
    id bigint NOT NULL,
    uuid uuid,
    name character varying(255)
);


ALTER TABLE public.upload OWNER TO postgres;

--
-- Name: upload_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.upload_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.upload_id_seq OWNER TO postgres;

--
-- Name: upload_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.upload_id_seq OWNED BY public.upload.id;


--
-- Name: user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."user" (
    id bigint NOT NULL,
    lower_name character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    full_name character varying(255),
    email character varying(255) NOT NULL,
    keep_email_private boolean,
    passwd character varying(255) NOT NULL,
    login_type integer,
    login_source bigint DEFAULT 0 NOT NULL,
    login_name character varying(255),
    type integer,
    location character varying(255),
    website character varying(255),
    rands character varying(10),
    salt character varying(10),
    language character varying(5),
    created_unix bigint,
    updated_unix bigint,
    last_login_unix bigint,
    last_repo_visibility boolean,
    max_repo_creation integer DEFAULT '-1'::integer NOT NULL,
    is_active boolean,
    is_admin boolean,
    allow_git_hook boolean,
    allow_import_local boolean,
    allow_create_organization boolean DEFAULT true,
    prohibit_login boolean DEFAULT false NOT NULL,
    avatar character varying(2048) NOT NULL,
    avatar_email character varying(255) NOT NULL,
    use_custom_avatar boolean,
    num_followers integer,
    num_following integer DEFAULT 0 NOT NULL,
    num_stars integer,
    num_repos integer,
    description character varying(255),
    num_teams integer,
    num_members integer,
    diff_view_style character varying(255) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE public."user" OWNER TO postgres;

--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_id_seq OWNER TO postgres;

--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_id_seq OWNED BY public."user".id;


--
-- Name: user_open_id; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_open_id (
    id bigint NOT NULL,
    uid bigint NOT NULL,
    uri character varying(255) NOT NULL,
    show boolean DEFAULT false
);


ALTER TABLE public.user_open_id OWNER TO postgres;

--
-- Name: user_open_id_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_open_id_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_open_id_id_seq OWNER TO postgres;

--
-- Name: user_open_id_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_open_id_id_seq OWNED BY public.user_open_id.id;


--
-- Name: version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.version (
    id bigint NOT NULL,
    version bigint
);


ALTER TABLE public.version OWNER TO postgres;

--
-- Name: version_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.version_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.version_id_seq OWNER TO postgres;

--
-- Name: version_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.version_id_seq OWNED BY public.version.id;


--
-- Name: watch; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.watch (
    id bigint NOT NULL,
    user_id bigint,
    repo_id bigint
);


ALTER TABLE public.watch OWNER TO postgres;

--
-- Name: watch_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.watch_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.watch_id_seq OWNER TO postgres;

--
-- Name: watch_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.watch_id_seq OWNED BY public.watch.id;


--
-- Name: webhook; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.webhook (
    id bigint NOT NULL,
    repo_id bigint,
    org_id bigint,
    url text,
    content_type integer,
    secret text,
    events text,
    is_ssl boolean,
    is_active boolean,
    hook_task_type integer,
    meta text,
    last_status integer,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE public.webhook OWNER TO postgres;

--
-- Name: webhook_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.webhook_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.webhook_id_seq OWNER TO postgres;

--
-- Name: webhook_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.webhook_id_seq OWNED BY public.webhook.id;


--
-- Name: access id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.access ALTER COLUMN id SET DEFAULT nextval('public.access_id_seq'::regclass);


--
-- Name: access_token id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.access_token ALTER COLUMN id SET DEFAULT nextval('public.access_token_id_seq'::regclass);


--
-- Name: action id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.action ALTER COLUMN id SET DEFAULT nextval('public.action_id_seq'::regclass);


--
-- Name: attachment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachment ALTER COLUMN id SET DEFAULT nextval('public.attachment_id_seq'::regclass);


--
-- Name: collaboration id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.collaboration ALTER COLUMN id SET DEFAULT nextval('public.collaboration_id_seq'::regclass);


--
-- Name: comment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comment ALTER COLUMN id SET DEFAULT nextval('public.comment_id_seq'::regclass);


--
-- Name: commit_status id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commit_status ALTER COLUMN id SET DEFAULT nextval('public.commit_status_id_seq'::regclass);


--
-- Name: deleted_branch id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deleted_branch ALTER COLUMN id SET DEFAULT nextval('public.deleted_branch_id_seq'::regclass);


--
-- Name: deploy_key id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deploy_key ALTER COLUMN id SET DEFAULT nextval('public.deploy_key_id_seq'::regclass);


--
-- Name: email_address id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_address ALTER COLUMN id SET DEFAULT nextval('public.email_address_id_seq'::regclass);


--
-- Name: follow id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.follow ALTER COLUMN id SET DEFAULT nextval('public.follow_id_seq'::regclass);


--
-- Name: gpg_key id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gpg_key ALTER COLUMN id SET DEFAULT nextval('public.gpg_key_id_seq'::regclass);


--
-- Name: hook_task id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hook_task ALTER COLUMN id SET DEFAULT nextval('public.hook_task_id_seq'::regclass);


--
-- Name: issue id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue ALTER COLUMN id SET DEFAULT nextval('public.issue_id_seq'::regclass);


--
-- Name: issue_assignees id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_assignees ALTER COLUMN id SET DEFAULT nextval('public.issue_assignees_id_seq'::regclass);


--
-- Name: issue_label id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_label ALTER COLUMN id SET DEFAULT nextval('public.issue_label_id_seq'::regclass);


--
-- Name: issue_user id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_user ALTER COLUMN id SET DEFAULT nextval('public.issue_user_id_seq'::regclass);


--
-- Name: issue_watch id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_watch ALTER COLUMN id SET DEFAULT nextval('public.issue_watch_id_seq'::regclass);


--
-- Name: label id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.label ALTER COLUMN id SET DEFAULT nextval('public.label_id_seq'::regclass);


--
-- Name: lfs_lock id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lfs_lock ALTER COLUMN id SET DEFAULT nextval('public.lfs_lock_id_seq'::regclass);


--
-- Name: lfs_meta_object id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lfs_meta_object ALTER COLUMN id SET DEFAULT nextval('public.lfs_meta_object_id_seq'::regclass);


--
-- Name: login_source id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.login_source ALTER COLUMN id SET DEFAULT nextval('public.login_source_id_seq'::regclass);


--
-- Name: milestone id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.milestone ALTER COLUMN id SET DEFAULT nextval('public.milestone_id_seq'::regclass);


--
-- Name: mirror id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mirror ALTER COLUMN id SET DEFAULT nextval('public.mirror_id_seq'::regclass);


--
-- Name: notice id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notice ALTER COLUMN id SET DEFAULT nextval('public.notice_id_seq'::regclass);


--
-- Name: notification id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification ALTER COLUMN id SET DEFAULT nextval('public.notification_id_seq'::regclass);


--
-- Name: org_user id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_user ALTER COLUMN id SET DEFAULT nextval('public.org_user_id_seq'::regclass);


--
-- Name: protected_branch id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.protected_branch ALTER COLUMN id SET DEFAULT nextval('public.protected_branch_id_seq'::regclass);


--
-- Name: public_key id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.public_key ALTER COLUMN id SET DEFAULT nextval('public.public_key_id_seq'::regclass);


--
-- Name: pull_request id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pull_request ALTER COLUMN id SET DEFAULT nextval('public.pull_request_id_seq'::regclass);


--
-- Name: reaction id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reaction ALTER COLUMN id SET DEFAULT nextval('public.reaction_id_seq'::regclass);


--
-- Name: release id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.release ALTER COLUMN id SET DEFAULT nextval('public.release_id_seq'::regclass);


--
-- Name: repo_indexer_status id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.repo_indexer_status ALTER COLUMN id SET DEFAULT nextval('public.repo_indexer_status_id_seq'::regclass);


--
-- Name: repo_redirect id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.repo_redirect ALTER COLUMN id SET DEFAULT nextval('public.repo_redirect_id_seq'::regclass);


--
-- Name: repo_unit id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.repo_unit ALTER COLUMN id SET DEFAULT nextval('public.repo_unit_id_seq'::regclass);


--
-- Name: repository id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.repository ALTER COLUMN id SET DEFAULT nextval('public.repository_id_seq'::regclass);


--
-- Name: star id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.star ALTER COLUMN id SET DEFAULT nextval('public.star_id_seq'::regclass);


--
-- Name: stopwatch id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stopwatch ALTER COLUMN id SET DEFAULT nextval('public.stopwatch_id_seq'::regclass);


--
-- Name: team id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team ALTER COLUMN id SET DEFAULT nextval('public.team_id_seq'::regclass);


--
-- Name: team_repo id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_repo ALTER COLUMN id SET DEFAULT nextval('public.team_repo_id_seq'::regclass);


--
-- Name: team_unit id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_unit ALTER COLUMN id SET DEFAULT nextval('public.team_unit_id_seq'::regclass);


--
-- Name: team_user id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_user ALTER COLUMN id SET DEFAULT nextval('public.team_user_id_seq'::regclass);


--
-- Name: topic id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.topic ALTER COLUMN id SET DEFAULT nextval('public.topic_id_seq'::regclass);


--
-- Name: tracked_time id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tracked_time ALTER COLUMN id SET DEFAULT nextval('public.tracked_time_id_seq'::regclass);


--
-- Name: two_factor id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.two_factor ALTER COLUMN id SET DEFAULT nextval('public.two_factor_id_seq'::regclass);


--
-- Name: u2f_registration id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.u2f_registration ALTER COLUMN id SET DEFAULT nextval('public.u2f_registration_id_seq'::regclass);


--
-- Name: upload id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.upload ALTER COLUMN id SET DEFAULT nextval('public.upload_id_seq'::regclass);


--
-- Name: user id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user" ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq'::regclass);


--
-- Name: user_open_id id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_open_id ALTER COLUMN id SET DEFAULT nextval('public.user_open_id_id_seq'::regclass);


--
-- Name: version id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.version ALTER COLUMN id SET DEFAULT nextval('public.version_id_seq'::regclass);


--
-- Name: watch id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.watch ALTER COLUMN id SET DEFAULT nextval('public.watch_id_seq'::regclass);


--
-- Name: webhook id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.webhook ALTER COLUMN id SET DEFAULT nextval('public.webhook_id_seq'::regclass);


--
-- Data for Name: access; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.access (id, user_id, repo_id, mode) VALUES (1, 2, 3, 2);
INSERT INTO public.access (id, user_id, repo_id, mode) VALUES (2, 4, 4, 2);
INSERT INTO public.access (id, user_id, repo_id, mode) VALUES (3, 4, 3, 2);
INSERT INTO public.access (id, user_id, repo_id, mode) VALUES (4, 15, 22, 2);
INSERT INTO public.access (id, user_id, repo_id, mode) VALUES (5, 15, 21, 2);
INSERT INTO public.access (id, user_id, repo_id, mode) VALUES (6, 15, 23, 4);
INSERT INTO public.access (id, user_id, repo_id, mode) VALUES (7, 15, 24, 4);
INSERT INTO public.access (id, user_id, repo_id, mode) VALUES (8, 18, 23, 4);
INSERT INTO public.access (id, user_id, repo_id, mode) VALUES (9, 18, 24, 4);
INSERT INTO public.access (id, user_id, repo_id, mode) VALUES (10, 18, 22, 2);
INSERT INTO public.access (id, user_id, repo_id, mode) VALUES (11, 18, 21, 2);
INSERT INTO public.access (id, user_id, repo_id, mode) VALUES (12, 20, 27, 4);
INSERT INTO public.access (id, user_id, repo_id, mode) VALUES (13, 20, 28, 4);


--
-- Data for Name: access_token; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.access_token (id, uid, name, sha1, created_unix, updated_unix) VALUES (1, 1, 'Token A', 'hash1', 946687980, 946687980);
INSERT INTO public.access_token (id, uid, name, sha1, created_unix, updated_unix) VALUES (2, 1, 'Token B', 'hash2', 946687980, 946687980);
INSERT INTO public.access_token (id, uid, name, sha1, created_unix, updated_unix) VALUES (3, 2, 'Token A', 'hash3', 946687980, 946687980);


--
-- Data for Name: action; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.action (id, user_id, op_type, act_user_id, repo_id, comment_id, is_deleted, ref_name, is_private, content, created_unix) VALUES (1, 2, 12, 2, 2, NULL, false, NULL, true, NULL, NULL);
INSERT INTO public.action (id, user_id, op_type, act_user_id, repo_id, comment_id, is_deleted, ref_name, is_private, content, created_unix) VALUES (2, 3, 2, 2, 3, NULL, false, NULL, true, 'oldRepoName', NULL);
INSERT INTO public.action (id, user_id, op_type, act_user_id, repo_id, comment_id, is_deleted, ref_name, is_private, content, created_unix) VALUES (3, 11, 1, 11, 9, NULL, false, NULL, false, NULL, NULL);


--
-- Data for Name: attachment; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.attachment (id, uuid, issue_id, release_id, comment_id, name, download_count, size, created_unix) VALUES (1, 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 1, NULL, 0, 'attach1', 0, 0, 946684800);
INSERT INTO public.attachment (id, uuid, issue_id, release_id, comment_id, name, download_count, size, created_unix) VALUES (2, 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', 1, NULL, 0, 'attach2', 1, 0, 946684800);
INSERT INTO public.attachment (id, uuid, issue_id, release_id, comment_id, name, download_count, size, created_unix) VALUES (3, 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a13', 2, NULL, 1, 'attach1', 0, 0, 946684800);
INSERT INTO public.attachment (id, uuid, issue_id, release_id, comment_id, name, download_count, size, created_unix) VALUES (4, 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a14', 3, NULL, 1, 'attach2', 1, 0, 946684800);
INSERT INTO public.attachment (id, uuid, issue_id, release_id, comment_id, name, download_count, size, created_unix) VALUES (5, 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a15', 4, NULL, 0, 'attach1', 0, 0, 946684800);
INSERT INTO public.attachment (id, uuid, issue_id, release_id, comment_id, name, download_count, size, created_unix) VALUES (6, 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a16', 5, NULL, 2, 'attach1', 0, 0, 946684800);
INSERT INTO public.attachment (id, uuid, issue_id, release_id, comment_id, name, download_count, size, created_unix) VALUES (7, 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a17', 5, NULL, 2, 'attach1', 0, 0, 946684800);
INSERT INTO public.attachment (id, uuid, issue_id, release_id, comment_id, name, download_count, size, created_unix) VALUES (8, 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a18', 6, NULL, 0, 'attach1', 0, 0, 946684800);


--
-- Data for Name: collaboration; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.collaboration (id, repo_id, user_id, mode) VALUES (1, 3, 2, 2);
INSERT INTO public.collaboration (id, repo_id, user_id, mode) VALUES (2, 4, 4, 2);


--
-- Data for Name: comment; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.comment (id, type, poster_id, issue_id, label_id, old_milestone_id, milestone_id, assignee_id, removed_assignee, old_title, new_title, commit_id, line, content, created_unix, updated_unix, commit_sha) VALUES (1, 7, 2, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 946684810, NULL, NULL);
INSERT INTO public.comment (id, type, poster_id, issue_id, label_id, old_milestone_id, milestone_id, assignee_id, removed_assignee, old_title, new_title, commit_id, line, content, created_unix, updated_unix, commit_sha) VALUES (2, 0, 3, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'good work!', 946684811, NULL, NULL);
INSERT INTO public.comment (id, type, poster_id, issue_id, label_id, old_milestone_id, milestone_id, assignee_id, removed_assignee, old_title, new_title, commit_id, line, content, created_unix, updated_unix, commit_sha) VALUES (3, 0, 5, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'meh...', 946684812, NULL, NULL);


--
-- Data for Name: commit_status; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.commit_status (id, index, repo_id, state, sha, target_url, description, context, creator_id, created_unix, updated_unix) VALUES (1, 1, 1, 'pending', '1234123412341234123412341234123412341234', 'https://example.com/builds/', 'My awesome CI-service', 'ci/awesomeness', 2, NULL, NULL);
INSERT INTO public.commit_status (id, index, repo_id, state, sha, target_url, description, context, creator_id, created_unix, updated_unix) VALUES (2, 2, 1, 'warning', '1234123412341234123412341234123412341234', 'https://example.com/converage/', 'My awesome Coverage service', 'cov/awesomeness', 2, NULL, NULL);
INSERT INTO public.commit_status (id, index, repo_id, state, sha, target_url, description, context, creator_id, created_unix, updated_unix) VALUES (3, 3, 1, 'success', '1234123412341234123412341234123412341234', 'https://example.com/converage/', 'My awesome Coverage service', 'cov/awesomeness', 2, NULL, NULL);
INSERT INTO public.commit_status (id, index, repo_id, state, sha, target_url, description, context, creator_id, created_unix, updated_unix) VALUES (4, 4, 1, 'failure', '1234123412341234123412341234123412341234', 'https://example.com/builds/', 'My awesome CI-service', 'ci/awesomeness', 2, NULL, NULL);
INSERT INTO public.commit_status (id, index, repo_id, state, sha, target_url, description, context, creator_id, created_unix, updated_unix) VALUES (5, 5, 1, 'error', '1234123412341234123412341234123412341234', 'https://example.com/builds/', 'My awesome deploy service', 'deploy/awesomeness', 2, NULL, NULL);


--
-- Data for Name: deleted_branch; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.deleted_branch (id, repo_id, name, commit, deleted_by_id, deleted_unix) VALUES (1, 1, 'foo', '1213212312313213200000000', 1, 978307200);
INSERT INTO public.deleted_branch (id, repo_id, name, commit, deleted_by_id, deleted_unix) VALUES (2, 1, 'bar', '5655464564554545000000000', 99, 978307200);


--
-- Data for Name: deploy_key; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: email_address; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.email_address (id, uid, email, is_activated) VALUES (1, 1, 'user11@example.com', false);
INSERT INTO public.email_address (id, uid, email, is_activated) VALUES (2, 1, 'user12@example.com', false);
INSERT INTO public.email_address (id, uid, email, is_activated) VALUES (3, 2, 'user2@example.com', true);
INSERT INTO public.email_address (id, uid, email, is_activated) VALUES (4, 2, 'user21@example.com', false);
INSERT INTO public.email_address (id, uid, email, is_activated) VALUES (5, 9999999, 'user9999999@example.com', true);
INSERT INTO public.email_address (id, uid, email, is_activated) VALUES (6, 10, 'user101@example.com', true);


--
-- Data for Name: external_login_user; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: follow; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.follow (id, user_id, follow_id) VALUES (1, 4, 2);
INSERT INTO public.follow (id, user_id, follow_id) VALUES (2, 8, 2);
INSERT INTO public.follow (id, user_id, follow_id) VALUES (3, 2, 8);


--
-- Data for Name: gpg_key; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: hook_task; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.hook_task (id, repo_id, hook_id, uuid, type, url, payload_content, content_type, event_type, is_ssl, is_delivered, delivered, is_succeed, request_content, response_content) VALUES (1, 1, 1, 'uuid1', NULL, NULL, NULL, NULL, NULL, NULL, true, NULL, NULL, NULL, NULL);


--
-- Data for Name: issue; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.issue (id, repo_id, index, poster_id, name, content, milestone_id, priority, is_closed, is_pull, num_comments, ref, deadline_unix, created_unix, updated_unix, closed_unix) VALUES (1, 1, 1, 1, 'issue1', 'content for the first issue', NULL, NULL, false, false, 2, NULL, NULL, 946684800, 978307200, NULL);
INSERT INTO public.issue (id, repo_id, index, poster_id, name, content, milestone_id, priority, is_closed, is_pull, num_comments, ref, deadline_unix, created_unix, updated_unix, closed_unix) VALUES (2, 1, 2, 1, 'issue2', 'content for the second issue', 1, NULL, false, true, NULL, NULL, NULL, 946684810, 978307190, NULL);
INSERT INTO public.issue (id, repo_id, index, poster_id, name, content, milestone_id, priority, is_closed, is_pull, num_comments, ref, deadline_unix, created_unix, updated_unix, closed_unix) VALUES (3, 1, 3, 1, 'issue3', 'content for the third issue', NULL, NULL, false, true, NULL, NULL, NULL, 946684820, 978307180, NULL);
INSERT INTO public.issue (id, repo_id, index, poster_id, name, content, milestone_id, priority, is_closed, is_pull, num_comments, ref, deadline_unix, created_unix, updated_unix, closed_unix) VALUES (4, 2, 1, 2, 'issue4', 'content for the fourth issue', NULL, NULL, true, false, NULL, NULL, NULL, 946684830, 978307200, NULL);
INSERT INTO public.issue (id, repo_id, index, poster_id, name, content, milestone_id, priority, is_closed, is_pull, num_comments, ref, deadline_unix, created_unix, updated_unix, closed_unix) VALUES (5, 1, 4, 2, 'issue5', 'content for the fifth issue', NULL, NULL, true, false, NULL, NULL, NULL, 946684840, 978307200, NULL);
INSERT INTO public.issue (id, repo_id, index, poster_id, name, content, milestone_id, priority, is_closed, is_pull, num_comments, ref, deadline_unix, created_unix, updated_unix, closed_unix) VALUES (6, 3, 1, 1, 'issue6', 'content6', NULL, NULL, false, false, 0, NULL, NULL, 946684850, 978307200, NULL);


--
-- Data for Name: issue_assignees; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.issue_assignees (id, assignee_id, issue_id) VALUES (1, 1, 1);
INSERT INTO public.issue_assignees (id, assignee_id, issue_id) VALUES (2, 1, 6);


--
-- Data for Name: issue_label; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.issue_label (id, issue_id, label_id) VALUES (1, 1, 1);
INSERT INTO public.issue_label (id, issue_id, label_id) VALUES (2, 5, 2);
INSERT INTO public.issue_label (id, issue_id, label_id) VALUES (3, 2, 1);


--
-- Data for Name: issue_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.issue_user (id, uid, issue_id, is_read, is_mentioned) VALUES (1, 1, 1, true, false);
INSERT INTO public.issue_user (id, uid, issue_id, is_read, is_mentioned) VALUES (2, 2, 1, true, false);
INSERT INTO public.issue_user (id, uid, issue_id, is_read, is_mentioned) VALUES (3, 4, 1, false, false);


--
-- Data for Name: issue_watch; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.issue_watch (id, user_id, issue_id, is_watching, created_unix, updated_unix) VALUES (1, 9, 1, true, 946684800, 946684800);
INSERT INTO public.issue_watch (id, user_id, issue_id, is_watching, created_unix, updated_unix) VALUES (2, 2, 2, false, 946684800, 946684800);


--
-- Data for Name: label; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.label (id, repo_id, name, description, color, num_issues, num_closed_issues) VALUES (1, 1, 'label1', NULL, '#abcdef', 2, 0);
INSERT INTO public.label (id, repo_id, name, description, color, num_issues, num_closed_issues) VALUES (2, 1, 'label2', NULL, '#000000', 1, 1);


--
-- Data for Name: lfs_lock; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: lfs_meta_object; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: login_source; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: milestone; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.milestone (id, repo_id, name, content, is_closed, num_issues, num_closed_issues, completeness, deadline_unix, closed_date_unix) VALUES (1, 1, 'milestone1', 'content1', false, 1, NULL, NULL, NULL, NULL);
INSERT INTO public.milestone (id, repo_id, name, content, is_closed, num_issues, num_closed_issues, completeness, deadline_unix, closed_date_unix) VALUES (2, 1, 'milestone2', 'content2', false, 0, NULL, NULL, NULL, NULL);


--
-- Data for Name: mirror; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: notice; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.notice (id, type, description, created_unix) VALUES (1, 1, 'description1', NULL);
INSERT INTO public.notice (id, type, description, created_unix) VALUES (2, 1, 'description2', NULL);
INSERT INTO public.notice (id, type, description, created_unix) VALUES (3, 1, 'description3', NULL);


--
-- Data for Name: notification; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.notification (id, user_id, repo_id, status, source, issue_id, commit_id, updated_by, created_unix, updated_unix) VALUES (1, 1, 1, 1, 1, 1, NULL, 2, 946684800, 946684800);
INSERT INTO public.notification (id, user_id, repo_id, status, source, issue_id, commit_id, updated_by, created_unix, updated_unix) VALUES (2, 2, 1, 2, 1, 2, NULL, 1, 946684800, 946684800);
INSERT INTO public.notification (id, user_id, repo_id, status, source, issue_id, commit_id, updated_by, created_unix, updated_unix) VALUES (3, 2, 1, 3, 1, 2, NULL, 1, 946684800, 946684800);
INSERT INTO public.notification (id, user_id, repo_id, status, source, issue_id, commit_id, updated_by, created_unix, updated_unix) VALUES (4, 2, 1, 1, 1, 2, NULL, 1, 946684800, 946684800);


--
-- Data for Name: oauth2_session; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: org_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.org_user (id, uid, org_id, is_public) VALUES (1, 2, 3, true);
INSERT INTO public.org_user (id, uid, org_id, is_public) VALUES (2, 4, 3, false);
INSERT INTO public.org_user (id, uid, org_id, is_public) VALUES (3, 5, 6, true);
INSERT INTO public.org_user (id, uid, org_id, is_public) VALUES (4, 5, 7, false);
INSERT INTO public.org_user (id, uid, org_id, is_public) VALUES (5, 15, 17, true);
INSERT INTO public.org_user (id, uid, org_id, is_public) VALUES (6, 18, 17, false);
INSERT INTO public.org_user (id, uid, org_id, is_public) VALUES (7, 20, 19, true);


--
-- Data for Name: protected_branch; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: public_key; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: pull_request; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.pull_request (id, type, status, issue_id, index, head_repo_id, base_repo_id, head_user_name, head_branch, base_branch, merge_base, has_merged, merged_commit_id, merger_id, merged_unix) VALUES (1, 0, 2, 2, 2, 1, 1, 'user1', 'branch1', 'master', '1234567890abcdef', true, NULL, 2, NULL);
INSERT INTO public.pull_request (id, type, status, issue_id, index, head_repo_id, base_repo_id, head_user_name, head_branch, base_branch, merge_base, has_merged, merged_commit_id, merger_id, merged_unix) VALUES (2, 0, 2, 3, 3, 1, 1, 'user1', 'branch2', 'master', 'fedcba9876543210', false, NULL, NULL, NULL);


--
-- Data for Name: reaction; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: release; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: repo_indexer_status; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: repo_redirect; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.repo_redirect (id, owner_id, lower_name, redirect_repo_id) VALUES (1, 2, 'oldrepo1', 1);


--
-- Data for Name: repo_topic; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.repo_topic (repo_id, topic_id) VALUES (1, 1);
INSERT INTO public.repo_topic (repo_id, topic_id) VALUES (1, 2);
INSERT INTO public.repo_topic (repo_id, topic_id) VALUES (1, 3);


--
-- Data for Name: repo_unit; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.repo_unit (id, repo_id, type, config, created_unix) VALUES (1, 1, 4, '{}', 946684810);
INSERT INTO public.repo_unit (id, repo_id, type, config, created_unix) VALUES (2, 1, 5, '{}', 946684810);
INSERT INTO public.repo_unit (id, repo_id, type, config, created_unix) VALUES (3, 1, 1, '{}', 946684810);
INSERT INTO public.repo_unit (id, repo_id, type, config, created_unix) VALUES (4, 1, 2, '{"EnableTimetracker":true,"AllowOnlyContributorsToTrackTime":true}', 946684810);
INSERT INTO public.repo_unit (id, repo_id, type, config, created_unix) VALUES (5, 1, 3, '{"IgnoreWhitespaceConflicts":false,"AllowMerge":true,"AllowRebase":true,"AllowSquash":true}', 946684810);
INSERT INTO public.repo_unit (id, repo_id, type, config, created_unix) VALUES (6, 3, 1, '{}', 946684810);
INSERT INTO public.repo_unit (id, repo_id, type, config, created_unix) VALUES (7, 3, 2, '{"EnableTimetracker":false,"AllowOnlyContributorsToTrackTime":false}', 946684810);
INSERT INTO public.repo_unit (id, repo_id, type, config, created_unix) VALUES (8, 3, 3, '{"IgnoreWhitespaceConflicts":true,"AllowMerge":true,"AllowRebase":false,"AllowSquash":false}', 946684810);
INSERT INTO public.repo_unit (id, repo_id, type, config, created_unix) VALUES (9, 3, 4, '{}', 946684810);
INSERT INTO public.repo_unit (id, repo_id, type, config, created_unix) VALUES (10, 3, 5, '{}', 946684810);
INSERT INTO public.repo_unit (id, repo_id, type, config, created_unix) VALUES (11, 31, 1, '{}', 1524304355);
INSERT INTO public.repo_unit (id, repo_id, type, config, created_unix) VALUES (12, 33, 1, '{}', 1535593231);
INSERT INTO public.repo_unit (id, repo_id, type, config, created_unix) VALUES (13, 33, 2, '{"EnableTimetracker":true,"AllowOnlyContributorsToTrackTime":true}', 1535593231);
INSERT INTO public.repo_unit (id, repo_id, type, config, created_unix) VALUES (14, 33, 3, '{"IgnoreWhitespaceConflicts":false,"AllowMerge":true,"AllowRebase":true,"AllowSquash":true}', 1535593231);
INSERT INTO public.repo_unit (id, repo_id, type, config, created_unix) VALUES (15, 33, 4, '{}', 1535593231);
INSERT INTO public.repo_unit (id, repo_id, type, config, created_unix) VALUES (16, 33, 5, '{}', 1535593231);


--
-- Data for Name: repository; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (1, 2, 'repo1', 'repo1', NULL, NULL, NULL, 3, NULL, NULL, 2, 1, 2, 0, 2, 0, false, NULL, NULL, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO public.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (2, 2, 'repo2', 'repo2', NULL, NULL, NULL, NULL, 1, NULL, 1, 1, 0, 0, 0, 0, true, NULL, NULL, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO public.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (3, 3, 'repo3', 'repo3', NULL, NULL, NULL, 0, NULL, NULL, 1, 0, 0, 0, 0, 0, true, NULL, NULL, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO public.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (4, 5, 'repo4', 'repo4', NULL, NULL, NULL, NULL, 1, NULL, 0, 0, 0, 0, 0, 0, false, NULL, NULL, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO public.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (5, 3, 'repo5', 'repo5', NULL, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, true, NULL, true, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO public.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (6, 10, 'repo6', 'repo6', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, true, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO public.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (7, 10, 'repo7', 'repo7', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, true, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO public.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (8, 10, 'repo8', 'repo8', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, false, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO public.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (9, 11, 'repo9', 'repo9', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, false, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO public.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (10, 12, 'repo10', 'repo10', NULL, NULL, NULL, NULL, NULL, 1, 0, 0, 0, 0, 0, 0, false, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO public.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (11, 13, 'repo11', 'repo11', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, false, NULL, false, false, 10, 0, true, NULL, NULL, NULL);
INSERT INTO public.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (12, 14, 'test_repo_12', 'test_repo_12', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, false, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO public.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (13, 14, 'test_repo_13', 'test_repo_13', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, true, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO public.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (14, 14, 'test_repo_14', 'test_repo_14', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, false, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO public.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (15, 2, 'repo15', 'repo15', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, true, NULL, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO public.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (16, 2, 'repo16', 'repo16', NULL, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, true, NULL, NULL, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO public.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (17, 15, 'big_test_public_1', 'big_test_public_1', NULL, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, false, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO public.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (18, 15, 'big_test_public_2', 'big_test_public_2', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, false, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO public.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (19, 15, 'big_test_private_1', 'big_test_private_1', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, true, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO public.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (20, 15, 'big_test_private_2', 'big_test_private_2', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, true, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO public.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (21, 16, 'big_test_public_3', 'big_test_public_3', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, false, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO public.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (22, 16, 'big_test_private_3', 'big_test_private_3', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, true, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO public.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (23, 17, 'big_test_public_4', 'big_test_public_4', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, false, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO public.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (24, 17, 'big_test_private_4', 'big_test_private_4', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, true, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO public.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (25, 20, 'big_test_public_mirror_5', 'big_test_public_mirror_5', NULL, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, false, NULL, true, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO public.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (26, 20, 'big_test_private_mirror_5', 'big_test_private_mirror_5', NULL, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, true, NULL, true, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO public.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (27, 19, 'big_test_public_mirror_6', 'big_test_public_mirror_6', NULL, NULL, NULL, 0, NULL, 1, 0, 0, 0, 0, 0, 0, false, NULL, true, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO public.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (28, 19, 'big_test_private_mirror_6', 'big_test_private_mirror_6', NULL, NULL, NULL, 0, NULL, 1, 0, 0, 0, 0, 0, 0, true, NULL, true, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO public.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (29, 20, 'big_test_public_fork_7', 'big_test_public_fork_7', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, false, NULL, false, true, 27, 0, true, NULL, NULL, NULL);
INSERT INTO public.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (30, 20, 'big_test_private_fork_7', 'big_test_private_fork_7', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, true, NULL, false, true, 28, 0, true, NULL, NULL, NULL);
INSERT INTO public.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (31, 2, 'repo20', 'repo20', NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, 0, 0, NULL, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO public.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (32, 3, 'repo21', 'repo21', NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, 0, 0, false, NULL, false, false, NULL, 0, true, NULL, NULL, NULL);
INSERT INTO public.repository (id, owner_id, lower_name, name, description, website, default_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, is_private, is_bare, is_mirror, is_fork, fork_id, size, is_fsck_enabled, topics, created_unix, updated_unix) VALUES (33, 2, 'utf8', 'utf8', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, false, NULL, NULL, false, NULL, 0, true, NULL, NULL, NULL);


--
-- Data for Name: star; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.star (id, uid, repo_id) VALUES (1, 2, 2);
INSERT INTO public.star (id, uid, repo_id) VALUES (2, 2, 4);


--
-- Data for Name: stopwatch; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.stopwatch (id, issue_id, user_id, created_unix) VALUES (1, 1, 1, 1500988502);
INSERT INTO public.stopwatch (id, issue_id, user_id, created_unix) VALUES (2, 2, 2, 1500988502);


--
-- Data for Name: team; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.team (id, org_id, lower_name, name, description, authorize, num_repos, num_members) VALUES (1, 3, 'owners', 'Owners', NULL, 4, 3, 1);
INSERT INTO public.team (id, org_id, lower_name, name, description, authorize, num_repos, num_members) VALUES (2, 3, 'team1', 'team1', NULL, 2, 1, 2);
INSERT INTO public.team (id, org_id, lower_name, name, description, authorize, num_repos, num_members) VALUES (3, 6, 'owners', 'Owners', NULL, 4, 0, 1);
INSERT INTO public.team (id, org_id, lower_name, name, description, authorize, num_repos, num_members) VALUES (4, 7, 'owners', 'Owners', NULL, 4, 0, 1);
INSERT INTO public.team (id, org_id, lower_name, name, description, authorize, num_repos, num_members) VALUES (5, 17, 'owners', 'Owners', NULL, 4, 2, 2);
INSERT INTO public.team (id, org_id, lower_name, name, description, authorize, num_repos, num_members) VALUES (6, 19, 'owners', 'Owners', NULL, 4, 2, 1);


--
-- Data for Name: team_repo; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.team_repo (id, org_id, team_id, repo_id) VALUES (1, 3, 1, 3);
INSERT INTO public.team_repo (id, org_id, team_id, repo_id) VALUES (2, 3, 2, 3);
INSERT INTO public.team_repo (id, org_id, team_id, repo_id) VALUES (3, 3, 1, 5);
INSERT INTO public.team_repo (id, org_id, team_id, repo_id) VALUES (4, 17, 5, 23);
INSERT INTO public.team_repo (id, org_id, team_id, repo_id) VALUES (5, 17, 5, 24);
INSERT INTO public.team_repo (id, org_id, team_id, repo_id) VALUES (6, 19, 6, 27);
INSERT INTO public.team_repo (id, org_id, team_id, repo_id) VALUES (7, 19, 6, 28);
INSERT INTO public.team_repo (id, org_id, team_id, repo_id) VALUES (8, 3, 1, 32);


--
-- Data for Name: team_unit; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (1, NULL, 1, 1);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (2, NULL, 1, 2);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (3, NULL, 1, 3);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (4, NULL, 1, 4);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (5, NULL, 1, 5);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (6, NULL, 1, 6);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (7, NULL, 1, 7);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (8, NULL, 2, 1);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (9, NULL, 2, 2);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (10, NULL, 2, 3);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (11, NULL, 2, 4);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (12, NULL, 2, 5);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (13, NULL, 2, 6);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (14, NULL, 2, 7);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (15, NULL, 3, 1);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (16, NULL, 3, 2);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (17, NULL, 3, 3);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (18, NULL, 3, 4);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (19, NULL, 3, 5);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (20, NULL, 3, 6);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (21, NULL, 3, 7);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (22, NULL, 4, 1);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (23, NULL, 4, 2);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (24, NULL, 4, 3);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (25, NULL, 4, 4);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (26, NULL, 4, 5);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (27, NULL, 4, 6);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (28, NULL, 4, 7);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (29, NULL, 5, 1);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (30, NULL, 5, 2);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (31, NULL, 5, 3);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (32, NULL, 5, 4);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (33, NULL, 5, 5);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (34, NULL, 5, 6);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (35, NULL, 5, 7);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (36, NULL, 6, 1);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (37, NULL, 6, 2);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (38, NULL, 6, 3);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (39, NULL, 6, 4);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (40, NULL, 6, 5);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (41, NULL, 6, 6);
INSERT INTO public.team_unit (id, org_id, team_id, type) VALUES (42, NULL, 6, 7);


--
-- Data for Name: team_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.team_user (id, org_id, team_id, uid) VALUES (1, 3, 1, 2);
INSERT INTO public.team_user (id, org_id, team_id, uid) VALUES (2, 3, 2, 2);
INSERT INTO public.team_user (id, org_id, team_id, uid) VALUES (3, 3, 2, 4);
INSERT INTO public.team_user (id, org_id, team_id, uid) VALUES (4, 6, 3, 5);
INSERT INTO public.team_user (id, org_id, team_id, uid) VALUES (5, 7, 4, 5);
INSERT INTO public.team_user (id, org_id, team_id, uid) VALUES (6, 17, 5, 15);
INSERT INTO public.team_user (id, org_id, team_id, uid) VALUES (7, 17, 5, 18);
INSERT INTO public.team_user (id, org_id, team_id, uid) VALUES (8, 19, 6, 20);


--
-- Data for Name: topic; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.topic (id, name, repo_count, created_unix, updated_unix) VALUES (1, 'golang', 1, NULL, NULL);
INSERT INTO public.topic (id, name, repo_count, created_unix, updated_unix) VALUES (2, 'database', 1, NULL, NULL);
INSERT INTO public.topic (id, name, repo_count, created_unix, updated_unix) VALUES (3, 'SQL', 1, NULL, NULL);


--
-- Data for Name: tracked_time; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.tracked_time (id, issue_id, user_id, created_unix, "time") VALUES (1, 1, 1, 946684800, 400);
INSERT INTO public.tracked_time (id, issue_id, user_id, created_unix, "time") VALUES (2, 2, 2, 946684801, 3661);
INSERT INTO public.tracked_time (id, issue_id, user_id, created_unix, "time") VALUES (3, 2, 2, 946684802, 1);
INSERT INTO public.tracked_time (id, issue_id, user_id, created_unix, "time") VALUES (4, 4, -1, 946684802, 1);
INSERT INTO public.tracked_time (id, issue_id, user_id, created_unix, "time") VALUES (5, 5, 2, 946684802, 1);


--
-- Data for Name: two_factor; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: u2f_registration; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.u2f_registration (id, name, user_id, raw, counter, created_unix, updated_unix) VALUES (1, 'U2F Key', 1, NULL, 0, 946684800, 946684800);


--
-- Data for Name: upload; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (1, 'user1', 'user1', 'User One', 'user1@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 0, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, true, true, NULL, NULL, true, false, 'avatar1', 'user1@example.com', NULL, NULL, 0, NULL, 0, NULL, NULL, NULL, '');
INSERT INTO public."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (2, 'user2', 'user2', 'User Two', 'user2@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 0, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, true, false, NULL, NULL, true, false, 'avatar2', 'user2@example.com', NULL, 2, 1, 2, 6, NULL, NULL, NULL, '');
INSERT INTO public."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (3, 'user3', 'user3', 'User Three', 'user3@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 1, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, NULL, false, NULL, NULL, true, false, 'avatar3', 'user3@example.com', NULL, NULL, 0, NULL, 3, NULL, 2, 2, '');
INSERT INTO public."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (4, 'user4', 'user4', 'User Four', 'user4@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 0, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, true, false, NULL, NULL, true, false, 'avatar4', 'user4@example.com', NULL, NULL, 1, NULL, 0, NULL, NULL, NULL, '');
INSERT INTO public."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (5, 'user5', 'user5', 'User Five', 'user5@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 0, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, true, false, NULL, NULL, false, false, 'avatar5', 'user5@example.com', NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, '');
INSERT INTO public."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (6, 'user6', 'user6', 'User Six', 'user6@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 1, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, NULL, false, NULL, NULL, true, false, 'avatar6', 'user6@example.com', NULL, NULL, 0, NULL, 0, NULL, 1, 1, '');
INSERT INTO public."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (7, 'user7', 'user7', 'User Seven', 'user7@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 1, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, NULL, false, NULL, NULL, true, false, 'avatar7', 'user7@example.com', NULL, NULL, 0, NULL, 0, NULL, 1, 1, '');
INSERT INTO public."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (8, 'user8', 'user8', 'User Eight', 'user8@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 0, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, true, false, NULL, NULL, true, false, 'avatar8', 'user8@example.com', NULL, 1, 1, NULL, 0, NULL, NULL, NULL, '');
INSERT INTO public."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (9, 'user9', 'user9', 'User Nine', 'user9@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 0, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, false, false, NULL, NULL, true, false, 'avatar9', 'user9@example.com', NULL, NULL, 0, NULL, 0, NULL, NULL, NULL, '');
INSERT INTO public."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (10, 'user10', 'user10', 'User Ten', 'user10@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 0, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, true, false, NULL, NULL, true, false, 'avatar10', 'user10@example.com', NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, '');
INSERT INTO public."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (11, 'user11', 'user11', 'User Eleven', 'user11@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 0, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, true, false, NULL, NULL, true, false, 'avatar11', 'user11@example.com', NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, '');
INSERT INTO public."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (12, 'user12', 'user12', 'User 12', 'user12@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 0, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, true, false, NULL, NULL, true, false, 'avatar12', 'user12@example.com', NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, '');
INSERT INTO public."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (13, 'user13', 'user13', 'User 13', 'user13@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 0, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, true, false, NULL, NULL, true, false, 'avatar13', 'user13@example.com', NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, '');
INSERT INTO public."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (14, 'user14', 'user14', 'User 14', 'user14@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 0, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, true, false, NULL, NULL, true, false, 'avatar14', 'user13@example.com', NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, '');
INSERT INTO public."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (15, 'user15', 'user15', 'User 15', 'user15@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 0, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, true, false, NULL, NULL, true, false, 'avatar15', 'user15@example.com', NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, '');
INSERT INTO public."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (16, 'user16', 'user16', 'User 16', 'user16@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 0, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, true, false, NULL, NULL, true, false, 'avatar16', 'user16@example.com', NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, '');
INSERT INTO public."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (17, 'user17', 'user17', 'User 17', 'user17@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 1, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, true, false, NULL, NULL, true, false, 'avatar17', 'user17@example.com', NULL, NULL, 0, NULL, 2, NULL, 1, 2, '');
INSERT INTO public."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (18, 'user18', 'user18', 'User 18', 'user18@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 0, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, true, false, NULL, NULL, true, false, 'avatar18', 'user18@example.com', NULL, NULL, 0, NULL, 0, NULL, NULL, NULL, '');
INSERT INTO public."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (19, 'user19', 'user19', 'User 19', 'user19@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 1, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, true, false, NULL, NULL, true, false, 'avatar19', 'user19@example.com', NULL, NULL, 0, NULL, 2, NULL, 1, 1, '');
INSERT INTO public."user" (id, lower_name, name, full_name, email, keep_email_private, passwd, login_type, login_source, login_name, type, location, website, rands, salt, language, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, description, num_teams, num_members, diff_view_style) VALUES (20, 'user20', 'user20', 'User 20', 'user20@example.com', NULL, '7d93daa0d1e6f2305cc8fa496847d61dc7320bb16262f9c55dd753480207234cdd96a93194e408341971742f4701772a025a', NULL, 0, NULL, 0, NULL, NULL, NULL, 'ZogKvWdyEx', NULL, NULL, NULL, NULL, NULL, -1, true, false, NULL, NULL, true, false, 'avatar20', 'user20@example.com', NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, '');


--
-- Data for Name: user_open_id; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.user_open_id (id, uid, uri, show) VALUES (1, 1, 'https://user1.domain1.tld/', false);
INSERT INTO public.user_open_id (id, uid, uri, show) VALUES (2, 1, 'http://user1.domain2.tld/', true);
INSERT INTO public.user_open_id (id, uid, uri, show) VALUES (3, 2, 'https://domain1.tld/user2/', true);


--
-- Data for Name: version; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.version (id, version) VALUES (1, 70);


--
-- Data for Name: watch; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.watch (id, user_id, repo_id) VALUES (1, 1, 1);
INSERT INTO public.watch (id, user_id, repo_id) VALUES (2, 4, 1);
INSERT INTO public.watch (id, user_id, repo_id) VALUES (3, 9, 1);


--
-- Data for Name: webhook; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.webhook (id, repo_id, org_id, url, content_type, secret, events, is_ssl, is_active, hook_task_type, meta, last_status, created_unix, updated_unix) VALUES (1, 1, NULL, 'www.example.com/url1', 1, NULL, '{"push_only":true,"send_everything":false,"choose_events":false,"events":{"create":false,"push":true,"pull_request":false}}', NULL, true, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.webhook (id, repo_id, org_id, url, content_type, secret, events, is_ssl, is_active, hook_task_type, meta, last_status, created_unix, updated_unix) VALUES (2, 1, NULL, 'www.example.com/url2', 1, NULL, '{"push_only":false,"send_everything":false,"choose_events":false,"events":{"create":false,"push":true,"pull_request":true}}', NULL, false, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.webhook (id, repo_id, org_id, url, content_type, secret, events, is_ssl, is_active, hook_task_type, meta, last_status, created_unix, updated_unix) VALUES (3, 3, 3, 'www.example.com/url3', 1, NULL, '{"push_only":false,"send_everything":false,"choose_events":false,"events":{"create":false,"push":true,"pull_request":true}}', NULL, true, NULL, NULL, NULL, NULL, NULL);


--
-- Name: access_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.access_id_seq', 10000, true);


--
-- Name: access_token_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.access_token_id_seq', 10000, true);


--
-- Name: action_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.action_id_seq', 10000, true);


--
-- Name: attachment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attachment_id_seq', 10000, true);


--
-- Name: collaboration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.collaboration_id_seq', 10000, true);


--
-- Name: comment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.comment_id_seq', 10000, true);


--
-- Name: commit_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.commit_status_id_seq', 10000, true);


--
-- Name: deleted_branch_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.deleted_branch_id_seq', 10000, true);


--
-- Name: deploy_key_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.deploy_key_id_seq', 10000, true);


--
-- Name: email_address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.email_address_id_seq', 10000, true);


--
-- Name: follow_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.follow_id_seq', 10000, true);


--
-- Name: gpg_key_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.gpg_key_id_seq', 10000, true);


--
-- Name: hook_task_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.hook_task_id_seq', 10000, true);


--
-- Name: issue_assignees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.issue_assignees_id_seq', 10000, true);


--
-- Name: issue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.issue_id_seq', 10000, true);


--
-- Name: issue_label_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.issue_label_id_seq', 10000, true);


--
-- Name: issue_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.issue_user_id_seq', 10000, true);


--
-- Name: issue_watch_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.issue_watch_id_seq', 10000, true);


--
-- Name: label_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.label_id_seq', 10000, true);


--
-- Name: lfs_lock_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.lfs_lock_id_seq', 10000, true);


--
-- Name: lfs_meta_object_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.lfs_meta_object_id_seq', 10000, true);


--
-- Name: login_source_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.login_source_id_seq', 10000, true);


--
-- Name: milestone_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.milestone_id_seq', 10000, true);


--
-- Name: mirror_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mirror_id_seq', 10000, true);


--
-- Name: notice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notice_id_seq', 10000, true);


--
-- Name: notification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notification_id_seq', 10000, true);


--
-- Name: org_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.org_user_id_seq', 10000, true);


--
-- Name: protected_branch_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.protected_branch_id_seq', 10000, true);


--
-- Name: public_key_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.public_key_id_seq', 10000, true);


--
-- Name: pull_request_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pull_request_id_seq', 10000, true);


--
-- Name: reaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reaction_id_seq', 10000, true);


--
-- Name: release_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.release_id_seq', 10000, true);


--
-- Name: repo_indexer_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.repo_indexer_status_id_seq', 10000, true);


--
-- Name: repo_redirect_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.repo_redirect_id_seq', 10000, true);


--
-- Name: repo_unit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.repo_unit_id_seq', 10000, true);


--
-- Name: repository_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.repository_id_seq', 10000, true);


--
-- Name: star_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.star_id_seq', 10000, true);


--
-- Name: stopwatch_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.stopwatch_id_seq', 10000, true);


--
-- Name: team_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.team_id_seq', 10000, true);


--
-- Name: team_repo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.team_repo_id_seq', 10000, true);


--
-- Name: team_unit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.team_unit_id_seq', 10000, true);


--
-- Name: team_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.team_user_id_seq', 10000, true);


--
-- Name: topic_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.topic_id_seq', 10000, true);


--
-- Name: tracked_time_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tracked_time_id_seq', 10000, true);


--
-- Name: two_factor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.two_factor_id_seq', 10000, true);


--
-- Name: u2f_registration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.u2f_registration_id_seq', 10000, true);


--
-- Name: upload_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.upload_id_seq', 10000, true);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_id_seq', 10000, true);


--
-- Name: user_open_id_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_open_id_id_seq', 10000, true);


--
-- Name: version_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.version_id_seq', 10000, true);


--
-- Name: watch_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.watch_id_seq', 10000, true);


--
-- Name: webhook_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.webhook_id_seq', 10000, true);


--
-- Name: access access_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.access
    ADD CONSTRAINT access_pkey PRIMARY KEY (id);


--
-- Name: access_token access_token_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.access_token
    ADD CONSTRAINT access_token_pkey PRIMARY KEY (id);


--
-- Name: action action_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.action
    ADD CONSTRAINT action_pkey PRIMARY KEY (id);


--
-- Name: attachment attachment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachment
    ADD CONSTRAINT attachment_pkey PRIMARY KEY (id);


--
-- Name: collaboration collaboration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.collaboration
    ADD CONSTRAINT collaboration_pkey PRIMARY KEY (id);


--
-- Name: comment comment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_pkey PRIMARY KEY (id);


--
-- Name: commit_status commit_status_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commit_status
    ADD CONSTRAINT commit_status_pkey PRIMARY KEY (id);


--
-- Name: deleted_branch deleted_branch_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deleted_branch
    ADD CONSTRAINT deleted_branch_pkey PRIMARY KEY (id);


--
-- Name: deploy_key deploy_key_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deploy_key
    ADD CONSTRAINT deploy_key_pkey PRIMARY KEY (id);


--
-- Name: email_address email_address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_address
    ADD CONSTRAINT email_address_pkey PRIMARY KEY (id);


--
-- Name: external_login_user external_login_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.external_login_user
    ADD CONSTRAINT external_login_user_pkey PRIMARY KEY (external_id, login_source_id);


--
-- Name: follow follow_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.follow
    ADD CONSTRAINT follow_pkey PRIMARY KEY (id);


--
-- Name: gpg_key gpg_key_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gpg_key
    ADD CONSTRAINT gpg_key_pkey PRIMARY KEY (id);


--
-- Name: hook_task hook_task_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hook_task
    ADD CONSTRAINT hook_task_pkey PRIMARY KEY (id);


--
-- Name: issue_assignees issue_assignees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_assignees
    ADD CONSTRAINT issue_assignees_pkey PRIMARY KEY (id);


--
-- Name: issue_label issue_label_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_label
    ADD CONSTRAINT issue_label_pkey PRIMARY KEY (id);


--
-- Name: issue issue_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue
    ADD CONSTRAINT issue_pkey PRIMARY KEY (id);


--
-- Name: issue_user issue_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_user
    ADD CONSTRAINT issue_user_pkey PRIMARY KEY (id);


--
-- Name: issue_watch issue_watch_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_watch
    ADD CONSTRAINT issue_watch_pkey PRIMARY KEY (id);


--
-- Name: label label_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.label
    ADD CONSTRAINT label_pkey PRIMARY KEY (id);


--
-- Name: lfs_lock lfs_lock_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lfs_lock
    ADD CONSTRAINT lfs_lock_pkey PRIMARY KEY (id);


--
-- Name: lfs_meta_object lfs_meta_object_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lfs_meta_object
    ADD CONSTRAINT lfs_meta_object_pkey PRIMARY KEY (id);


--
-- Name: login_source login_source_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.login_source
    ADD CONSTRAINT login_source_pkey PRIMARY KEY (id);


--
-- Name: milestone milestone_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.milestone
    ADD CONSTRAINT milestone_pkey PRIMARY KEY (id);


--
-- Name: mirror mirror_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mirror
    ADD CONSTRAINT mirror_pkey PRIMARY KEY (id);


--
-- Name: notice notice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notice
    ADD CONSTRAINT notice_pkey PRIMARY KEY (id);


--
-- Name: notification notification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_pkey PRIMARY KEY (id);


--
-- Name: oauth2_session oauth2_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth2_session
    ADD CONSTRAINT oauth2_session_pkey PRIMARY KEY (id);


--
-- Name: org_user org_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_user
    ADD CONSTRAINT org_user_pkey PRIMARY KEY (id);


--
-- Name: protected_branch protected_branch_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.protected_branch
    ADD CONSTRAINT protected_branch_pkey PRIMARY KEY (id);


--
-- Name: public_key public_key_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.public_key
    ADD CONSTRAINT public_key_pkey PRIMARY KEY (id);


--
-- Name: pull_request pull_request_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pull_request
    ADD CONSTRAINT pull_request_pkey PRIMARY KEY (id);


--
-- Name: reaction reaction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reaction
    ADD CONSTRAINT reaction_pkey PRIMARY KEY (id);


--
-- Name: release release_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.release
    ADD CONSTRAINT release_pkey PRIMARY KEY (id);


--
-- Name: repo_indexer_status repo_indexer_status_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.repo_indexer_status
    ADD CONSTRAINT repo_indexer_status_pkey PRIMARY KEY (id);


--
-- Name: repo_redirect repo_redirect_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.repo_redirect
    ADD CONSTRAINT repo_redirect_pkey PRIMARY KEY (id);


--
-- Name: repo_unit repo_unit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.repo_unit
    ADD CONSTRAINT repo_unit_pkey PRIMARY KEY (id);


--
-- Name: repository repository_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.repository
    ADD CONSTRAINT repository_pkey PRIMARY KEY (id);


--
-- Name: star star_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.star
    ADD CONSTRAINT star_pkey PRIMARY KEY (id);


--
-- Name: stopwatch stopwatch_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stopwatch
    ADD CONSTRAINT stopwatch_pkey PRIMARY KEY (id);


--
-- Name: team team_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team
    ADD CONSTRAINT team_pkey PRIMARY KEY (id);


--
-- Name: team_repo team_repo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_repo
    ADD CONSTRAINT team_repo_pkey PRIMARY KEY (id);


--
-- Name: team_unit team_unit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_unit
    ADD CONSTRAINT team_unit_pkey PRIMARY KEY (id);


--
-- Name: team_user team_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_user
    ADD CONSTRAINT team_user_pkey PRIMARY KEY (id);


--
-- Name: topic topic_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.topic
    ADD CONSTRAINT topic_pkey PRIMARY KEY (id);


--
-- Name: tracked_time tracked_time_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tracked_time
    ADD CONSTRAINT tracked_time_pkey PRIMARY KEY (id);


--
-- Name: two_factor two_factor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.two_factor
    ADD CONSTRAINT two_factor_pkey PRIMARY KEY (id);


--
-- Name: u2f_registration u2f_registration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.u2f_registration
    ADD CONSTRAINT u2f_registration_pkey PRIMARY KEY (id);


--
-- Name: upload upload_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.upload
    ADD CONSTRAINT upload_pkey PRIMARY KEY (id);


--
-- Name: user_open_id user_open_id_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_open_id
    ADD CONSTRAINT user_open_id_pkey PRIMARY KEY (id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: version version_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.version
    ADD CONSTRAINT version_pkey PRIMARY KEY (id);


--
-- Name: watch watch_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.watch
    ADD CONSTRAINT watch_pkey PRIMARY KEY (id);


--
-- Name: webhook webhook_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.webhook
    ADD CONSTRAINT webhook_pkey PRIMARY KEY (id);


--
-- Name: IDX_access_token_created_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_access_token_created_unix" ON public.access_token USING btree (created_unix);


--
-- Name: IDX_access_token_uid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_access_token_uid" ON public.access_token USING btree (uid);


--
-- Name: IDX_access_token_updated_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_access_token_updated_unix" ON public.access_token USING btree (updated_unix);


--
-- Name: IDX_action_act_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_action_act_user_id" ON public.action USING btree (act_user_id);


--
-- Name: IDX_action_comment_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_action_comment_id" ON public.action USING btree (comment_id);


--
-- Name: IDX_action_created_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_action_created_unix" ON public.action USING btree (created_unix);


--
-- Name: IDX_action_is_deleted; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_action_is_deleted" ON public.action USING btree (is_deleted);


--
-- Name: IDX_action_is_private; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_action_is_private" ON public.action USING btree (is_private);


--
-- Name: IDX_action_repo_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_action_repo_id" ON public.action USING btree (repo_id);


--
-- Name: IDX_action_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_action_user_id" ON public.action USING btree (user_id);


--
-- Name: IDX_attachment_issue_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_attachment_issue_id" ON public.attachment USING btree (issue_id);


--
-- Name: IDX_attachment_release_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_attachment_release_id" ON public.attachment USING btree (release_id);


--
-- Name: IDX_collaboration_repo_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_collaboration_repo_id" ON public.collaboration USING btree (repo_id);


--
-- Name: IDX_collaboration_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_collaboration_user_id" ON public.collaboration USING btree (user_id);


--
-- Name: IDX_comment_created_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_comment_created_unix" ON public.comment USING btree (created_unix);


--
-- Name: IDX_comment_issue_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_comment_issue_id" ON public.comment USING btree (issue_id);


--
-- Name: IDX_comment_poster_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_comment_poster_id" ON public.comment USING btree (poster_id);


--
-- Name: IDX_comment_updated_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_comment_updated_unix" ON public.comment USING btree (updated_unix);


--
-- Name: IDX_commit_status_created_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_commit_status_created_unix" ON public.commit_status USING btree (created_unix);


--
-- Name: IDX_commit_status_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_commit_status_index" ON public.commit_status USING btree (index);


--
-- Name: IDX_commit_status_repo_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_commit_status_repo_id" ON public.commit_status USING btree (repo_id);


--
-- Name: IDX_commit_status_sha; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_commit_status_sha" ON public.commit_status USING btree (sha);


--
-- Name: IDX_commit_status_updated_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_commit_status_updated_unix" ON public.commit_status USING btree (updated_unix);


--
-- Name: IDX_deleted_branch_deleted_by_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_deleted_branch_deleted_by_id" ON public.deleted_branch USING btree (deleted_by_id);


--
-- Name: IDX_deleted_branch_deleted_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_deleted_branch_deleted_unix" ON public.deleted_branch USING btree (deleted_unix);


--
-- Name: IDX_deleted_branch_repo_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_deleted_branch_repo_id" ON public.deleted_branch USING btree (repo_id);


--
-- Name: IDX_deploy_key_key_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_deploy_key_key_id" ON public.deploy_key USING btree (key_id);


--
-- Name: IDX_deploy_key_repo_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_deploy_key_repo_id" ON public.deploy_key USING btree (repo_id);


--
-- Name: IDX_email_address_uid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_email_address_uid" ON public.email_address USING btree (uid);


--
-- Name: IDX_external_login_user_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_external_login_user_user_id" ON public.external_login_user USING btree (user_id);


--
-- Name: IDX_gpg_key_key_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_gpg_key_key_id" ON public.gpg_key USING btree (key_id);


--
-- Name: IDX_gpg_key_owner_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_gpg_key_owner_id" ON public.gpg_key USING btree (owner_id);


--
-- Name: IDX_hook_task_repo_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_hook_task_repo_id" ON public.hook_task USING btree (repo_id);


--
-- Name: IDX_issue_assignees_assignee_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_issue_assignees_assignee_id" ON public.issue_assignees USING btree (assignee_id);


--
-- Name: IDX_issue_assignees_issue_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_issue_assignees_issue_id" ON public.issue_assignees USING btree (issue_id);


--
-- Name: IDX_issue_closed_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_issue_closed_unix" ON public.issue USING btree (closed_unix);


--
-- Name: IDX_issue_created_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_issue_created_unix" ON public.issue USING btree (created_unix);


--
-- Name: IDX_issue_deadline_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_issue_deadline_unix" ON public.issue USING btree (deadline_unix);


--
-- Name: IDX_issue_is_closed; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_issue_is_closed" ON public.issue USING btree (is_closed);


--
-- Name: IDX_issue_is_pull; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_issue_is_pull" ON public.issue USING btree (is_pull);


--
-- Name: IDX_issue_milestone_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_issue_milestone_id" ON public.issue USING btree (milestone_id);


--
-- Name: IDX_issue_poster_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_issue_poster_id" ON public.issue USING btree (poster_id);


--
-- Name: IDX_issue_repo_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_issue_repo_id" ON public.issue USING btree (repo_id);


--
-- Name: IDX_issue_updated_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_issue_updated_unix" ON public.issue USING btree (updated_unix);


--
-- Name: IDX_issue_user_uid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_issue_user_uid" ON public.issue_user USING btree (uid);


--
-- Name: IDX_label_repo_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_label_repo_id" ON public.label USING btree (repo_id);


--
-- Name: IDX_lfs_lock_owner_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_lfs_lock_owner_id" ON public.lfs_lock USING btree (owner_id);


--
-- Name: IDX_lfs_lock_repo_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_lfs_lock_repo_id" ON public.lfs_lock USING btree (repo_id);


--
-- Name: IDX_lfs_meta_object_oid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_lfs_meta_object_oid" ON public.lfs_meta_object USING btree (oid);


--
-- Name: IDX_lfs_meta_object_repository_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_lfs_meta_object_repository_id" ON public.lfs_meta_object USING btree (repository_id);


--
-- Name: IDX_login_source_created_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_login_source_created_unix" ON public.login_source USING btree (created_unix);


--
-- Name: IDX_login_source_is_actived; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_login_source_is_actived" ON public.login_source USING btree (is_actived);


--
-- Name: IDX_login_source_is_sync_enabled; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_login_source_is_sync_enabled" ON public.login_source USING btree (is_sync_enabled);


--
-- Name: IDX_login_source_updated_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_login_source_updated_unix" ON public.login_source USING btree (updated_unix);


--
-- Name: IDX_milestone_repo_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_milestone_repo_id" ON public.milestone USING btree (repo_id);


--
-- Name: IDX_mirror_next_update_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_mirror_next_update_unix" ON public.mirror USING btree (next_update_unix);


--
-- Name: IDX_mirror_repo_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_mirror_repo_id" ON public.mirror USING btree (repo_id);


--
-- Name: IDX_mirror_updated_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_mirror_updated_unix" ON public.mirror USING btree (updated_unix);


--
-- Name: IDX_notice_created_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_notice_created_unix" ON public.notice USING btree (created_unix);


--
-- Name: IDX_notification_commit_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_notification_commit_id" ON public.notification USING btree (commit_id);


--
-- Name: IDX_notification_created_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_notification_created_unix" ON public.notification USING btree (created_unix);


--
-- Name: IDX_notification_issue_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_notification_issue_id" ON public.notification USING btree (issue_id);


--
-- Name: IDX_notification_repo_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_notification_repo_id" ON public.notification USING btree (repo_id);


--
-- Name: IDX_notification_source; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_notification_source" ON public.notification USING btree (source);


--
-- Name: IDX_notification_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_notification_status" ON public.notification USING btree (status);


--
-- Name: IDX_notification_updated_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_notification_updated_by" ON public.notification USING btree (updated_by);


--
-- Name: IDX_notification_updated_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_notification_updated_unix" ON public.notification USING btree (updated_unix);


--
-- Name: IDX_notification_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_notification_user_id" ON public.notification USING btree (user_id);


--
-- Name: IDX_oauth2_session_expires_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_oauth2_session_expires_unix" ON public.oauth2_session USING btree (expires_unix);


--
-- Name: IDX_org_user_is_public; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_org_user_is_public" ON public.org_user USING btree (is_public);


--
-- Name: IDX_org_user_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_org_user_org_id" ON public.org_user USING btree (org_id);


--
-- Name: IDX_org_user_uid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_org_user_uid" ON public.org_user USING btree (uid);


--
-- Name: IDX_public_key_owner_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_public_key_owner_id" ON public.public_key USING btree (owner_id);


--
-- Name: IDX_pull_request_base_repo_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_pull_request_base_repo_id" ON public.pull_request USING btree (base_repo_id);


--
-- Name: IDX_pull_request_has_merged; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_pull_request_has_merged" ON public.pull_request USING btree (has_merged);


--
-- Name: IDX_pull_request_head_repo_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_pull_request_head_repo_id" ON public.pull_request USING btree (head_repo_id);


--
-- Name: IDX_pull_request_issue_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_pull_request_issue_id" ON public.pull_request USING btree (issue_id);


--
-- Name: IDX_pull_request_merged_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_pull_request_merged_unix" ON public.pull_request USING btree (merged_unix);


--
-- Name: IDX_pull_request_merger_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_pull_request_merger_id" ON public.pull_request USING btree (merger_id);


--
-- Name: IDX_reaction_comment_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_reaction_comment_id" ON public.reaction USING btree (comment_id);


--
-- Name: IDX_reaction_created_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_reaction_created_unix" ON public.reaction USING btree (created_unix);


--
-- Name: IDX_reaction_issue_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_reaction_issue_id" ON public.reaction USING btree (issue_id);


--
-- Name: IDX_reaction_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_reaction_type" ON public.reaction USING btree (type);


--
-- Name: IDX_reaction_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_reaction_user_id" ON public.reaction USING btree (user_id);


--
-- Name: IDX_release_created_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_release_created_unix" ON public.release USING btree (created_unix);


--
-- Name: IDX_release_publisher_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_release_publisher_id" ON public.release USING btree (publisher_id);


--
-- Name: IDX_release_repo_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_release_repo_id" ON public.release USING btree (repo_id);


--
-- Name: IDX_release_tag_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_release_tag_name" ON public.release USING btree (tag_name);


--
-- Name: IDX_repo_indexer_status_repo_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_repo_indexer_status_repo_id" ON public.repo_indexer_status USING btree (repo_id);


--
-- Name: IDX_repo_redirect_lower_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_repo_redirect_lower_name" ON public.repo_redirect USING btree (lower_name);


--
-- Name: IDX_repo_unit_created_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_repo_unit_created_unix" ON public.repo_unit USING btree (created_unix);


--
-- Name: IDX_repo_unit_s; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_repo_unit_s" ON public.repo_unit USING btree (repo_id, type);


--
-- Name: IDX_repository_created_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_repository_created_unix" ON public.repository USING btree (created_unix);


--
-- Name: IDX_repository_fork_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_repository_fork_id" ON public.repository USING btree (fork_id);


--
-- Name: IDX_repository_is_bare; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_repository_is_bare" ON public.repository USING btree (is_bare);


--
-- Name: IDX_repository_is_fork; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_repository_is_fork" ON public.repository USING btree (is_fork);


--
-- Name: IDX_repository_is_mirror; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_repository_is_mirror" ON public.repository USING btree (is_mirror);


--
-- Name: IDX_repository_is_private; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_repository_is_private" ON public.repository USING btree (is_private);


--
-- Name: IDX_repository_lower_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_repository_lower_name" ON public.repository USING btree (lower_name);


--
-- Name: IDX_repository_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_repository_name" ON public.repository USING btree (name);


--
-- Name: IDX_repository_updated_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_repository_updated_unix" ON public.repository USING btree (updated_unix);


--
-- Name: IDX_stopwatch_issue_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_stopwatch_issue_id" ON public.stopwatch USING btree (issue_id);


--
-- Name: IDX_stopwatch_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_stopwatch_user_id" ON public.stopwatch USING btree (user_id);


--
-- Name: IDX_team_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_team_org_id" ON public.team USING btree (org_id);


--
-- Name: IDX_team_repo_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_team_repo_org_id" ON public.team_repo USING btree (org_id);


--
-- Name: IDX_team_unit_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_team_unit_org_id" ON public.team_unit USING btree (org_id);


--
-- Name: IDX_team_user_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_team_user_org_id" ON public.team_user USING btree (org_id);


--
-- Name: IDX_topic_created_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_topic_created_unix" ON public.topic USING btree (created_unix);


--
-- Name: IDX_topic_updated_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_topic_updated_unix" ON public.topic USING btree (updated_unix);


--
-- Name: IDX_tracked_time_issue_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_tracked_time_issue_id" ON public.tracked_time USING btree (issue_id);


--
-- Name: IDX_tracked_time_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_tracked_time_user_id" ON public.tracked_time USING btree (user_id);


--
-- Name: IDX_two_factor_created_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_two_factor_created_unix" ON public.two_factor USING btree (created_unix);


--
-- Name: IDX_two_factor_updated_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_two_factor_updated_unix" ON public.two_factor USING btree (updated_unix);


--
-- Name: IDX_u2f_registration_created_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_u2f_registration_created_unix" ON public.u2f_registration USING btree (created_unix);


--
-- Name: IDX_u2f_registration_updated_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_u2f_registration_updated_unix" ON public.u2f_registration USING btree (updated_unix);


--
-- Name: IDX_u2f_registration_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_u2f_registration_user_id" ON public.u2f_registration USING btree (user_id);


--
-- Name: IDX_user_created_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_user_created_unix" ON public."user" USING btree (created_unix);


--
-- Name: IDX_user_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_user_is_active" ON public."user" USING btree (is_active);


--
-- Name: IDX_user_last_login_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_user_last_login_unix" ON public."user" USING btree (last_login_unix);


--
-- Name: IDX_user_open_id_uid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_user_open_id_uid" ON public.user_open_id USING btree (uid);


--
-- Name: IDX_user_updated_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_user_updated_unix" ON public."user" USING btree (updated_unix);


--
-- Name: IDX_webhook_created_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_webhook_created_unix" ON public.webhook USING btree (created_unix);


--
-- Name: IDX_webhook_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_webhook_is_active" ON public.webhook USING btree (is_active);


--
-- Name: IDX_webhook_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_webhook_org_id" ON public.webhook USING btree (org_id);


--
-- Name: IDX_webhook_repo_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_webhook_repo_id" ON public.webhook USING btree (repo_id);


--
-- Name: IDX_webhook_updated_unix; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_webhook_updated_unix" ON public.webhook USING btree (updated_unix);


--
-- Name: UQE_access_s; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_access_s" ON public.access USING btree (user_id, repo_id);


--
-- Name: UQE_access_token_sha1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_access_token_sha1" ON public.access_token USING btree (sha1);


--
-- Name: UQE_attachment_uuid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_attachment_uuid" ON public.attachment USING btree (uuid);


--
-- Name: UQE_collaboration_s; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_collaboration_s" ON public.collaboration USING btree (repo_id, user_id);


--
-- Name: UQE_commit_status_repo_sha_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_commit_status_repo_sha_index" ON public.commit_status USING btree (index, repo_id, sha);


--
-- Name: UQE_deleted_branch_s; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_deleted_branch_s" ON public.deleted_branch USING btree (repo_id, name, commit);


--
-- Name: UQE_deploy_key_s; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_deploy_key_s" ON public.deploy_key USING btree (key_id, repo_id);


--
-- Name: UQE_email_address_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_email_address_email" ON public.email_address USING btree (email);


--
-- Name: UQE_follow_follow; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_follow_follow" ON public.follow USING btree (user_id, follow_id);


--
-- Name: UQE_issue_label_s; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_issue_label_s" ON public.issue_label USING btree (issue_id, label_id);


--
-- Name: UQE_issue_repo_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_issue_repo_index" ON public.issue USING btree (repo_id, index);


--
-- Name: UQE_issue_watch_watch; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_issue_watch_watch" ON public.issue_watch USING btree (user_id, issue_id);


--
-- Name: UQE_lfs_meta_object_s; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_lfs_meta_object_s" ON public.lfs_meta_object USING btree (oid, repository_id);


--
-- Name: UQE_login_source_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_login_source_name" ON public.login_source USING btree (name);


--
-- Name: UQE_org_user_s; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_org_user_s" ON public.org_user USING btree (uid, org_id);


--
-- Name: UQE_protected_branch_s; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_protected_branch_s" ON public.protected_branch USING btree (repo_id, branch_name);


--
-- Name: UQE_reaction_s; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_reaction_s" ON public.reaction USING btree (type, issue_id, comment_id, user_id);


--
-- Name: UQE_release_n; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_release_n" ON public.release USING btree (repo_id, tag_name);


--
-- Name: UQE_repo_redirect_s; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_repo_redirect_s" ON public.repo_redirect USING btree (owner_id, lower_name);


--
-- Name: UQE_repo_topic_s; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_repo_topic_s" ON public.repo_topic USING btree (repo_id, topic_id);


--
-- Name: UQE_repository_s; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_repository_s" ON public.repository USING btree (owner_id, lower_name);


--
-- Name: UQE_star_s; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_star_s" ON public.star USING btree (uid, repo_id);


--
-- Name: UQE_team_repo_s; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_team_repo_s" ON public.team_repo USING btree (team_id, repo_id);


--
-- Name: UQE_team_unit_s; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_team_unit_s" ON public.team_unit USING btree (team_id, type);


--
-- Name: UQE_team_user_s; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_team_user_s" ON public.team_user USING btree (team_id, uid);


--
-- Name: UQE_topic_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_topic_name" ON public.topic USING btree (name);


--
-- Name: UQE_two_factor_uid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_two_factor_uid" ON public.two_factor USING btree (uid);


--
-- Name: UQE_upload_uuid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_upload_uuid" ON public.upload USING btree (uuid);


--
-- Name: UQE_user_lower_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_user_lower_name" ON public."user" USING btree (lower_name);


--
-- Name: UQE_user_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_user_name" ON public."user" USING btree (name);


--
-- Name: UQE_user_open_id_uri; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_user_open_id_uri" ON public.user_open_id USING btree (uri);


--
-- Name: UQE_watch_watch; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_watch_watch" ON public.watch USING btree (user_id, repo_id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

