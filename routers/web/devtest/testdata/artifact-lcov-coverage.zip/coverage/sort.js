document.addEventListener("DOMContentLoaded", function() {
  document.getElementById("sort-note").textContent = "JS loaded: column sorting enabled";
  document.querySelectorAll("th[data-col]").forEach(function(th) {
    th.addEventListener("click", function() {
      var col = parseInt(th.getAttribute("data-col"), 10);
      var tbody = document.querySelector("tbody");
      var rows = Array.from(tbody.querySelectorAll("tr")).filter(function(row) {
        return row.cells.length > col;
      });
      rows.sort(function(a, b) {
        return a.cells[col].textContent.localeCompare(b.cells[col].textContent, undefined, {numeric: true});
      });
      rows.forEach(function(row) { tbody.appendChild(row); });
    });
  });
});
